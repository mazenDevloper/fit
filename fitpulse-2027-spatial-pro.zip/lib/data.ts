// FitPulse 2027 Spatial Pro - Core Domain Data & Protocol Models

export interface InBodyData {
  totalWeight: number; // 61.80 kg
  muscleMass: number; // 51.10 kg
  bodyFatPercentage: number; // 13.0%
  subcutaneousFat: number; // 9.1%
  visceralFatLevel: number; // Level 5
  bmr: number; // 1473 Kcal
  targetCaloriesMin: number; // 1800 Kcal
  targetCaloriesMax: number; // 1850 Kcal
  targetProteinMin: number; // 115 g
  targetProteinMax: number; // 120 g
  ffmi: number; // 22.4
  leanMassRatio: number; // 82.68%
  hydrationTargetLiters: number; // 3.5 L
}

export const INITIAL_INBODY_DATA: InBodyData = {
  totalWeight: 61.8,
  muscleMass: 51.1,
  bodyFatPercentage: 13.0,
  subcutaneousFat: 9.1,
  visceralFatLevel: 5,
  bmr: 1473,
  targetCaloriesMin: 1800,
  targetCaloriesMax: 1850,
  targetProteinMin: 115,
  targetProteinMax: 120,
  ffmi: 22.4,
  leanMassRatio: 82.7,
  hydrationTargetLiters: 3.5,
};

export interface Exercise {
  id: string;
  nameAr: string;
  nameEn: string;
  category:
    | "biceps"
    | "shoulders"
    | "chest"
    | "back"
    | "triceps"
    | "abs"
    | "legs";
  categoryAr: string;
  targetMuscles: string[];
  focusDescription: string;
  sets: number;
  reps: string;
  restSeconds: number;
  l4l5SafetyRating: "safe" | "therapeutic" | "strict_form"; // Green / Cyan / Amber
  spineGuidanceAr: string;
  executionSteps: string[];
  voiceCue: string;
  meshHighlightTarget: string; // Used by Three.js viewer
}

export const EXERCISE_LIBRARY: Exercise[] = [
  // 1. البايسبس والساعد
  {
    id: "high-cable-rope-curl",
    nameAr: "سحب الكيبل العالي بالحبل",
    nameEn: "High Cable Rope Curl",
    category: "biceps",
    categoryAr: "البايسبس والساعد",
    targetMuscles: ["العضلة ذات الرأسين (Biceps)", "العضدية (Brachialis)", "عضلات الساعد"],
    focusDescription: "تضخيم قمة البايسبس والـ Brachialis مع زيادة سمك الساعد عبر السحب العلوي الموجه بالحبل.",
    sets: 4,
    reps: "10 - 12 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "تثبيت الجذع وقفل الحوض لمنع أي اهتزاز في الفقرات القطنية أثناء السحب.",
    executionSteps: [
      "اضبط البكرة في المستوى العلوي وثبت حبل المقاومة.",
      "تراجع خطوة للخلف، اثنِ الركبتين قليلاً، وثبت المرفقين في زاوية موجهة للأعلى.",
      "اسحب الحبل باتجاه الجبهة/الأذنين مع فتح طرفي الحبل في نهاية الحركة لأقصى انقباض.",
      "ارجع ببطء لمدة ثانيتين للتحكم في الإطالة اللامركزية.",
    ],
    voiceCue: "اسحب الحبل نحو أعلى الرأس وافتح قبضتك في القمة لأقصى ضخ دم في البايسبس والساعد.",
    meshHighlightTarget: "biceps",
  },
  {
    id: "band-curls",
    nameAr: "ثني البايسبس بالحبل المطاطي",
    nameEn: "Band Curls",
    category: "biceps",
    categoryAr: "البايسبس والساعد",
    targetMuscles: ["قمة البايسبس", "الرأس القصير والطويل"],
    focusDescription: "تحديد قمة عضلة البايسبس في المنزل باستخدام منحنى المقاومة المتصاعد.",
    sets: 3,
    reps: "12 - 15 تكرار",
    restSeconds: 45,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "الوقوف بظهر مستقيم وكتفين للخلف دون أرجحة الجذع.",
    executionSteps: [
      "قف على منتصف الحبل المطاطي بقدمين متوازيتين بعرض الكتفين.",
      "امسك المقابض بحيث تكون راحتا اليدين متجهة للأمام.",
      "اثنِ الذراعين للأعلى مع عصر البايسبس في أعلى نقطة لثانية كاملة.",
      "انزل بتحكم كامل محافظاً على التوتر المستمر.",
    ],
    voiceCue: "اثنِ الذراعين بقوة مع تثبيت المرفقين بجانب الجسم، تنفس بانتظام.",
    meshHighlightTarget: "biceps",
  },
  {
    id: "band-hammer-curls",
    nameAr: "ثني المطرقة بالحبل",
    nameEn: "Band Hammer Curls",
    category: "biceps",
    categoryAr: "البايسبس والساعد",
    targetMuscles: ["العضدية الكعبرية (Brachioradialis)", "الرأس الخارجي للبايسبس"],
    focusDescription: "زيادة سمك الذراع وعرض قبضة الساعد ومنح مظهر ثلاثي الأبعاد للذراع.",
    sets: 3,
    reps: "12 تكرار",
    restSeconds: 45,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "الحفاظ على استقامة العمود الفقري وعدم ثني الرقبة للأمام.",
    executionSteps: [
      "قف فوق الحبل المطاطي مع إمساك المقابض بحيث تواجه الكفان بعضهما (قبضة مطرقة محايدة).",
      "ارفع اليدين باتجاه الكتف دون تدوير المعصم.",
      "اثبت في قمة الحركة للتركيز على عضلات الساعد والـ Brachialis.",
      "انزل ببطء شديد.",
    ],
    voiceCue: "حافظ على القبضة المحايدة واشعر بضغط العضدية والساعد مع كل تكرار.",
    meshHighlightTarget: "biceps",
  },

  // 2. الكتف والقوام
  {
    id: "lateral-raises",
    nameAr: "الرفرفة الجانبية بالحبل",
    nameEn: "Lateral Raises",
    category: "shoulders",
    categoryAr: "الكتف والقوام",
    targetMuscles: ["الكتف الجانبي (Lateral Deltoid)"],
    focusDescription: "تعريض الكتف الجانبي ونحت مظهر الـ V-Taper الاحترافي لتوسيع الإطار العلوي للجسم.",
    sets: 4,
    reps: "12 - 15 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "ميلان خفيف جداً للأمام (5 درجات) لحماية أوتار الكتف وعزل القطنية تماماً.",
    executionSteps: [
      "امسك الحبل المطاطي مع الوقوف ثابتاً، واحنِ المرفقين بزاوية طفيفة للغاية.",
      "ارفع الذراعين جانبياً بمستوى الكتف مع توجيه الكوع للأعلى وللخارج قليلاً.",
      "تجنب استخدام قوة الدفع من الساقين أو الظهر.",
      "انزل بالتدريج وبتحكم كامل.",
    ],
    voiceCue: "ارفع للأجناب كالنسر واجعل الكوع يقود الحركة لتعريض الكتف الجانبي.",
    meshHighlightTarget: "shoulders",
  },
  {
    id: "face-pulls",
    nameAr: "سحب الحبل للوجه (العلاج البديل للقوام)",
    nameEn: "Face Pulls (Posture Restoration)",
    category: "shoulders",
    categoryAr: "الكتف والقوام",
    targetMuscles: ["الكتف الخلفي", "الترابيس السفلية", "عضلات لوح الكتف الدوارة (Rotator Cuff)"],
    focusDescription: "التمرين العلاجي الأساسي المعوض عن سترة شد الظهر: يشد الظهر العلوي، يعالج انحناء الكتفين ويصلح القوام وظيفياً بدون ضمور عضلي.",
    sets: 4,
    reps: "15 تكرار نقي",
    restSeconds: 60,
    l4l5SafetyRating: "therapeutic",
    spineGuidanceAr: "تمرين علاجي ذهبي: يعزز الاستقامة الطبيعية للعمود الفقري ويمنع إجهاد فقرات L4-L5.",
    executionSteps: [
      "ثبت الحبل في مستوى الوجه أو أعلى قليلاً.",
      "امسك طرفي الحبل مع إبهامين متجهين للخلف.",
      "اسحب الحبل باتجاه جانبي الوجه مع سحب لوحي الكتف للخلف وتدوير الذراعين للخارج.",
      "اثبت ثانيتين في نقطة الانقباض الأقصى لتقوية العضلات المثبتة.",
    ],
    voiceCue: "اسحب الحبل للوجه وافتح ذراعيك للخارج! هذا هو علاج القوام الحقيقي وبديل مشد الظهر.",
    meshHighlightTarget: "shoulders",
  },
  {
    id: "overhead-press",
    nameAr: "الضغط العلوي",
    nameEn: "Overhead Press",
    category: "shoulders",
    categoryAr: "الكتف والقوام",
    targetMuscles: ["الكتف الأمامي", "الكتف الجانبي", "الكور"],
    focusDescription: "بناء القوة الدافعة للكتف الأمامي والكتلة العضلية الشاملة للجزء العلوي.",
    sets: 3,
    reps: "8 - 10 تكرار",
    restSeconds: 75,
    l4l5SafetyRating: "strict_form",
    spineGuidanceAr: "تفعيل عضلات البطن والمقعدة بقوة لمنع أي تقوس زائد في أسفل الظهر (L4-L5).",
    executionSteps: [
      "قف بثبات واضغط عضلات المقعدة (Glutes) لحماية الفقرات القطنية.",
      "ادفع الوزن أو الحبل للأعلى عمودياً فوق الرأس مباشرة.",
      "اقفل الحركة عند الامتداد الكامل دون ارتداد للظهر.",
      "انزل بالوزن لمستوى الترقوة بهدوء.",
    ],
    voiceCue: "اضغط للأعلى عمودياً مع شد عضلات البطن والمقعدة لحماية أسفل الظهر.",
    meshHighlightTarget: "shoulders",
  },

  // 3. الصدر
  {
    id: "close-grip-pushups",
    nameAr: "الضغط بالقبضة الضيقة",
    nameEn: "Close-Grip Pushups",
    category: "chest",
    categoryAr: "الصدر",
    targetMuscles: ["خط الصدر الداخلي", "الترايسبس", "الكتف الأمامي"],
    focusDescription: "إبراز خط الصدر الأوسط الداخلي وبناء كثافة متماسكة بوزن الجسم.",
    sets: 3,
    reps: "10 - 12 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "الحفاظ على خط مستقيم من الكعبين إلى الرأس دون هبوط الحوض.",
    executionSteps: [
      "اتخذ وضعية الضغط مع وضع اليدين للداخل أقرب من عرض الكتفين.",
      "انزل بصدرك باتجاه اليدين مع إبقاء المرفقين قريبين من جانبي القفص الصدري.",
      "ادفع الأرض بقوة للأعلى حتى الإغلاق الكامل مع عصر الصدر.",
    ],
    voiceCue: "انزل ببطء وادفع بقوة مع تركيز الضغط على وسط الصدر والترايسبس.",
    meshHighlightTarget: "chest",
  },
  {
    id: "band-flyes",
    nameAr: "تجميع الصدر بالحبل",
    nameEn: "Band Flyes",
    category: "chest",
    categoryAr: "الصدر",
    targetMuscles: ["الصدر الأوسط", "الألياف الصدرية الكبرى"],
    focusDescription: "تكثيف الصدر الأوسط وعزل العضلة بالكامل عبر مقاومة مستمرة طوال المدى الحركي.",
    sets: 3,
    reps: "12 - 15 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "تثبيت الجذع وعدم الاندفاع بالخصر أثناء التجميع.",
    executionSteps: [
      "ثبت الحبل خلفك أو لفه حول عمود/باب ثابت.",
      "افرد الذراعين جانبياً مع انثناء بسيط في المرفقين.",
      "اجمع اليدين للأمام كأنك تحتضن شجرة ضخمة حتى تتلامس اليدان.",
      "اعصر عضلات الصدر في المنتصف لمدة ثانية.",
    ],
    voiceCue: "اجمع يديك للأمام واعصر الصدر الأوسط في نقطة التلاقي، تمدد بتحكم عند العودة.",
    meshHighlightTarget: "chest",
  },
  {
    id: "incline-pushups",
    nameAr: "الضغط بزاوية علوية",
    nameEn: "Incline Pushups",
    category: "chest",
    categoryAr: "الصدر",
    targetMuscles: ["الصدر العلوي (Clavicular Head)"],
    focusDescription: "تعبئة وتحديد الصدر العلوي لمنح الصدر مظهراً ممتلئاً ومرفوعاً رياضياً.",
    sets: 3,
    reps: "12 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "وضع اليدين على منصة مرتفعة يخفف الضغط المباشر على العمود الفقري ويسهل استقامة الظهر.",
    executionSteps: [
      "ضع يديك على حافة طاولة أو سرير أو مسند مرتفع.",
      "اثبت الجذع وانزل بالصدر حتى يلامس الحافة تقريباً.",
      "ادفع للأعلى مع التركيز على الجزء العلوي من الصدر.",
    ],
    voiceCue: "ركز الضغط على الصدر العلوي وحافظ على استقامة الكور طوال العدات.",
    meshHighlightTarget: "chest",
  },

  // 4. الظهر والقطنية
  {
    id: "seated-rows",
    nameAr: "السحب للخصر",
    nameEn: "Seated Rows",
    category: "back",
    categoryAr: "الظهر والقطنية",
    targetMuscles: ["عضلات الظهر العريض (Lats)", "المعينات (Rhomboids)", "الترابيس الوسطى"],
    focusDescription: "تقوية عضلات الظهر العريض وزيادة كثافة سماكة الظهر وتحسين القوام.",
    sets: 4,
    reps: "10 - 12 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "الجلوس بظهر مفرود ومستقيم 90 درجة وسحب المقبض للبطن دون أرجحة الجذع.",
    executionSteps: [
      "اجلس مع ثني الركبتين قليلاً وتثبيت القدمين، وامسك حبل المقاومة.",
      "حافظ على صدرك مفتوحاً للأمام والكتفين للأسفل.",
      "اسحب الحبل نحو أسفل البطن/الخصر مع ضم لوحي الكتف للخلف بقوة.",
      "ارجع ببطء متيحاً لعضلات الظهر أن تتمدد بشكل صحي.",
    ],
    voiceCue: "اسحب نحو الخصر والصق لوحي الكتف ببعضهما، رائع لقوة الظهر.",
    meshHighlightTarget: "back",
  },
  {
    id: "lat-pulldowns",
    nameAr: "السحب العالي",
    nameEn: "Lat Pulldowns",
    category: "back",
    categoryAr: "الظهر والقطنية",
    targetMuscles: ["المجنص (Latissimus Dorsi)", "عضلات الإبط الخلفية"],
    focusDescription: "تعريض الظهر ومنح مظهر الجناح العضلي وتضييق الخصر البصري.",
    sets: 3,
    reps: "12 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "تجنب سحب الوزن خلف الرقبة؛ اسحب دائماً للأمام باتجاه أعلى الصدر لحماية الفقرات.",
    executionSteps: [
      "امسك الحبل بقبضة واسعة للأعلى.",
      "اسحب للأسفل باتجاه أعلى الصدر مع إخراج الصدر للأمام قليلاً.",
      "اعصر عضلات المجنص لثانية ثم اصعد ببطء للاستفادة من التمدد.",
    ],
    voiceCue: "اسحب للأسفل نحو الصدر واشعر بعضلات المجنص تتسع، حركة ممتازة.",
    meshHighlightTarget: "back",
  },
  {
    id: "supermans",
    nameAr: "تمرين سوبرمان (حامي الفقرات القطنية L4-L5)",
    nameEn: "Supermans (Lumbar Spine Guard)",
    category: "back",
    categoryAr: "الظهر والقطنية",
    targetMuscles: ["عضلات أسفل الظهر (Erector Spinae)", "المقعدة العلوية", "المثبتات العميقة"],
    focusDescription: "التمرين الذهبي الطبي لتقوية القطنية، تحصين فقرات L4-L5، وبناء الدرع العضلي الحامي للغضاريف.",
    sets: 3,
    reps: "10 تكرار مع ثبات ثانيتين",
    restSeconds: 45,
    l4l5SafetyRating: "therapeutic",
    spineGuidanceAr: "بروتوكول علاجي مباشر: يقوي الألياف العميقة للعمود الفقري ويمنع الانزلاق الغضروفي.",
    executionSteps: [
      "استلقِ على بطنك على سجادة مريحة مع مد الذراعين والساقين بالكامل.",
      "ارفع ذراعيك وصدرك وساقيك عن الأرض في آن واحد بنحو 10 إلى 15 سم فقط بسلاسة.",
      "اثبت في الأعلى لمدة ثانيتين مع التنفس الهادئ وشد عضلات الظهر السفلية.",
      "اهبط برفق على السجادة وكرر الحركة.",
    ],
    voiceCue: "ارفع صدرك وساقيك بسلاسة واثبت لثانيتين! أنت الآن تبني درعاً واقياً لفقرات L4-L5.",
    meshHighlightTarget: "spine",
  },

  // 5. الترايسبس
  {
    id: "overhead-extensions",
    nameAr: "الترايسبس فوق الرأس",
    nameEn: "Overhead Extensions",
    category: "triceps",
    categoryAr: "الترايسبس",
    targetMuscles: ["الرأس الطويل للترايسبس (Long Head)"],
    focusDescription: "تضخيم الرأس الطويل المسؤول عن أكثر من 60% من حجم عضلة الترايسبس وظهور الذراع ضخماً من الخلف.",
    sets: 3,
    reps: "12 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "الجلوس بوضعية مستقيمة أو الوقوف مع شد البطن لتجنب تقوس القطنية أثناء رفع الذراعين.",
    executionSteps: [
      "امسك الحبل فوق وخلف الرأس مع تثبيت المرفقين بالقرب من الرأس.",
      "ادفع اليدين للأعلى ولفوق الرأس حتى الامتداد الكامل للترايسبس.",
      "اثبت لثانية في قمة الحركة ثم انزل ببطء خلف الرأس لتمديد الرأس الطويل.",
    ],
    voiceCue: "ثبت مرفقيك وادفع للأعلى! هذا التمرين يضخم الرأس الطويل للذراع بامتياز.",
    meshHighlightTarget: "triceps",
  },
  {
    id: "pushdowns",
    nameAr: "ضغط الترايسبس للأسفل",
    nameEn: "Pushdowns",
    category: "triceps",
    categoryAr: "الترايسبس",
    targetMuscles: ["الرأس الجانبي والأوسط للترايسبس (Horseshoe shape)"],
    focusDescription: "نحت وتحديد عضلة الترايسبس وإبراز شكل حذوة الحصان المشدودة.",
    sets: 3,
    reps: "12 - 15 تكرار",
    restSeconds: 45,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "تثبيت الكوعين عند جانبي الضلوع وعدم الانحناء الشديد بالظهر.",
    executionSteps: [
      "ثبت الحبل في مستوى مرتفع، وامسك المقابض مع تثبيت الكوعين عند الخصر.",
      "اضغط للأسفل حتى تفرد الذراعين بالكامل وافتح القبضة للخارج قليلاً في الأسفل.",
      "اعصر الترايسبس بقوة ثم ارجع لمستوى الصدر بتحكم.",
    ],
    voiceCue: "اضغط للأسفل وافرد الذراعين تماماً، نحت احترافي للترايسبس.",
    meshHighlightTarget: "triceps",
  },
  {
    id: "diamond-push-ups",
    nameAr: "الضغط الماسي بوزن الجسم",
    nameEn: "Diamond Push-ups",
    category: "triceps",
    categoryAr: "الترايسبس",
    targetMuscles: ["الترايسبس بالكامل", "الصدر الداخلي"],
    focusDescription: "تفخيم وقوة الترايسبس بحمل وزن الجسم بالكامل وتطوير القوة الوظيفية.",
    sets: 3,
    reps: "8 - 10 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "strict_form",
    spineGuidanceAr: "شد عضلات البطن للحفاظ على استقامة الحوض ومنع انحناء القطنية.",
    executionSteps: [
      "اتخذ وضعية الضغط مع وضع الكفين معاً لتشكيل شكل ماسة (مثلث) بالإبهامين والسبابتين.",
      "انزل بالصدر ببطء نحو مركز الماسة باليدين.",
      "ادفع بقوة للأعلى بالاعتماد التام على قوة الترايسبس.",
    ],
    voiceCue: "ركز الدفع من عضلات الترايسبس واصعد بقوة وانضباط.",
    meshHighlightTarget: "triceps",
  },

  // 6. البطن والكور
  {
    id: "plank",
    nameAr: "اللوح الثابت (بلانك)",
    nameEn: "Plank",
    category: "abs",
    categoryAr: "البطن والكور",
    targetMuscles: ["عضلة البطن المستعرضة (Transverse Abdominis)", "عضلات الكور العميقة"],
    focusDescription: "شد عضلات البطن العميقة والخصر وبناء حزام طبيعي داخلي يدعم العمود الفقري.",
    sets: 3,
    reps: "ثبات 40 - 50 ثانية",
    restSeconds: 45,
    l4l5SafetyRating: "therapeutic",
    spineGuidanceAr: "تمرين أساسي في بروتوكول حماية L4-L5: يفرغ الضغط عن الفقرات عبر تقوية الجدار البطني الداخلي.",
    executionSteps: [
      "استند على الساعدين وأصابع القدمين مع الحفاظ على خط مستقيم للجسم.",
      "اشفط السرة باتجاه العمود الفقري واضغط عضلات المقعدة بقوة.",
      "تنفس بهدوء دون كتم النفس مع الحفاظ على الرقبة في وضعية محايدة.",
    ],
    voiceCue: "اشفط بطنك للداخل واثبت كالجبل، هذا هو الحزام الطبيعي الذي يحمي فقراتك.",
    meshHighlightTarget: "abs",
  },
  {
    id: "leg-raises",
    nameAr: "رفع الأرجل لأسفل البطن",
    nameEn: "Leg Raises",
    category: "abs",
    categoryAr: "البطن والكور",
    targetMuscles: ["أسفل البطن (Lower Abs)", "عضلات الحوض"],
    focusDescription: "إزالة دهون الكرش السفلي ونحت خطوط الـ V-Lines السفلية.",
    sets: 3,
    reps: "12 تكرار",
    restSeconds: 45,
    l4l5SafetyRating: "strict_form",
    spineGuidanceAr: "ضع يديك تحت المقعدة لضمان التصاق أسفل الظهر بالأرض تماماً ومنع أي فجوة هوائية تحت L4-L5.",
    executionSteps: [
      "استلقِ على ظهرك وضع يديك تحت أسفل المقعدة لتثبيت الحوض.",
      "الصق ظهرك السفلي بالأرض بالكامل.",
      "ارفع الساقين معاً للأعلى حتى زاوية 90 درجة مع الحفاظ على استقامتهما قدر الإمكان.",
      "انزل بالساقين ببطء وتوقف قبل لمس الأرض بـ 5 سم ثم كرر.",
    ],
    voiceCue: "الصق أسفل ظهرك بالأرض وارفع ساقيك بتحكم، رائع لشد أسفل البطن.",
    meshHighlightTarget: "abs",
  },
  {
    id: "crunches",
    nameAr: "طحن البطن (كرنشز)",
    nameEn: "Crunches",
    category: "abs",
    categoryAr: "البطن والكور",
    targetMuscles: ["عضلات البطن العلوية (Upper Rectus Abdominis)"],
    focusDescription: "تقسيم البطن العلوية وبناء بريق الـ 6-Packs الصلبة.",
    sets: 3,
    reps: "15 تكرار",
    restSeconds: 45,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "عدم شد الرقبة باليدين، والرفع فقط للكتفين عن الأرض دون رفع أسفل الظهر لتفادي الضغط القطني.",
    executionSteps: [
      "استلقِ مع ثني الركبتين والقدمين مثبتتين على الأرض.",
      "ضع أطراف أصابعك خلف أذنيك دون شد الرأس.",
      "ارفع لوحي الكتف عن الأرض مسافة 10 سم فقط مع عصر عضلات البطن العلوية وإخراج الزفير.",
      "انزل ببطء واستنشق الهواء.",
    ],
    voiceCue: "اعصر البطن في الأعلى وأخرج الزفير بقوة دون شد الرقبة.",
    meshHighlightTarget: "abs",
  },

  // 7. الأرجل والمقعدة (مع تخفيف عرق النسا)
  {
    id: "bodyweight-squats",
    nameAr: "القرفصاء بوزن الجسم",
    nameEn: "Bodyweight Squats",
    category: "legs",
    categoryAr: "الأرجل والمقعدة",
    targetMuscles: ["الفخذ الأمامي (Quadriceps)", "المقعدة (Glutes)", "الفخذ الخلفي"],
    focusDescription: "تقوية الفخذين وزيادة إفراز هرمون التستوستيرون الطبيعي وتسريع التضخيم الصافي.",
    sets: 3,
    reps: "15 تكرار",
    restSeconds: 60,
    l4l5SafetyRating: "safe",
    spineGuidanceAr: "النزول بوزن الجسم مع إرجاع الحوض للخلف وفتح الصدر لحفظ التقعر الطبيعي للفقرات.",
    executionSteps: [
      "قف بقدمين أوسع قليلاً من عرض الكتفين مع توجيه أصابع القدم للخارج بزاوية 15 درجة.",
      "انزل بالورك للأسفل والخلف كأنك تجلس على كرسي حتى يصبح الفخذ موازياً للأرض.",
      "ادفع من خلال الكعبين للوقوف مع شد المقعدة في القمة.",
    ],
    voiceCue: "انزل ببطء وادفع بكعبيك للأعلى مع استقامة الصدر والظهر.",
    meshHighlightTarget: "legs",
  },
  {
    id: "glute-bridges",
    nameAr: "جسر المقعدة (علاج عرق النسا والضغط القطني)",
    nameEn: "Glute Bridges (Sciatica Decompression)",
    category: "legs",
    categoryAr: "الأرجل والمقعدة",
    targetMuscles: ["عضلات المقعدة الكبرى (Gluteus Maximus)", "عضلات الحوض", "الفخذ الخلفي"],
    focusDescription: "التمرين العلاجي المعتمد لتقوية الحوض وتخفيف الضغط الغضروفي عن فقرات L4-L5 وعلاج عرق النسا.",
    sets: 4,
    reps: "12 - 15 تكرار مع ثبات ثانيتين",
    restSeconds: 45,
    l4l5SafetyRating: "therapeutic",
    spineGuidanceAr: "بروتوكول علاجي مباشر: يعيد موازنة الحوض ويحرر الضغط الانضغاطي الواقع على ديسك L4-L5.",
    executionSteps: [
      "استلقِ على ظهرك واثنِ الركبتين مع تثبيت القدمين على مسافة قريبة من المقعدة.",
      "ضع يديك مفرودتين بجانبك على الأرض.",
      "ادفع بكعبيك وارفع الحوض للأعلى حتى يشكل خطاً مستقيماً من الركبتين إلى الكتفين.",
      "اعصر المقعدة بأقصى قوة في القمة لمدة ثانيتين ثم اهبط برفق.",
    ],
    voiceCue: "ارفع الحوض واضغط المقعدة في القمة! هذا التمرين يحرر عرق النسا ويخفف الحمل عن الغضاريف.",
    meshHighlightTarget: "glutes",
  },
  {
    id: "piriformis-stretch",
    nameAr: "إطالة عضلة الكمثرية (إلغاء اختناق العصب القطني)",
    nameEn: "Piriformis Stretch (Sciatic Nerve Release)",
    category: "legs",
    categoryAr: "الأرجل والمقعدة",
    targetMuscles: ["عضلة الكمثرية (Piriformis)", "العصب الوركي (Sciatic Nerve)", "مدورات الحوض"],
    focusDescription: "الإطالة العلاجية المعجزة لإلغاء اختناق العصب القطني وإزالة آلام عرق النسا وتسهيل حركة الساقين.",
    sets: 3,
    reps: "ثبات 30 ثانية لكل ساق",
    restSeconds: 30,
    l4l5SafetyRating: "therapeutic",
    spineGuidanceAr: "تمرين استرخاء طبي يومي: يفك الضغط المتشنج حول العصب الوركي القطني.",
    executionSteps: [
      "استلقِ على ظهرك واثنِ الركبتين.",
      "ضع كاحل القدم اليمنى فوق ركبة الساق اليسرى (وضعية رقم 4).",
      "امسك فخذ الساق اليسرى بكلتا يديك واسحبه برفق باتجاه صدرك.",
      "اشعر بتمدد واسترخاء عميق في منطقة المقعدة والورك لمدة 30 ثانية مع تنفس بطيء.",
      "بدل للساق الأخرى وكرر 3 جولات.",
    ],
    voiceCue: "اسحب الفخذ بلطف وتنفس بعمق... العصب الوركي يتحرر الآن من الاختناق تماماً.",
    meshHighlightTarget: "glutes",
  },
];

// Exact Diet & Meal Breakdown Matching User Prompt with Ultra HD Visuals
export interface MealItem {
  id: string;
  nameAr: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  timeSlot: string;
  descriptionAr: string;
  components: string[];
  tipsAr: string;
  imageUrl: string;
  badge: string;
}

export const DAILY_MEALS: MealItem[] = [
  {
    id: "breakfast",
    nameAr: "وجبة الإفطار (انطلاقة الطاقة)",
    calories: 450,
    protein: 28,
    carbs: 42,
    fats: 16,
    timeSlot: "07:30 AM",
    descriptionAr: "3 بيضات مسلوقة + خبز أسمر + خيار وطماطم طازجة",
    imageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80",
    badge: "بروتين عالي + كولين",
    components: [
      "3 بيضات كاملة مسلوقة (بروتين عالي الجودة وكولين للأعصاب)",
      "رغيف خبز أسمر / حبة كاملة (ألياف وكربوهيدرات معقدة بطيئة الامتصاص)",
      "طبق خيار وطماطم طازج غني بالبوتاسيوم ومضادات الأكسدة",
    ],
    tipsAr: "يوفر الأحماض الأمينية الأساسية لإيقاف الهدم العضلي الصباحي بعد النوم.",
  },
  {
    id: "pre_workout_snack",
    nameAr: "سناك قبل التمرين (شحنة الطاقة السريعة)",
    calories: 220,
    protein: 8,
    carbs: 45,
    fats: 3,
    timeSlot: "04:30 PM (قبل التمرين بساعة)",
    descriptionAr: "كوب حليب أو لبن طازج + موزة ناضجة",
    imageUrl: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=800&auto=format&fit=crop&q=80",
    badge: "بوتاسيوم + جليكوجين سريع",
    components: [
      "كوب حليب / لبن طازج (200 مل) غني بالكالسيوم والبروتين",
      "موزة متوسطة الحجم غنية بالبوتاسيوم لتعزيز انقباض العضلات ومنع التشنجات",
    ],
    tipsAr: "يمنح الجليكوجين السريع ويحمي من هبوط الطاقة أثناء التمرين دون إثقال المعدة.",
  },
  {
    id: "lunch",
    nameAr: "وجبة الغداء (بناء الكتلة العضلية)",
    calories: 680,
    protein: 45,
    carbs: 78,
    fats: 14,
    timeSlot: "01:30 PM",
    descriptionAr: "صدر دجاج / علبة تونة / طبق عدس + 7 ملاعق أرز + سلطة خضراء زيت زيتون",
    imageUrl: "https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=800&auto=format&fit=crop&q=80",
    badge: "الوجبة الرئيسية (45g Protein)",
    components: [
      "150-180 جم صدر دجاج مشوي متبل أو علبة تونة بالماء أو طبق عدس غني",
      "7 ملاعق كبيرة أرز أبيض أو بسمتي مطبوخ باعتدال",
      "سلطة خضراء مشكلة مع ملعقة صغيرة زيت زيتون بكر",
    ],
    tipsAr: "الوجبة الرئيسية الأضخم لتزويد العضلات بـ 45 جم بروتين نقي لتسريع التضخيم الصافي.",
  },
  {
    id: "dinner",
    nameAr: "وجبة العشاء (الاستشفاء الليلي وحماية الغضاريف)",
    calories: 380,
    protein: 25,
    carbs: 22,
    fats: 12,
    timeSlot: "09:00 PM",
    descriptionAr: "علبة زبادي + قطعة جبن قريش أو أبيض مع زيت زيتون وخيار",
    imageUrl: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800&auto=format&fit=crop&q=80",
    badge: "كازين بطيء الامتصاص",
    components: [
      "علبة زبادي طبيعي / يوناني (150-170 جم)",
      "قطعة جبن قريش أو جبن أبيض قليل الملح (100 جم)",
      "ملعقة زيت زيتون بكر + شرائح خيار مهدئة للجهاز الهضمي",
    ],
    tipsAr: "بروتين الكازين بطيء الامتصاص يغذي الألياف العضلية أثناء النوم ويصلح الأنسجة.",
  },
];

// Muscle Anatomy Visual Reference Cards
export interface MuscleAnatomyCard {
  key: string;
  nameAr: string;
  nameEn: string;
  functionAr: string;
  hypertrophyFocus: string;
  spineSafetyRole: string;
  imageUrl: string;
  targetCount: number;
}

export const MUSCLE_ANATOMY_CARDS: MuscleAnatomyCard[] = [
  {
    key: "spine",
    nameAr: "العمود الفقري والغضروف القطني L4-L5",
    nameEn: "L4-L5 Lumbar & Spinal Column",
    functionAr: "محور ارتكاز الجذع ونقل الأحمال الحركية وتفريغ الضغط عن العصب الوركي",
    hypertrophyFocus: "تقوية عضلات الانتصاب الشوكي (Erector Spinae) وحزام البطن الداخلي",
    spineSafetyRole: "منع الانزلاق وتوسيع القناة العصبية عبر المشي وتمارين الإطالة",
    imageUrl: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&auto=format&fit=crop&q=80",
    targetCount: 4,
  },
  {
    key: "shoulders",
    nameAr: "عضلات الكتف والقوام والترابيس السفلية",
    nameEn: "Deltoids & Lower Trapezius",
    functionAr: "شد الكتفين للخلف وفتح الصدر طبيعياً كبديل فسيولوجي لمشد الظهر",
    hypertrophyFocus: "تعريض الكتف الجانبي والكتف الخلفي عبر Face Pulls والرفرفة",
    spineSafetyRole: "إلغاء تحدب الظهر وتحسين انسيابية الجذع",
    imageUrl: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=800&auto=format&fit=crop&q=80",
    targetCount: 5,
  },
  {
    key: "chest",
    nameAr: "عضلات الصدر (الكبرى والصغرى)",
    nameEn: "Pectoralis Major & Minor",
    functionAr: "الدفع الأفقي والتقريب العضلي وبناء درع علوي للجسم",
    hypertrophyFocus: "الضغط المنزلي وضغط الحبل المطاطي بزوايا متعددة",
    spineSafetyRole: "توازن نسبي مع عضلات الظهر لمنع شد الأكتاف للأمام",
    imageUrl: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=800&auto=format&fit=crop&q=80",
    targetCount: 3,
  },
  {
    key: "back",
    nameAr: "عضلات الظهر والمجنص (V-Taper)",
    nameEn: "Latissimus Dorsi & Rhomboids",
    functionAr: "سحب الأحمال وتوسيع إطار الظهر وحماية القفص الصدري",
    hypertrophyFocus: "السحب بالحبل والتجديف الأفقي والعمودي",
    spineSafetyRole: "دعامة رئيسية لمنع إجهاد الفقرات القطنية",
    imageUrl: "https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=800&auto=format&fit=crop&q=80",
    targetCount: 4,
  },
  {
    key: "biceps",
    nameAr: "البايسبس والساعد (عضدية كعبرية)",
    nameEn: "Biceps Brachii & Forearms",
    functionAr: "ثني المرفق وتدوير الساعد وقوة القبضة الوظيفية",
    hypertrophyFocus: "ثني الحبل العادي والمطرقة والـ Concentration Curls",
    spineSafetyRole: "أداء التمارين بظهر مستقيم دون مرجحة أسفل الظهر",
    imageUrl: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=800&auto=format&fit=crop&q=80",
    targetCount: 4,
  },
  {
    key: "triceps",
    nameAr: "الترايسبس (الرؤوس الثلاثة)",
    nameEn: "Triceps Brachii",
    functionAr: "فرد المرفق والدفع الصاروخي، يشكل 65% من حجم الذراع",
    hypertrophyFocus: "دفع الحبل للأسفل (Pushdowns) والضغط الماسي",
    spineSafetyRole: "تثبيت الكوع دون التأثير على فقرات الرقبة والقطنية",
    imageUrl: "https://images.unsplash.com/photo-1583454155184-870a1f63aebc?w=800&auto=format&fit=crop&q=80",
    targetCount: 3,
  },
  {
    key: "abs",
    nameAr: "البطن والكور والحزام الطبيعي",
    nameEn: "Core & Rectus Abdominis",
    functionAr: "حزام طبيعي داخلي يلتف حول الفقرات القطنية L4-L5 لحمايتها",
    hypertrophyFocus: "بلانك، تفريغ البطن، ورفع الساقين مع لصق الظهر بالأرض",
    spineSafetyRole: "العنصر الأهم لمنع احتكاك ديسك L4-L5",
    imageUrl: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80",
    targetCount: 3,
  },
  {
    key: "glutes",
    nameAr: "الأرجل والمقعدة وإطالة الكمثرية",
    nameEn: "Glutes & Sciatica Relievers",
    functionAr: "تثبيت عظام الحوض وتفريغ الشد عن العصب الوركي (عرق النسا)",
    hypertrophyFocus: "جسر المقعدة (Glute Bridges) والسكوات وإطالة الكمثرية",
    spineSafetyRole: "إلغاء اختناق العصب الوركي القطني فورياً",
    imageUrl: "https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=800&auto=format&fit=crop&q=80",
    targetCount: 4,
  },
];

// Today's Program Routine Item
export interface ProgramStep {
  id: string;
  timeSlot: string;
  titleAr: string;
  category: "routine" | "meal" | "workout" | "walking" | "spine_care";
  descriptionAr: string;
  calorieImpact?: number;
  proteinImpact?: number;
  isCompleted: boolean;
  actionTab?: string;
  badge: string;
}

export const INITIAL_TODAY_PROGRAM: ProgramStep[] = [
  {
    id: "step_morning_water",
    timeSlot: "06:45 AM",
    titleAr: "شرب 500 مل ماء دافئ + إطالة الكمثرية 5 دقائق",
    category: "spine_care",
    descriptionAr: "ترطيب الغضاريف صباحاً وفك اختناق العصب الوركي قبل البدء بالحركة اليومية.",
    isCompleted: true,
    actionTab: "spine-protocol",
    badge: "ترطيب الغضاريف",
  },
  {
    id: "step_breakfast",
    timeSlot: "07:30 AM",
    titleAr: "وجبة الإفطار (450 Kcal - 28g Protein)",
    category: "meal",
    descriptionAr: "3 بيضات مسلوقة + خبز أسمر + خضار طازجة (إيقاف الهدم العضلي الصباحي).",
    calorieImpact: 450,
    proteinImpact: 28,
    isCompleted: true,
    actionTab: "diet",
    badge: "إفطار التضخيم",
  },
  {
    id: "step_midday_water",
    timeSlot: "11:00 AM",
    titleAr: "شرب 1 لتر ماء + الوقوف والتمدد 3 دقائق",
    category: "spine_care",
    descriptionAr: "منع الجلوس المتواصل وتنشيط الدورة الدموية في منطقة الحوض.",
    isCompleted: false,
    actionTab: "spine-protocol",
    badge: "وقاية قطنية",
  },
  {
    id: "step_lunch",
    timeSlot: "01:30 PM",
    titleAr: "وجبة الغداء الرئيسية (680 Kcal - 45g Protein)",
    category: "meal",
    descriptionAr: "صدر دجاج / تونة + 7 ملاعق أرز + سلطة خضراء بزيت زيتون.",
    calorieImpact: 680,
    proteinImpact: 45,
    isCompleted: false,
    actionTab: "diet",
    badge: "الكتلة العضلية",
  },
  {
    id: "step_pre_snack",
    timeSlot: "04:30 PM",
    titleAr: "سناك قبل التمرين (220 Kcal - حليب + موزة)",
    category: "meal",
    descriptionAr: "شحنة جليكوجين وبوتاسيوم سريعة لدعم طاقة التمرين وحماية العضلات من الإجهاد.",
    calorieImpact: 220,
    proteinImpact: 8,
    isCompleted: false,
    actionTab: "diet",
    badge: "طاقة التدريب",
  },
  {
    id: "step_workout_session",
    timeSlot: "05:30 PM",
    titleAr: "جلسة التمارين بالحبل (سحب الوجه Face Pulls + الظهر والأكتاف)",
    category: "workout",
    descriptionAr: "4 جولات Face Pulls + 3 جولات بلانك + 4 جولات ثني بايسبس بالحبل (بدون ضغط قطني).",
    isCompleted: false,
    actionTab: "exercises",
    badge: "تضخيم وبناء",
  },
  {
    id: "step_salalah_walk",
    timeSlot: "07:15 PM",
    titleAr: "مشي صلالة (8,000 - 10,000 خطوة على شاطئ الدهاريز أو سهل إتين)",
    category: "walking",
    descriptionAr: "مشي انسيابي مسائي لضخ السائل الزلالي داخل غضروف L4-L5 وحرق 320 Kcal.",
    isCompleted: false,
    actionTab: "salalah-gps",
    badge: "مشي حقيقي GPS",
  },
  {
    id: "step_dinner",
    timeSlot: "09:00 PM",
    titleAr: "وجبة العشاء (380 Kcal - 25g Protein كازين ليلي)",
    category: "meal",
    descriptionAr: "زبادي + جبن قريش + زيت زيتون وخيار لتغذية الأنسجة أثناء النوم.",
    calorieImpact: 380,
    proteinImpact: 25,
    isCompleted: false,
    actionTab: "diet",
    badge: "استشفاء ليلي",
  },
  {
    id: "step_night_decompression",
    timeSlot: "10:30 PM",
    titleAr: "تفريغ الضغط القطني وإطالة الظهر قبل النوم (5 دقائق)",
    category: "spine_care",
    descriptionAr: "تمدد الركبتين للصدر + نوم على مرتبة طبية متوسطة الصلوبة بدون مشد ظهر.",
    isCompleted: false,
    actionTab: "spine-protocol",
    badge: "نوم هادئ",
  },
];

// Daily Check-in & Comprehensive Telemetry Record
export interface DailyCheckinData {
  date: string;
  timestamp: string;
  weightKg: number;
  stepsCount: number;
  waterMl: number;
  caloriesConsumed: number;
  caloriesTarget: number;
  proteinGrams: number;
  proteinTarget: number;
  painScore: number; // 0 to 10
  sciaticaStatus: string;
  workoutCompleted: boolean;
  completedStepsIds: string[];
  notes: string;
  gpsDistanceKm: number;
  salalahRouteName: string;
}

// Salalah GPS Walking Routes for L4-L5 Disc Hydration
export interface SalalahRoute {
  id: string;
  nameAr: string;
  nameEn: string;
  distanceKm: number;
  estimatedSteps: number;
  targetDecompressionScore: number;
  terrainType: string;
  descriptionAr: string;
  coordinates: { lat: number; lng: number }[];
}

export const SALALAH_ROUTES: SalalahRoute[] = [
  {
    id: "dahariz-beach",
    nameAr: "مسار كورنيش شاطئ الدهاريز - صلالة",
    nameEn: "Dahariz Beach Promenade - Salalah",
    distanceKm: 6.2,
    estimatedSteps: 8800,
    targetDecompressionScore: 92,
    terrainType: "ممشى ساحلي ممهد ومسطح تماماً (مثالي للفقرات)",
    descriptionAr: "الممشى الساحلي الأفضل في صلالة: الهواء البحري المشبع باليود والأرضية المستوية تضمن حركة دورانية لطيفة للحوض لتوسيع المسافات بين فقرات L4-L5.",
    coordinates: [
      { lat: 17.0298, lng: 54.1487 },
      { lat: 17.0315, lng: 54.162 },
      { lat: 17.033, lng: 54.1755 },
      { lat: 17.0345, lng: 54.189 },
    ],
  },
  {
    id: "ittin-trail",
    nameAr: "مسار سهل وجبل إتين - صلالة",
    nameEn: "Ittin Plain & Mountain Trail",
    distanceKm: 7.0,
    estimatedSteps: 9800,
    targetDecompressionScore: 96,
    terrainType: "طبيعة عشبية ناعمة مع انحدارات خفيفة جداً",
    descriptionAr: "المسار الطبيعي الأجمل وسط خضرة صلالة وضباب الجبال: أرضية عشبية تمتص صدمات الخطوات وتمنع أي ارتداد سلبي على غضاريف أسفل الظهر.",
    coordinates: [
      { lat: 17.085, lng: 54.072 },
      { lat: 17.098, lng: 54.068 },
      { lat: 17.112, lng: 54.062 },
      { lat: 17.125, lng: 54.055 },
    ],
  },
  {
    id: "haffa-palms",
    nameAr: "مسار شاطئ وبساتين الحافة - صلالة",
    nameEn: "Al Haffa Palm Coast - Salalah",
    distanceKm: 5.8,
    estimatedSteps: 8200,
    targetDecompressionScore: 88,
    terrainType: "ممشى تراثي مظلل بين أشجار النارجيل والشاطئ",
    descriptionAr: "مسار مريح وهادئ بالقرب من سوق الحافة وأشجار جوز الهند (النارجيل)، رائع للمشي المسائي الهادئ لترطيب الغضاريف قبل النوم.",
    coordinates: [
      { lat: 17.008, lng: 54.095 },
      { lat: 17.0095, lng: 54.108 },
      { lat: 17.011, lng: 54.121 },
      { lat: 17.0125, lng: 54.135 },
    ],
  },
];
