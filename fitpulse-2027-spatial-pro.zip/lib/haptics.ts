// Haptic Feedback Engine using Navigator Vibrate API

export class HapticEngine {
  public static isSupported(): boolean {
    return typeof window !== "undefined" && "vibrate" in navigator;
  }

  public static tap() {
    if (this.isSupported()) {
      try {
        navigator.vibrate(15);
      } catch {}
    }
  }

  public static medium() {
    if (this.isSupported()) {
      try {
        navigator.vibrate(35);
      } catch {}
    }
  }

  public static repDone() {
    if (this.isSupported()) {
      try {
        navigator.vibrate([25, 30, 45]);
      } catch {}
    }
  }

  public static workoutComplete() {
    if (this.isSupported()) {
      try {
        navigator.vibrate([60, 40, 80, 40, 120]);
      } catch {}
    }
  }

  public static spineAlert() {
    if (this.isSupported()) {
      try {
        navigator.vibrate([100, 50, 100]);
      } catch {}
    }
  }

  public static success() {
    if (this.isSupported()) {
      try {
        navigator.vibrate([40, 30, 60]);
      } catch {}
    }
  }
}
