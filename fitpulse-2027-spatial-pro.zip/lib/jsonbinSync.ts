export interface AppSyncState {
  todayProgram: {
    steps: Array<{
      id: string;
      timeSlot?: string;
      titleAr: string;
      category: string;
      descriptionAr?: string;
      calorieImpact?: number;
      proteinImpact?: number;
      isCompleted: boolean;
      actionTab?: string;
      badge?: string;
      imageUrl?: string;
    }>;
    weightKg: number;
    stepsCount: number;
    waterMl: number;
    painScore: number;
    notes: string;
    lastUpdated: string;
  };
  workoutSession?: {
    lastExerciseId?: string;
    completedReps?: number;
    activeMuscle?: string;
  };
  customPlan?: Record<string, unknown>;
}

const STORAGE_KEY = "apex_fitness_pro_sync_state_v1";

export async function fetchJsonBinData(): Promise<AppSyncState | null> {
  try {
    const res = await fetch("/api/jsonbin", { method: "GET" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) {
      if (typeof window !== "undefined") {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(json.data));
      }
      return json.data as AppSyncState;
    }
  } catch (e) {
    console.warn("JSONBin remote fetch failed, falling back to local storage", e);
  }

  if (typeof window !== "undefined") {
    try {
      const cached = localStorage.getItem(STORAGE_KEY);
      if (cached) return JSON.parse(cached);
    } catch {}
  }
  return null;
}

let syncTimeout: NodeJS.Timeout | null = null;

export async function saveJsonBinData(state: AppSyncState, immediate = false): Promise<boolean> {
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {}
  }

  const doUpload = async () => {
    try {
      const res = await fetch("/api/jsonbin", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(state),
      });
      const data = await res.json();
      if (data.success) {
        if (typeof window !== "undefined") {
          window.dispatchEvent(
            new CustomEvent("apex-jsonbin-sync-success", {
              detail: { timestamp: new Date().toLocaleTimeString("ar-EG") },
            })
          );
        }
        return true;
      }
      return false;
    } catch (err) {
      console.warn("Auto-sync to JSONBin error:", err);
      return false;
    }
  };

  if (immediate) {
    return await doUpload();
  }

  if (syncTimeout) clearTimeout(syncTimeout);
  syncTimeout = setTimeout(() => {
    doUpload();
  }, 800);

  return true;
}
