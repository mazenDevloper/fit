// Web Speech Synthesis & Recognition API for Arabic Coach

export class SpeechEngine {
  private static synth: SpeechSynthesis | null = null;
  private static recognition: any = null;
  private static isSpeaking: boolean = false;

  private static getSynth(): SpeechSynthesis | null {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      this.synth = window.speechSynthesis;
      return this.synth;
    }
    return null;
  }

  public static isSupported(): boolean {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  }

  public static isRecognitionSupported(): boolean {
    return (
      typeof window !== "undefined" &&
      ("SpeechRecognition" in window || "webkitSpeechRecognition" in window)
    );
  }

  public static speak(text: string, onEnd?: () => void) {
    const synth = this.getSynth();
    if (!synth) return;

    try {
      synth.cancel(); // Stop any pending speech

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "ar-SA";
      utterance.rate = 1.0;
      utterance.pitch = 1.05;

      // Find Arabic voice if available
      const voices = synth.getVoices();
      const arabicVoice = voices.find(
        (v) => v.lang.includes("ar") || v.lang.startsWith("ar")
      );
      if (arabicVoice) {
        utterance.voice = arabicVoice;
      }

      utterance.onstart = () => {
        this.isSpeaking = true;
      };

      utterance.onend = () => {
        this.isSpeaking = false;
        if (onEnd) onEnd();
      };

      utterance.onerror = () => {
        this.isSpeaking = false;
        if (onEnd) onEnd();
      };

      synth.speak(utterance);
    } catch (e) {
      console.warn("Speech synthesis error", e);
    }
  }

  public static stop() {
    const synth = this.getSynth();
    if (synth) {
      synth.cancel();
      this.isSpeaking = false;
    }
  }

  public static getIsSpeaking(): boolean {
    return this.isSpeaking;
  }

  // Voice Command Listener in Arabic
  public static startListening(
    onResult: (transcript: string) => void,
    onError?: (err: any) => void
  ): () => void {
    if (typeof window === "undefined") return () => {};

    const SpeechRec =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRec) {
      if (onError) onError("المتصفح لا يدعم التعرف على الصوت");
      return () => {};
    }

    try {
      const rec = new SpeechRec();
      rec.lang = "ar-SA";
      rec.continuous = false;
      rec.interimResults = false;

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        onResult(transcript);
      };

      rec.onerror = (e: any) => {
        if (onError) onError(e);
      };

      rec.start();

      return () => {
        try {
          rec.stop();
        } catch {}
      };
    } catch (err) {
      if (onError) onError(err);
      return () => {};
    }
  }
}
