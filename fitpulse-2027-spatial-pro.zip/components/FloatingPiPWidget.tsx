"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Maximize2,
  Minimize2,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Droplet,
  Volume2,
  ExternalLink,
  Zap,
  X,
  Plus,
  Minus,
  Check,
  Dumbbell,
  Layers,
} from "lucide-react";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

interface FloatingPiPWidgetProps {
  currentExerciseName?: string;
  targetMuscle?: string;
  onNavigateTab?: (tabId: string) => void;
}

export default function FloatingPiPWidget({
  currentExerciseName = "سحب الحبل للوجه (Face Pulls)",
  targetMuscle = "الأكتاف الخلفية والترابيس",
  onNavigateTab,
}: FloatingPiPWidgetProps) {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [seconds, setSeconds] = useState<number>(0);
  const [currentReps, setCurrentReps] = useState<number>(12);
  const [currentSet, setCurrentSet] = useState<number>(2);
  const [waterMl, setWaterMl] = useState<number>(3000);
  const [isPipActive, setIsPipActive] = useState<boolean>(false);
  const [pipSupported] = useState<boolean>(() => {
    if (typeof window === "undefined" || typeof document === "undefined") return false;
    return "pictureInPictureEnabled" in document || "documentPictureInPicture" in window;
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Position for draggable widget
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 20, y: 120 });
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Timer interval
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning]);

  // Live Canvas PiP Renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let stepCounter = 0;

    const render = () => {
      stepCounter += 0.05;
      const width = canvas.width;
      const height = canvas.height;

      // Dark Obsidian Background
      ctx.fillStyle = "#04070e";
      ctx.fillRect(0, 0, width, height);

      // Cyan Neon Border
      ctx.strokeStyle = "#00f0ff";
      ctx.lineWidth = 4;
      ctx.strokeRect(2, 2, width - 4, height - 4);

      // Header Bar
      ctx.fillStyle = "#090d16";
      ctx.fillRect(4, 4, width - 8, 48);

      ctx.fillStyle = "#00f0ff";
      ctx.font = "bold 16px monospace";
      ctx.textAlign = "left";
      ctx.fillText("APEX PRO • FLOATING HUD", 16, 32);

      // L4-L5 Badge
      ctx.fillStyle = "#10b981";
      ctx.font = "bold 12px monospace";
      ctx.textAlign = "right";
      ctx.fillText("L4-L5 SAFE ✓", width - 16, 32);

      // Exercise Title
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 20px system-ui";
      ctx.textAlign = "center";
      ctx.fillText(currentExerciseName, width / 2, 85);

      // Muscle Target
      ctx.fillStyle = "#94a3b8";
      ctx.font = "14px system-ui";
      ctx.fillText(`العضلة: ${targetMuscle}`, width / 2, 110);

      // Timer & Reps Box
      ctx.fillStyle = "#0f172a";
      ctx.strokeStyle = "#1e293b";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(20, 130, width - 40, 90, 12);
      ctx.fill();
      ctx.stroke();

      // Format time
      const mins = String(Math.floor(seconds / 60)).padStart(2, "0");
      const secs = String(seconds % 60).padStart(2, "0");

      ctx.fillStyle = "#00f0ff";
      ctx.font = "bold 32px monospace";
      ctx.textAlign = "center";
      ctx.fillText(`${mins}:${secs}`, width / 2 - 80, 185);

      ctx.fillStyle = "#64748b";
      ctx.font = "11px monospace";
      ctx.fillText("WORKOUT TIME", width / 2 - 80, 150);

      // Reps & Sets Display
      ctx.fillStyle = "#f59e0b";
      ctx.font = "bold 28px monospace";
      ctx.fillText(`الجولة ${currentSet} / 3`, width / 2 + 80, 185);

      ctx.fillStyle = "#64748b";
      ctx.font = "11px monospace";
      ctx.fillText(`${currentReps} REPS`, width / 2 + 80, 150);

      // Animated Exercise Bar Sine Wave
      ctx.beginPath();
      ctx.strokeStyle = "#00f0ff";
      ctx.lineWidth = 3;
      for (let x = 20; x < width - 20; x++) {
        const y = 250 + Math.sin(stepCounter + x * 0.05) * 12;
        if (x === 20) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      ctx.fillStyle = "#94a3b8";
      ctx.font = "11px system-ui";
      ctx.textAlign = "center";
      ctx.fillText("تفريغ الضغط عن الفقرات القطنية L4-L5 مستمر", width / 2, 280);

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [currentExerciseName, targetMuscle, seconds, currentSet, currentReps]);

  // Launch Native Picture-in-Picture Window
  const handleLaunchNativePiP = async () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;

    try {
      spatialAudio.playSpatialPulse();
      HapticEngine.medium();

      // Check if video already streaming
      if (!video.srcObject) {
        // Capture canvas stream at 30 fps
        const stream = canvas.captureStream(30);
        video.srcObject = stream;
        await video.play();
      }

      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setIsPipActive(false);
      } else {
        await video.requestPictureInPicture();
        setIsPipActive(true);
        SpeechEngine.speak("تم تفعيل التشغيل العائم فوق التطبيقات بنجاح.");
      }
    } catch (err) {
      console.warn("Native PiP error, falling back to In-App Floating Overlay", err);
      setIsOpen(true);
      setIsMinimized(false);
    }
  };

  const handleToggleTimer = () => {
    setIsTimerRunning(!isTimerRunning);
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  const handleResetTimer = () => {
    setSeconds(0);
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  const handleAddRep = () => {
    setCurrentReps((prev) => prev + 1);
    spatialAudio.playRepComplete();
    HapticEngine.tap();
  };

  const handleWaterQuick = () => {
    setWaterMl((prev) => prev + 250);
    spatialAudio.playWaterDrop();
    HapticEngine.tap();
  };

  return (
    <>
      {/* Hidden Native PiP Stream Generator Elements */}
      <canvas
        ref={canvasRef}
        width={480}
        height={300}
        className="hidden"
        aria-hidden="true"
      />
      <video
        ref={videoRef}
        muted
        playsInline
        autoPlay
        className="hidden"
        aria-hidden="true"
      />

      {/* 1. TOP FLOATING CONTROL BAR BUTTON (Always accessible in top corner) */}
      <div className="fixed bottom-6 left-6 z-50 flex items-center gap-2">
        <button
          onClick={() => {
            setIsOpen(true);
            setIsMinimized(false);
            spatialAudio.playClick();
            HapticEngine.tap();
          }}
          className="group flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-[#090d16]/95 border border-[#00f0ff]/50 text-white font-mono text-xs font-bold shadow-[0_0_25px_rgba(0,240,255,0.35)] backdrop-blur-xl hover:bg-[#00f0ff]/20 hover:scale-105 transition-all"
        >
          <div className="w-6 h-6 rounded-lg bg-[#00f0ff]/20 flex items-center justify-center text-[#00f0ff] animate-pulse">
            <Zap className="w-4 h-4" />
          </div>
          <div className="text-right">
            <span className="block text-[11px] text-[#00f0ff]">التشغيل فوق التطبيقات</span>
            <span className="block text-[9px] text-slate-400">نافذة عائمة PiP + مؤقت وجولات</span>
          </div>
        </button>

        <button
          onClick={handleLaunchNativePiP}
          className="p-3 rounded-2xl bg-[#00f0ff] text-slate-950 font-mono text-xs font-black shadow-[0_0_20px_rgba(0,240,255,0.5)] hover:bg-[#00f0ff]/90 transition hover:scale-105"
          title="تشغيل نافذة عائمة بنظام Picture-in-Picture فوق جميع التطبيقات"
        >
          <ExternalLink className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>

      {/* 2. FLOATING DRAGGABLE OVERLAY WINDOW */}
      {isOpen && (
        <div
          className={`fixed z-[9999] transition-all duration-300 rounded-3xl bg-[#090d16]/95 border border-[#00f0ff]/50 shadow-[0_0_40px_rgba(0,240,255,0.25)] backdrop-blur-2xl text-white ${
            isMinimized
              ? "bottom-24 left-6 w-72 p-3.5"
              : "bottom-24 left-6 sm:left-10 w-[92vw] sm:w-96 p-5"
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/90">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00f0ff] animate-ping" />
              <span className="text-xs font-black font-mono tracking-wider text-[#00f0ff]">
                FLOATING COCKPIT
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={handleLaunchNativePiP}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/40 text-[#00f0ff] transition text-xs"
                title="إخراج نافذة عائمة PiP خارج المتصفح"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white transition"
              >
                {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-red-500/50 text-slate-400 hover:text-red-400 transition"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Body */}
          {!isMinimized ? (
            <div className="space-y-4 pt-3">
              {/* Exercise Details */}
              <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-400">التمرين النشط</span>
                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                    L4-L5 SAFE
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">{currentExerciseName}</h4>
                <p className="text-[11px] text-[#00f0ff] font-mono">{targetMuscle}</p>
              </div>

              {/* Timer & Controls */}
              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                  <span className="text-[10px] font-mono text-slate-400 block">مؤقت الجولة</span>
                  <span className="text-xl font-black font-mono text-[#00f0ff]">
                    {String(Math.floor(seconds / 60)).padStart(2, "0")}:
                    {String(seconds % 60).padStart(2, "0")}
                  </span>
                  <div className="flex justify-center gap-2 mt-2">
                    <button
                      onClick={handleToggleTimer}
                      className={`p-1.5 px-3 rounded-xl text-xs font-mono font-bold flex items-center gap-1 ${
                        isTimerRunning
                          ? "bg-amber-500 text-slate-950"
                          : "bg-[#00f0ff] text-slate-950"
                      }`}
                    >
                      {isTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                      <span>{isTimerRunning ? "إيقاف" : "تشغيل"}</span>
                    </button>
                    <button
                      onClick={handleResetTimer}
                      className="p-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                      title="إعادة ضبط"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                  <span className="text-[10px] font-mono text-slate-400 block">التكرار (Reps)</span>
                  <span className="text-xl font-black font-mono text-amber-400">
                    {currentReps} <span className="text-xs text-slate-400 font-normal">تكرار</span>
                  </span>
                  <div className="flex justify-center items-center gap-2 mt-2">
                    <button
                      onClick={() => setCurrentReps((prev) => Math.max(0, prev - 1))}
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs font-mono font-bold text-white">
                      {currentSet}/3 جولات
                    </span>
                    <button
                      onClick={handleAddRep}
                      className="p-1.5 rounded-lg bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 hover:bg-[#00f0ff]/30"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Quick Hydration Button */}
              <div className="flex items-center justify-between p-2.5 rounded-2xl bg-blue-950/30 border border-blue-500/20 text-xs">
                <div className="flex items-center gap-2">
                  <Droplet className="w-4 h-4 text-[#00f0ff]" />
                  <span className="text-slate-300 font-mono">الماء: {waterMl} ml</span>
                </div>
                <button
                  onClick={handleWaterQuick}
                  className="px-2.5 py-1 rounded-xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 text-[#00f0ff] text-[11px] font-mono font-bold hover:bg-[#00f0ff]/30 transition"
                >
                  +250ml سريع
                </button>
              </div>

              {/* Native OS PiP Banner */}
              <button
                onClick={handleLaunchNativePiP}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#00f0ff] to-blue-500 text-slate-950 font-mono text-xs font-black shadow-[0_0_20px_rgba(0,240,255,0.4)] hover:brightness-110 transition flex items-center justify-center gap-2"
              >
                <ExternalLink className="w-4 h-4 stroke-[2.5]" />
                <span>تشغيل نافذة عائمة PiP فوق كل التطبيقات</span>
              </button>
            </div>
          ) : (
            // Minimized Floating Strip
            <div className="flex items-center justify-between pt-2">
              <div>
                <span className="text-xs font-bold text-white block">{currentExerciseName}</span>
                <span className="text-[11px] font-mono text-[#00f0ff]">
                  {String(Math.floor(seconds / 60)).padStart(2, "0")}:
                  {String(seconds % 60).padStart(2, "0")} • {currentReps} reps
                </span>
              </div>
              <button
                onClick={handleToggleTimer}
                className="p-2 rounded-xl bg-[#00f0ff] text-slate-950 font-bold"
              >
                {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
}
