"use client";

import React, { useState } from "react";
import Image from "next/image";
import {
  Dumbbell,
  Utensils,
  TrendingUp,
  User,
  Home as HomeIcon,
  Flame,
  Zap,
  ChevronRight,
  Clock,
  Scale,
  Settings,
  CheckSquare,
  Square,
  Check,
  RotateCcw,
  Sparkles,
  Info,
} from "lucide-react";
import ThreeMuscleViewer from "@/components/ThreeMuscleViewer";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";

interface ApexPhoneMockupProps {
  onNavigateTab?: (tabId: string) => void;
}

export default function ApexPhoneMockup({ onNavigateTab }: ApexPhoneMockupProps) {
  // Active sub-tab inside mockup or dual view
  const [activeDeviceTab, setActiveDeviceTab] = useState<"dual" | "workout" | "nutrition">("dual");
  const [workoutNav, setWorkoutNav] = useState<string>("workout");
  const [nutritionNav, setNutritionNav] = useState<string>("nutrition");

  // Selected Day in Workout of the Day
  const [selectedDay, setSelectedDay] = useState<string>("mon");

  // Exercise Schedule Checkboxes
  const [exercises, setExercises] = useState([
    { id: "bench_press", name: "Bench Press", setsReps: "4x10", checked: true, color: "cyan" },
    { id: "incline_fly", name: "Incline DB Fly", setsReps: "3x12", checked: true, color: "orange" },
    { id: "tricep_pushdown", name: "Tricep Pushdown", setsReps: "4x12", checked: false, color: "slate" },
  ]);

  // Calories & Macros interactive state
  const [consumedCalories, setConsumedCalories] = useState<number>(1750);
  const targetCalories = 2400;

  const toggleExercise = (id: string) => {
    setExercises((prev) =>
      prev.map((ex) => {
        if (ex.id === id) {
          const next = !ex.checked;
          if (next) {
            spatialAudio.playRepComplete();
            HapticEngine.repDone();
          } else {
            spatialAudio.playClick();
            HapticEngine.tap();
          }
          return { ...ex, checked: next };
        }
        return ex;
      })
    );
  };

  const daysList = [
    { key: "mon", day: "Mon", date: "23", time: "1h 15m", active: true },
    { key: "thu", day: "Thu", date: "26", time: "", active: false },
    { key: "fri", day: "Fr", date: "27", time: "", active: false },
    { key: "sat", day: "Sa", date: "28", time: "", active: false },
    { key: "sun", day: "Su", date: "29", time: "", active: false },
  ];

  return (
    <div className="space-y-6" id="apex-fitness-mockup-section">
      {/* Top Controls: Mode Switcher & Design Badges */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-[#090d16] border border-slate-800/90 p-4 sm:p-5 rounded-3xl gap-4 backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 flex items-center justify-center text-[#00f0ff] shadow-[0_0_15px_rgba(0,240,255,0.25)]">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold tracking-tight text-white font-mono">
                APEX FITNESS <span className="text-[#00f0ff]">PRO STUDIO</span>
              </h2>
              <span className="text-[10px] font-mono uppercase bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/40 px-2 py-0.5 rounded-full font-bold">
                تصميم مطابق 100%
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              الوضع التشريحي المتوهج (Holographic Anatomy) + خطة التغذية والتمارين
            </p>
          </div>
        </div>

        {/* View Layout Toggle */}
        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded-2xl self-end sm:self-auto">
          <button
            onClick={() => setActiveDeviceTab("dual")}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
              activeDeviceTab === "dual"
                ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            الشاشتان معاً (Dual Showcase)
          </button>
          <button
            onClick={() => setActiveDeviceTab("workout")}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
              activeDeviceTab === "workout"
                ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            شاشة التمارين (Workouts)
          </button>
          <button
            onClick={() => setActiveDeviceTab("nutrition")}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
              activeDeviceTab === "nutrition"
                ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            شاشة التغذية (Nutrition)
          </button>
        </div>
      </div>

      {/* Main Showcase Stage */}
      <div className="relative w-full py-8 px-2 sm:px-6 rounded-3xl bg-gradient-to-b from-[#0a0d16] via-[#060810] to-[#04060c] border border-slate-800/80 overflow-hidden flex flex-col items-center justify-center shadow-2xl">
        {/* Subtle APEX FITNESS watermark logo in background */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
          <div className="text-center">
            <h1 className="text-8xl sm:text-9xl font-black font-mono tracking-tighter text-white">
              APEX
            </h1>
            <p className="text-2xl sm:text-3xl font-bold tracking-[0.4em] text-slate-400">
              FITNESS
            </p>
          </div>
        </div>

        {/* Devices Container */}
        <div
          className={`relative z-10 w-full flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-12 max-w-5xl transition-all duration-300`}
        >
          {/* ========================================================= */}
          {/* PHONE 1: WORKOUTS & HOLOGRAPHIC ANATOMY (LEFT DEVICE)     */}
          {/* ========================================================= */}
          {(activeDeviceTab === "dual" || activeDeviceTab === "workout") && (
            <div className="w-full max-w-[360px] sm:max-w-[390px] rounded-[48px] bg-[#0c101d] border-[8px] border-[#1e2438] p-4 sm:p-5 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_30px_rgba(0,240,255,0.12)] relative overflow-hidden flex flex-col justify-between min-h-[780px]">
              {/* Dynamic Island / Notch */}
              <div className="w-24 h-5 bg-black rounded-full mx-auto mb-2 flex items-center justify-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
                <div className="w-2 h-2 rounded-full bg-indigo-950" />
              </div>

              {/* Phone Header: APEX FITNESS | WORKOUTS + Profile */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black font-mono tracking-wider text-white">
                    APEX FITNESS
                  </span>
                  <span className="text-slate-600">|</span>
                  <span className="text-xs font-bold text-slate-400 tracking-wide font-mono">
                    WORKOUTS
                  </span>
                </div>
                <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
                  <User className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* 3D Anatomical Torso Mannequin with Neon Glowing Muscles */}
              <div className="relative my-2 rounded-2xl bg-gradient-to-b from-[#080c18] to-[#050711] border border-slate-800/80 overflow-hidden flex flex-col items-center">
                <div className="w-full h-[230px]">
                  <ThreeMuscleViewer
                    activeMuscleTarget="chest_triceps"
                    showCardGrid={false}
                    compactMode={true}
                  />
                </div>
              </div>

              {/* Card 1: WORKOUT OF THE DAY */}
              <div className="rounded-2xl bg-[#111728] border border-slate-800/80 p-3.5 space-y-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white tracking-wide font-mono">
                    WORKOUT OF THE DAY
                  </h4>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </div>

                {/* Day selector pills */}
                <div className="flex items-center justify-between gap-1">
                  {daysList.map((d) => {
                    const isSelected = selectedDay === d.key;
                    return (
                      <button
                        key={d.key}
                        onClick={() => {
                          setSelectedDay(d.key);
                          spatialAudio.playClick();
                          HapticEngine.tap();
                        }}
                        className={`px-2 py-1 rounded-xl text-[10px] font-mono transition-all flex flex-col items-center justify-center ${
                          isSelected
                            ? "bg-[#00f0ff] text-slate-950 font-black shadow-[0_0_12px_rgba(0,240,255,0.6)]"
                            : "bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800/70"
                        }`}
                      >
                        <span className="text-[9px] opacity-80">{d.day}</span>
                        <span className="text-xs font-bold">{d.date}</span>
                        {d.time && (
                          <span className="text-[8px] font-mono mt-0.5 opacity-90">{d.time}</span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Daily Schedule Exercises */}
                <div className="space-y-1.5 pt-1">
                  <p className="text-[10px] text-slate-400 font-mono">Daily Schedule</p>
                  <div className="space-y-1.5">
                    {exercises.map((ex, index) => (
                      <div
                        key={ex.id}
                        onClick={() => toggleExercise(ex.id)}
                        className={`flex items-center justify-between p-2 rounded-xl border cursor-pointer transition-all ${
                          ex.checked
                            ? ex.color === "cyan"
                              ? "bg-[#00f0ff]/10 border-[#00f0ff]/30 text-white"
                              : "bg-orange-500/10 border-orange-500/30 text-white"
                            : "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <Dumbbell className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                          <span className="text-xs font-mono font-medium">
                            {index + 1}. {ex.name} ({ex.setsReps})
                          </span>
                        </div>

                        {/* Custom Styled Checkbox */}
                        <div
                          className={`w-4 h-4 rounded flex items-center justify-center transition ${
                            ex.checked
                              ? ex.color === "cyan"
                                ? "bg-[#00f0ff] text-slate-950"
                                : "bg-orange-500 text-white"
                              : "border border-slate-700 bg-slate-950"
                          }`}
                        >
                          {ex.checked && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card 2: PROGRESS TRACKING */}
              <div className="rounded-2xl bg-[#111728] border border-slate-800/80 p-3.5 space-y-2 shadow-lg mt-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white tracking-wide font-mono">
                    PROGRESS TRACKING
                  </h4>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </div>

                <div className="flex items-center justify-between gap-3 pt-1">
                  {/* 75% Circular Ring Gauge */}
                  <div className="relative w-16 h-16 flex items-center justify-center flex-shrink-0">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                      <path
                        className="text-slate-800"
                        strokeWidth="3.5"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      <path
                        className="text-[#00f0ff]"
                        strokeDasharray="75, 100"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                    </svg>
                    <span className="absolute text-sm font-black font-mono text-white">
                      75%
                    </span>
                  </div>

                  {/* Metrics with Wave / Sparkline */}
                  <div className="flex-1 space-y-1.5">
                    <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                      <span className="flex items-center gap-1 text-slate-300">
                        <Scale className="w-3 h-3 text-[#00f0ff]" /> Weight
                      </span>
                      <span className="flex items-center gap-1 text-slate-300">
                        <Dumbbell className="w-3 h-3 text-orange-400" /> Lifts
                      </span>
                      <span className="flex items-center gap-1 text-slate-300">
                        <Clock className="w-3 h-3 text-emerald-400" /> Time
                      </span>
                    </div>

                    {/* Smooth Neon Sine Sparkline */}
                    <div className="h-6 w-full relative">
                      <svg className="w-full h-full overflow-visible" viewBox="0 0 100 20">
                        <path
                          d="M0,15 Q15,4 30,12 T60,8 T85,16 T100,5"
                          fill="none"
                          stroke="#00f0ff"
                          strokeWidth="2"
                          className="drop-shadow-[0_0_6px_rgba(0,240,255,0.7)]"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Mobile Navigation Bar */}
              <div className="pt-3 pb-1 border-t border-slate-800/80 flex items-center justify-around text-[10px] font-mono mt-2">
                <button
                  onClick={() => setWorkoutNav("home")}
                  className={`flex flex-col items-center gap-1 ${
                    workoutNav === "home" ? "text-[#00f0ff]" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <HomeIcon className="w-4 h-4" />
                  <span>Home</span>
                </button>
                <button
                  onClick={() => setWorkoutNav("workout")}
                  className={`flex flex-col items-center gap-1 ${
                    workoutNav === "workout"
                      ? "text-[#00f0ff] font-bold"
                      : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <Dumbbell className="w-4 h-4" />
                  <span>Workout</span>
                </button>
                <button
                  onClick={() => {
                    setWorkoutNav("nutrition");
                    setActiveDeviceTab("nutrition");
                  }}
                  className={`flex flex-col items-center gap-1 ${
                    workoutNav === "nutrition" ? "text-[#00f0ff]" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <Utensils className="w-4 h-4" />
                  <span>Nutrition</span>
                </button>
                <button
                  onClick={() => setWorkoutNav("progress")}
                  className={`flex flex-col items-center gap-1 ${
                    workoutNav === "progress" ? "text-[#00f0ff]" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Progress</span>
                </button>
                <button
                  onClick={() => setWorkoutNav("profile")}
                  className={`flex flex-col items-center gap-1 ${
                    workoutNav === "profile" ? "text-[#00f0ff]" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </button>
              </div>

              {/* Home indicator bar */}
              <div className="w-28 h-1 bg-slate-700 rounded-full mx-auto mt-1" />
            </div>
          )}

          {/* ========================================================= */}
          {/* PHONE 2: NUTRITION PLAN & MACROS (RIGHT DEVICE)           */}
          {/* ========================================================= */}
          {(activeDeviceTab === "dual" || activeDeviceTab === "nutrition") && (
            <div className="w-full max-w-[360px] sm:max-w-[390px] rounded-[48px] bg-[#0c101d] border-[8px] border-[#1e2438] p-4 sm:p-5 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_30px_rgba(0,240,255,0.08)] relative overflow-hidden flex flex-col justify-between min-h-[780px]">
              {/* Dynamic Island / Notch */}
              <div className="w-24 h-5 bg-black rounded-full mx-auto mb-2 flex items-center justify-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
                <div className="w-2 h-2 rounded-full bg-indigo-950" />
              </div>

              {/* Phone Header: APEX FITNESS | NUTRITION + Profile */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black font-mono tracking-wider text-white">
                    APEX FITNESS
                  </span>
                  <span className="text-slate-600">|</span>
                  <span className="text-xs font-bold text-slate-400 tracking-wide font-mono">
                    NUTRITION
                  </span>
                </div>
                <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
                  <User className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Nutrition Plan Header */}
              <div className="flex items-center justify-between py-2">
                <h3 className="text-lg font-black font-mono text-white tracking-tight">
                  NUTRITION PLAN
                </h3>
                <span className="text-xs font-mono text-slate-400">Oct 23</span>
              </div>

              {/* TODAY'S MEALS Horizontal Cards Carousel */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white font-mono">TODAY&apos;S MEALS</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  {/* Meal 1: Avocado Toast & Eggs */}
                  <div className="rounded-2xl bg-[#111728] border border-slate-800/80 overflow-hidden shadow-md flex flex-col justify-between">
                    <div className="relative h-20 w-full bg-slate-950">
                      <Image
                        src="https://images.unsplash.com/photo-1525351484163-7529414344d8?w=500&auto=format&fit=crop&q=80"
                        alt="Avocado Toast & Eggs"
                        fill
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="p-2 space-y-0.5">
                      <p className="text-[10px] font-bold text-white leading-tight">
                        Breakfast: Avocado Toast & Eggs
                      </p>
                      <p className="text-[9px] font-mono text-slate-400">(350 kcal)</p>
                    </div>
                  </div>

                  {/* Meal 2: Grilled Salmon & Quinoa */}
                  <div className="rounded-2xl bg-[#111728] border border-slate-800/80 overflow-hidden shadow-md flex flex-col justify-between">
                    <div className="relative h-20 w-full bg-slate-950">
                      <Image
                        src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=80"
                        alt="Grilled Salmon & Quinoa"
                        fill
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="p-2 space-y-0.5">
                      <p className="text-[10px] font-bold text-white leading-tight">
                        Lunch: Grilled Salmon & Quinoa
                      </p>
                      <p className="text-[9px] font-mono text-slate-400">(580 kcal)</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* CALORIE COUNTER Card */}
              <div className="rounded-2xl bg-[#111728] border border-slate-800/80 p-3.5 space-y-2 shadow-lg my-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white font-mono">CALORIE COUNTER</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                </div>

                <div className="flex items-baseline justify-between">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-2xl font-black font-mono text-white">
                      {consumedCalories.toLocaleString()}
                    </span>
                    <span className="text-xs font-mono text-slate-400">/ 2,400 kcal</span>
                  </div>

                  <div className="flex items-center gap-1 text-slate-400">
                    <Flame className="w-4 h-4 text-orange-400" />
                    <Zap className="w-4 h-4 text-[#00f0ff]" />
                  </div>
                </div>

                {/* Segmented Gradient Progress Bar (Cyan -> Amber -> Orange) */}
                <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden p-0.5 border border-slate-800">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#00f0ff] via-[#38bdf8] to-orange-400 shadow-[0_0_10px_rgba(0,240,255,0.5)] transition-all duration-500"
                    style={{ width: `${(consumedCalories / targetCalories) * 100}%` }}
                  />
                </div>
              </div>

              {/* MACROS Donut Chart Card */}
              <div className="rounded-2xl bg-[#111728] border border-slate-800/80 p-3.5 space-y-2 shadow-lg">
                <span className="text-xs font-bold text-white font-mono">MACROS</span>

                <div className="flex items-center gap-4 pt-1">
                  {/* Donut Chart SVG */}
                  <div className="relative w-20 h-20 flex items-center justify-center flex-shrink-0">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                      {/* Background */}
                      <path
                        className="text-slate-800"
                        strokeWidth="5"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      {/* Protein Segment (40% Cyan) */}
                      <path
                        className="text-[#00f0ff]"
                        strokeDasharray="40, 100"
                        strokeDashoffset="0"
                        strokeWidth="5"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      {/* Carbs Segment (45% Orange) */}
                      <path
                        className="text-orange-400"
                        strokeDasharray="45, 100"
                        strokeDashoffset="-40"
                        strokeWidth="5"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      {/* Fats Segment (15% Emerald) */}
                      <path
                        className="text-emerald-400"
                        strokeDasharray="15, 100"
                        strokeDashoffset="-85"
                        strokeWidth="5"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                    </svg>
                  </div>

                  {/* Macro breakdown list */}
                  <div className="flex-1 space-y-1.5 text-[10px] font-mono">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-slate-300">
                        <span className="w-2 h-2 rounded-full bg-[#00f0ff]" /> Protein: 185g
                      </span>
                      <span className="text-slate-400">(40%)</span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="w-[40%] h-full bg-[#00f0ff]" />
                    </div>

                    <div className="flex items-center justify-between pt-0.5">
                      <span className="flex items-center gap-1.5 text-slate-300">
                        <span className="w-2 h-2 rounded-full bg-orange-400" /> Carbs: 190g
                      </span>
                      <span className="text-slate-400">(45%)</span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="w-[45%] h-full bg-orange-400" />
                    </div>

                    <div className="flex items-center justify-between pt-0.5">
                      <span className="flex items-center gap-1.5 text-slate-300">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" /> Fats: 55g
                      </span>
                      <span className="text-slate-400">(15%)</span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="w-[15%] h-full bg-emerald-400" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Goal & Customize Action Bar */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#111728] border border-slate-800/80 my-2">
                <span className="text-[10px] font-black font-mono text-white tracking-wider">
                  GOAL: MUSCLE GAIN
                </span>
                <button
                  onClick={() => {
                    spatialAudio.playClick();
                    HapticEngine.tap();
                  }}
                  className="flex items-center gap-1 text-[10px] font-mono text-[#00f0ff] hover:underline"
                >
                  <span>CUSTOMIZE</span>
                  <Settings className="w-3 h-3" />
                </button>
              </div>

              {/* Bottom Mobile Navigation Bar */}
              <div className="pt-3 pb-1 border-t border-slate-800/80 flex items-center justify-around text-[10px] font-mono mt-2">
                <button
                  onClick={() => setNutritionNav("home")}
                  className={`flex flex-col items-center gap-1 ${
                    nutritionNav === "home" ? "text-[#00f0ff]" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <HomeIcon className="w-4 h-4" />
                  <span>Home</span>
                </button>
                <button
                  onClick={() => {
                    setNutritionNav("workout");
                    setActiveDeviceTab("workout");
                  }}
                  className={`flex flex-col items-center gap-1 ${
                    nutritionNav === "workout"
                      ? "text-[#00f0ff]"
                      : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <Dumbbell className="w-4 h-4" />
                  <span>Workout</span>
                </button>
                <button
                  onClick={() => setNutritionNav("nutrition")}
                  className={`flex flex-col items-center gap-1 ${
                    nutritionNav === "nutrition"
                      ? "text-[#00f0ff] font-bold"
                      : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <Utensils className="w-4 h-4" />
                  <span>Nutrition</span>
                </button>
                <button
                  onClick={() => setNutritionNav("progress")}
                  className={`flex flex-col items-center gap-1 ${
                    nutritionNav === "progress" ? "text-[#00f0ff]" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Progress</span>
                </button>
                <button
                  onClick={() => setNutritionNav("profile")}
                  className={`flex flex-col items-center gap-1 ${
                    nutritionNav === "profile" ? "text-[#00f0ff]" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </button>
              </div>

              {/* Home indicator bar */}
              <div className="w-28 h-1 bg-slate-700 rounded-full mx-auto mt-1" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
