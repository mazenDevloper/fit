"use client";

import React, { useState } from "react";
import {
  Layers,
  Sparkles,
  ShieldCheck,
  Dumbbell,
  Eye,
  Activity,
  Zap,
  Volume2,
  CheckCircle2,
  Info,
  Maximize2,
} from "lucide-react";
import { MUSCLE_ANATOMY_CARDS } from "@/lib/data";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

interface Svg2DMuscleViewerProps {
  activeMuscleTarget?: string;
  onSelectMuscle?: (target: string) => void;
  showCardGrid?: boolean;
  compactMode?: boolean;
}

export default function Svg2DMuscleViewer({
  activeMuscleTarget = "chest_triceps",
  onSelectMuscle,
  showCardGrid = true,
  compactMode = false,
}: Svg2DMuscleViewerProps) {
  const [selectedMuscle, setSelectedMuscle] = useState<string>(() => {
    return activeMuscleTarget === "chest" || activeMuscleTarget === "triceps"
      ? "chest_triceps"
      : activeMuscleTarget;
  });
  const [prevPropTarget, setPrevPropTarget] = useState<string>(activeMuscleTarget);
  const [viewMode, setViewMode] = useState<"front" | "back" | "dual">("front");
  const [hoveredMuscle, setHoveredMuscle] = useState<string | null>(null);

  // Sync if prop changes
  if (activeMuscleTarget !== prevPropTarget) {
    setPrevPropTarget(activeMuscleTarget);
    const mapped =
      activeMuscleTarget === "chest" || activeMuscleTarget === "triceps"
        ? "chest_triceps"
        : activeMuscleTarget;
    setSelectedMuscle(mapped);
  }

  const activeCard =
    MUSCLE_ANATOMY_CARDS.find((c) => c.key === selectedMuscle) ||
    MUSCLE_ANATOMY_CARDS[0];

  const handleMuscleClick = (muscleKey: string) => {
    setSelectedMuscle(muscleKey);
    spatialAudio.playClick();
    HapticEngine.tap();
    if (onSelectMuscle) {
      onSelectMuscle(muscleKey);
    }
  };

  const handleVoiceExplain = () => {
    if (!activeCard) return;
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    SpeechEngine.speak(
      `تشريح ${activeCard.nameAr}. ${activeCard.spineSafetyRole}. التركيز العضلي: ${activeCard.hypertrophyFocus}.`
    );
  };

  const isMuscleActive = (keys: string[]) => {
    return (
      keys.includes(selectedMuscle) ||
      (hoveredMuscle !== null && keys.includes(hoveredMuscle))
    );
  };

  const getFillColor = (keys: string[]) => {
    if (isMuscleActive(keys)) {
      return "#00f0ff"; // Glowing Cyber Cyan
    }
    return "#e63918"; // Vibrant Anatomical Crimson
  };

  const getSecondaryFill = (keys: string[]) => {
    if (isMuscleActive(keys)) {
      return "#00c2d6";
    }
    return "#c22b10";
  };

  const getStrokeColor = (keys: string[]) => {
    if (isMuscleActive(keys)) {
      return "#ffffff";
    }
    return "#3a0c06";
  };

  const getFilter = (keys: string[]) => {
    if (isMuscleActive(keys)) {
      return "url(#cyan-glow)";
    }
    return "url(#muscle-shadow)";
  };

  return (
    <div className="space-y-4" id="apex-2d-svg-anatomy">
      {/* 1. Header Toolbar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-[#090d16] border border-slate-800/90 p-4 rounded-3xl gap-3 backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#ff4620]/15 border border-[#ff4620]/40 flex items-center justify-center text-[#ff4620] shadow-[0_0_15px_rgba(255,70,32,0.3)]">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black font-mono tracking-tight text-white">
                2D ANATOMICAL <span className="text-[#00f0ff]">SVG ENGINE</span>
              </h3>
              <span className="text-[10px] font-mono bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/40 px-2 py-0.5 rounded-full font-bold">
                SVG تفاعلي دقيق
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              مجسم العضلات ثنائي الأبعاد (Front & Back) مع أمان الفقرات L4-L5
            </p>
          </div>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-2xl self-end sm:self-auto">
          <button
            onClick={() => {
              setViewMode("front");
              spatialAudio.playClick();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
              viewMode === "front"
                ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            المنظر الأمامي (Front)
          </button>
          <button
            onClick={() => {
              setViewMode("back");
              spatialAudio.playClick();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
              viewMode === "back"
                ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            المنظر الخلفي (Back)
          </button>
          <button
            onClick={() => {
              setViewMode("dual");
              spatialAudio.playClick();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition hidden sm:inline-block ${
              viewMode === "dual"
                ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            عرض مزدوج (Dual)
          </button>
        </div>
      </div>

      {/* 2. Main Visual Canvas + Muscle Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* SVG Musculature Viewport */}
        <div
          className={`${
            compactMode ? "lg:col-span-12" : "lg:col-span-7"
          } rounded-3xl bg-[#090d16] border border-slate-800/90 p-5 shadow-2xl backdrop-blur-xl relative overflow-hidden flex flex-col items-center justify-center min-h-[460px]`}
        >
          {/* Ambient Glows */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#ff4620]/10 rounded-full blur-[90px] pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#00f0ff]/10 rounded-full blur-[90px] pointer-events-none" />

          {/* Quick Muscle Selector Pills */}
          <div className="w-full flex items-center gap-1.5 overflow-x-auto pb-3 mb-2 scrollbar-none z-10 border-b border-slate-800/80">
            {[
              { id: "chest_triceps", label: "الصدر والترايسبس" },
              { id: "core_abs", label: "البطن والوسط" },
              { id: "shoulders", label: "الأكتاف (Delts)" },
              { id: "biceps", label: "البايسبس" },
              { id: "lats_back", label: "الظهر واللاتس" },
              { id: "l4_l5_spine", label: "فقرات L4-L5" },
              { id: "glutes", label: "الأرداف (Glutes)" },
              { id: "quads", label: "الفخذ الأمامي" },
              { id: "hamstrings_calves", label: "الفخذ الخلفي والسمانة" },
            ].map((m) => {
              const active = selectedMuscle === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => handleMuscleClick(m.id)}
                  className={`px-3 py-1 rounded-xl text-[11px] font-mono whitespace-nowrap transition-all border flex-shrink-0 ${
                    active
                      ? "bg-[#00f0ff] text-slate-950 font-bold border-[#00f0ff] shadow-[0_0_10px_rgba(0,240,255,0.4)]"
                      : "bg-slate-900/80 text-slate-300 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  {m.label}
                </button>
              );
            })}
          </div>

          {/* 2D SVG Diagrams */}
          <div className="w-full flex items-center justify-center gap-6 py-2 relative z-10">
            {/* FRONT VIEW SVG */}
            {(viewMode === "front" || viewMode === "dual") && (
              <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono text-slate-400 font-bold mb-1 tracking-wider uppercase">
                  FRONT VIEW • المنظر الأمامي
                </span>
                <svg
                  viewBox="0 0 300 620"
                  className="w-full max-w-[260px] sm:max-w-[290px] h-auto drop-shadow-2xl transition-transform duration-300 hover:scale-[1.02]"
                >
                  <defs>
                    <filter id="cyan-glow" x="-20%" y="-20%" width="140%" height="140%">
                      <feGaussianBlur stdDeviation="4" result="blur" />
                      <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                    <filter id="muscle-shadow" x="-10%" y="-10%" width="120%" height="120%">
                      <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#000" floodOpacity="0.4" />
                    </filter>
                    <linearGradient id="tendon-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#f5f0e6" />
                      <stop offset="100%" stopColor="#dcd4c3" />
                    </linearGradient>
                  </defs>

                  {/* Body Contour / Base Silhouette */}
                  <g className="anatomical-base" opacity="0.95">
                    {/* Head & Neck Base */}
                    <path
                      d="M130,20 C130,10 170,10 170,20 C178,40 175,65 168,75 C164,82 136,82 132,75 C125,65 122,40 130,20 Z"
                      fill="#edd8c7"
                      stroke="#8c6239"
                      strokeWidth="1.5"
                    />
                    {/* Neck Muscles (Sternocleidomastoid) */}
                    <path
                      d="M142,70 L146,105 L150,105 L146,70 Z"
                      fill="#e63918"
                      stroke="#4a0f05"
                      strokeWidth="1"
                    />
                    <path
                      d="M158,70 L154,105 L150,105 L154,70 Z"
                      fill="#e63918"
                      stroke="#4a0f05"
                      strokeWidth="1"
                    />

                    {/* Central Tendon Line (Linea Alba & Sternum) */}
                    <path
                      d="M149,105 L151,105 L151,265 L149,265 Z"
                      fill="url(#tendon-grad)"
                      stroke="#b5a995"
                      strokeWidth="1"
                    />

                    {/* CHEST (Pectoralis Major) - Interactive */}
                    <g
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => handleMuscleClick("chest_triceps")}
                      onMouseEnter={() => setHoveredMuscle("chest_triceps")}
                      onMouseLeave={() => setHoveredMuscle(null)}
                    >
                      {/* Left Chest (Right visually) */}
                      <path
                        d="M151,110 C165,108 190,118 200,140 C198,162 175,172 151,170 C150,150 150,125 151,110 Z"
                        fill={getFillColor(["chest_triceps"])}
                        stroke={getStrokeColor(["chest_triceps"])}
                        strokeWidth="2"
                        filter={getFilter(["chest_triceps"])}
                      />
                      {/* Striation lines */}
                      <path d="M155,125 Q175,135 192,145" stroke="#ffffff" strokeWidth="0.8" opacity="0.4" fill="none" />
                      <path d="M155,145 Q172,152 188,158" stroke="#ffffff" strokeWidth="0.8" opacity="0.4" fill="none" />

                      {/* Right Chest (Left visually) */}
                      <path
                        d="M149,110 C135,108 110,118 100,140 C102,162 125,172 149,170 C150,150 150,125 149,110 Z"
                        fill={getFillColor(["chest_triceps"])}
                        stroke={getStrokeColor(["chest_triceps"])}
                        strokeWidth="2"
                        filter={getFilter(["chest_triceps"])}
                      />
                      <path d="M145,125 Q125,135 108,145" stroke="#ffffff" strokeWidth="0.8" opacity="0.4" fill="none" />
                      <path d="M145,145 Q128,152 112,158" stroke="#ffffff" strokeWidth="0.8" opacity="0.4" fill="none" />
                    </g>

                    {/* SHOULDERS / DELTOIDS (Anterior & Lateral) */}
                    <g
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => handleMuscleClick("shoulders")}
                      onMouseEnter={() => setHoveredMuscle("shoulders")}
                      onMouseLeave={() => setHoveredMuscle(null)}
                    >
                      {/* Left Deltoid */}
                      <path
                        d="M98,110 C110,105 118,115 102,142 C92,165 72,155 78,130 C80,118 90,112 98,110 Z"
                        fill={getFillColor(["shoulders"])}
                        stroke={getStrokeColor(["shoulders"])}
                        strokeWidth="2"
                        filter={getFilter(["shoulders"])}
                      />
                      {/* Right Deltoid */}
                      <path
                        d="M202,110 C190,105 182,115 198,142 C208,165 228,155 222,130 C220,118 210,112 202,110 Z"
                        fill={getFillColor(["shoulders"])}
                        stroke={getStrokeColor(["shoulders"])}
                        strokeWidth="2"
                        filter={getFilter(["shoulders"])}
                      />
                    </g>

                    {/* BICEPS (Biceps Brachii) */}
                    <g
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => handleMuscleClick("biceps")}
                      onMouseEnter={() => setHoveredMuscle("biceps")}
                      onMouseLeave={() => setHoveredMuscle(null)}
                    >
                      {/* Left Bicep */}
                      <path
                        d="M76,145 C86,155 88,185 75,205 C68,200 64,175 70,150 Z"
                        fill={getFillColor(["biceps"])}
                        stroke={getStrokeColor(["biceps"])}
                        strokeWidth="1.8"
                        filter={getFilter(["biceps"])}
                      />
                      {/* Right Bicep */}
                      <path
                        d="M224,145 C214,155 212,185 225,205 C232,200 236,175 230,150 Z"
                        fill={getFillColor(["biceps"])}
                        stroke={getStrokeColor(["biceps"])}
                        strokeWidth="1.8"
                        filter={getFilter(["biceps"])}
                      />
                    </g>

                    {/* FOREARMS (Brachioradialis & Flexors) */}
                    <g
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => handleMuscleClick("biceps")}
                    >
                      <path
                        d="M72,210 C80,225 76,270 66,290 C56,280 58,230 68,212 Z"
                        fill={getSecondaryFill(["biceps"])}
                        stroke="#3a0c06"
                        strokeWidth="1.5"
                      />
                      <path
                        d="M228,210 C220,225 224,270 234,290 C244,280 242,230 232,212 Z"
                        fill={getSecondaryFill(["biceps"])}
                        stroke="#3a0c06"
                        strokeWidth="1.5"
                      />
                      {/* Hands */}
                      <path d="M62,292 C55,305 45,330 48,345 C54,342 66,325 68,305 Z" fill="#edd8c7" stroke="#8c6239" strokeWidth="1" />
                      <path d="M238,292 C245,305 255,330 252,345 C246,342 234,325 232,305 Z" fill="#edd8c7" stroke="#8c6239" strokeWidth="1" />
                    </g>

                    {/* CORE / ABS (Rectus Abdominis & Obliques) */}
                    <g
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => handleMuscleClick("core_abs")}
                      onMouseEnter={() => setHoveredMuscle("core_abs")}
                      onMouseLeave={() => setHoveredMuscle(null)}
                    >
                      {/* 6-Pack Upper Pair */}
                      <rect
                        x="132"
                        y="176"
                        width="16"
                        height="20"
                        rx="4"
                        fill={getFillColor(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                        filter={getFilter(["core_abs"])}
                      />
                      <rect
                        x="152"
                        y="176"
                        width="16"
                        height="20"
                        rx="4"
                        fill={getFillColor(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                        filter={getFilter(["core_abs"])}
                      />

                      {/* 6-Pack Mid Pair */}
                      <rect
                        x="132"
                        y="200"
                        width="16"
                        height="22"
                        rx="4"
                        fill={getFillColor(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                        filter={getFilter(["core_abs"])}
                      />
                      <rect
                        x="152"
                        y="200"
                        width="16"
                        height="22"
                        rx="4"
                        fill={getFillColor(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                        filter={getFilter(["core_abs"])}
                      />

                      {/* 6-Pack Lower Pair / Navel Area */}
                      <rect
                        x="133"
                        y="226"
                        width="15"
                        height="24"
                        rx="4"
                        fill={getFillColor(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                        filter={getFilter(["core_abs"])}
                      />
                      <rect
                        x="152"
                        y="226"
                        width="15"
                        height="24"
                        rx="4"
                        fill={getFillColor(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                        filter={getFilter(["core_abs"])}
                      />

                      {/* Obliques (External Abdominal Obliques) */}
                      <path
                        d="M128,180 C115,190 112,230 126,252 C130,240 130,195 128,180 Z"
                        fill={getSecondaryFill(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                      />
                      <path
                        d="M172,180 C185,190 188,230 174,252 C170,240 170,195 172,180 Z"
                        fill={getSecondaryFill(["core_abs"])}
                        stroke={getStrokeColor(["core_abs"])}
                        strokeWidth="1.5"
                      />
                    </g>

                    {/* Pelvis / Inguinal Tendon Sheet */}
                    <path
                      d="M126,255 L150,285 L174,255 L168,252 L150,265 L132,252 Z"
                      fill="url(#tendon-grad)"
                      stroke="#b5a995"
                      strokeWidth="1"
                    />

                    {/* QUADRICEPS / THIGHS (Rectus Femoris & Vastus Muscles) */}
                    <g
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => handleMuscleClick("quads")}
                      onMouseEnter={() => setHoveredMuscle("quads")}
                      onMouseLeave={() => setHoveredMuscle(null)}
                    >
                      {/* Left Leg Quads */}
                      <path
                        d="M122,265 C108,285 105,370 120,410 C130,415 142,390 144,350 C146,305 138,275 122,265 Z"
                        fill={getFillColor(["quads"])}
                        stroke={getStrokeColor(["quads"])}
                        strokeWidth="2"
                        filter={getFilter(["quads"])}
                      />
                      {/* Left Vastus Medialis (Teardrop) */}
                      <path
                        d="M136,365 C146,380 144,410 135,418 C128,415 128,390 136,365 Z"
                        fill={getSecondaryFill(["quads"])}
                        stroke="#3a0c06"
                        strokeWidth="1"
                      />

                      {/* Right Leg Quads */}
                      <path
                        d="M178,265 C192,285 195,370 180,410 C170,415 158,390 156,350 C154,305 162,275 178,265 Z"
                        fill={getFillColor(["quads"])}
                        stroke={getStrokeColor(["quads"])}
                        strokeWidth="2"
                        filter={getFilter(["quads"])}
                      />
                      {/* Right Vastus Medialis (Teardrop) */}
                      <path
                        d="M164,365 C154,380 156,410 165,418 C172,415 172,390 164,365 Z"
                        fill={getSecondaryFill(["quads"])}
                        stroke="#3a0c06"
                        strokeWidth="1"
                      />
                    </g>

                    {/* Knees (Patellar Tendons) */}
                    <circle cx="126" cy="428" r="8" fill="url(#tendon-grad)" stroke="#b5a995" strokeWidth="1.2" />
                    <circle cx="174" cy="428" r="8" fill="url(#tendon-grad)" stroke="#b5a995" strokeWidth="1.2" />

                    {/* CALVES & SHINS (Tibialis Anterior & Gastrocnemius Front) */}
                    <g
                      className="cursor-pointer transition-all duration-300"
                      onClick={() => handleMuscleClick("hamstrings_calves")}
                      onMouseEnter={() => setHoveredMuscle("hamstrings_calves")}
                      onMouseLeave={() => setHoveredMuscle(null)}
                    >
                      {/* Left Calf / Shin */}
                      <path
                        d="M120,440 C110,460 110,515 122,555 C128,555 134,510 132,460 C130,442 124,438 120,440 Z"
                        fill={getFillColor(["hamstrings_calves"])}
                        stroke={getStrokeColor(["hamstrings_calves"])}
                        strokeWidth="1.8"
                        filter={getFilter(["hamstrings_calves"])}
                      />
                      {/* Right Calf / Shin */}
                      <path
                        d="M180,440 C190,460 190,515 178,555 C172,555 166,510 168,460 C170,442 176,438 180,440 Z"
                        fill={getFillColor(["hamstrings_calves"])}
                        stroke={getStrokeColor(["hamstrings_calves"])}
                        strokeWidth="1.8"
                        filter={getFilter(["hamstrings_calves"])}
                      />
                    </g>

                    {/* Ankles & Feet */}
                    <path d="M118,560 C112,580 102,595 110,605 C124,608 132,598 126,560 Z" fill="#edd8c7" stroke="#8c6239" strokeWidth="1.2" />
                    <path d="M182,560 C188,580 198,595 190,605 C176,608 168,598 174,560 Z" fill="#edd8c7" stroke="#8c6239" strokeWidth="1.2" />
                  </g>
                </svg>
              </div>
            )}

            {/* BACK VIEW SVG */}
            {(viewMode === "back" || viewMode === "dual") && (
              <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono text-slate-400 font-bold mb-1 tracking-wider uppercase">
                  BACK VIEW • المنظر الخلفي
                </span>
                <svg
                  viewBox="0 0 300 620"
                  className="w-full max-w-[260px] sm:max-w-[290px] h-auto drop-shadow-2xl transition-transform duration-300 hover:scale-[1.02]"
                >
                  {/* Head & Upper Neck Back */}
                  <path
                    d="M130,20 C130,10 170,10 170,20 C178,40 175,65 168,75 C164,82 136,82 132,75 C125,65 122,40 130,20 Z"
                    fill="#edd8c7"
                    stroke="#8c6239"
                    strokeWidth="1.5"
                  />

                  {/* TRAPEZIUS & UPPER BACK (Traps) */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("lats_back")}
                    onMouseEnter={() => setHoveredMuscle("lats_back")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    <path
                      d="M150,75 L175,108 L188,125 L150,185 L112,125 L125,108 Z"
                      fill={getFillColor(["lats_back"])}
                      stroke={getStrokeColor(["lats_back"])}
                      strokeWidth="2"
                      filter={getFilter(["lats_back"])}
                    />
                  </g>

                  {/* REAR DELTOIDS */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("shoulders")}
                    onMouseEnter={() => setHoveredMuscle("shoulders")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    <path
                      d="M98,110 C110,105 118,115 104,138 C94,155 78,145 80,128 Z"
                      fill={getFillColor(["shoulders"])}
                      stroke={getStrokeColor(["shoulders"])}
                      strokeWidth="1.8"
                      filter={getFilter(["shoulders"])}
                    />
                    <path
                      d="M202,110 C190,105 182,115 196,138 C206,155 222,145 220,128 Z"
                      fill={getFillColor(["shoulders"])}
                      stroke={getStrokeColor(["shoulders"])}
                      strokeWidth="1.8"
                      filter={getFilter(["shoulders"])}
                    />
                  </g>

                  {/* TRICEPS (Triceps Brachii 3 Heads) */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("chest_triceps")}
                    onMouseEnter={() => setHoveredMuscle("chest_triceps")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    {/* Left Triceps */}
                    <path
                      d="M78,135 C88,145 86,185 75,205 C65,195 68,155 78,135 Z"
                      fill={getFillColor(["chest_triceps"])}
                      stroke={getStrokeColor(["chest_triceps"])}
                      strokeWidth="2"
                      filter={getFilter(["chest_triceps"])}
                    />
                    {/* Right Triceps */}
                    <path
                      d="M222,135 C212,145 214,185 225,205 C235,195 232,155 222,135 Z"
                      fill={getFillColor(["chest_triceps"])}
                      stroke={getStrokeColor(["chest_triceps"])}
                      strokeWidth="2"
                      filter={getFilter(["chest_triceps"])}
                    />
                  </g>

                  {/* LATS (Latissimus Dorsi) */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("lats_back")}
                    onMouseEnter={() => setHoveredMuscle("lats_back")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    {/* Left Lat Wing */}
                    <path
                      d="M148,160 C125,170 106,185 110,230 C125,238 144,228 148,220 Z"
                      fill={getFillColor(["lats_back"])}
                      stroke={getStrokeColor(["lats_back"])}
                      strokeWidth="2"
                      filter={getFilter(["lats_back"])}
                    />
                    {/* Right Lat Wing */}
                    <path
                      d="M152,160 C175,170 194,185 190,230 C175,238 156,228 152,220 Z"
                      fill={getFillColor(["lats_back"])}
                      stroke={getStrokeColor(["lats_back"])}
                      strokeWidth="2"
                      filter={getFilter(["lats_back"])}
                    />
                  </g>

                  {/* L4-L5 LUMBAR SPINE & ERECTOR SPINAE - Highlighted Protection */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("l4_l5_spine")}
                    onMouseEnter={() => setHoveredMuscle("l4_l5_spine")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    {/* Lumbar Spine Column */}
                    <rect
                      x="146"
                      y="215"
                      width="8"
                      height="48"
                      rx="3"
                      fill={
                        isMuscleActive(["l4_l5_spine"]) ? "#10b981" : "#059669"
                      }
                      stroke={
                        isMuscleActive(["l4_l5_spine"]) ? "#ffffff" : "#047857"
                      }
                      strokeWidth="2"
                      filter={
                        isMuscleActive(["l4_l5_spine"])
                          ? "url(#cyan-glow)"
                          : undefined
                      }
                    />
                    {/* L4 & L5 Specific Disc Badges */}
                    <circle cx="150" cy="245" r="5" fill="#34d399" stroke="#ffffff" strokeWidth="1" />
                    <circle cx="150" cy="256" r="5" fill="#34d399" stroke="#ffffff" strokeWidth="1" />
                    <text x="160" y="253" fill="#34d399" fontSize="8" fontFamily="monospace" fontWeight="bold">
                      L4-L5
                    </text>
                  </g>

                  {/* GLUTES (Gluteus Maximus & Medius) */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("glutes")}
                    onMouseEnter={() => setHoveredMuscle("glutes")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    {/* Left Glute */}
                    <path
                      d="M149,262 C130,260 115,280 120,315 C132,326 148,318 149,262 Z"
                      fill={getFillColor(["glutes"])}
                      stroke={getStrokeColor(["glutes"])}
                      strokeWidth="2"
                      filter={getFilter(["glutes"])}
                    />
                    {/* Right Glute */}
                    <path
                      d="M151,262 C170,260 185,280 180,315 C168,326 152,318 151,262 Z"
                      fill={getFillColor(["glutes"])}
                      stroke={getStrokeColor(["glutes"])}
                      strokeWidth="2"
                      filter={getFilter(["glutes"])}
                    />
                  </g>

                  {/* HAMSTRINGS (Biceps Femoris / Semitendinosus) */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("hamstrings_calves")}
                    onMouseEnter={() => setHoveredMuscle("hamstrings_calves")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    {/* Left Hamstring */}
                    <path
                      d="M120,320 C108,340 112,390 124,415 C136,410 144,380 142,322 Z"
                      fill={getFillColor(["hamstrings_calves"])}
                      stroke={getStrokeColor(["hamstrings_calves"])}
                      strokeWidth="2"
                      filter={getFilter(["hamstrings_calves"])}
                    />
                    {/* Right Hamstring */}
                    <path
                      d="M180,320 C192,340 188,390 176,415 C164,410 156,380 158,322 Z"
                      fill={getFillColor(["hamstrings_calves"])}
                      stroke={getStrokeColor(["hamstrings_calves"])}
                      strokeWidth="2"
                      filter={getFilter(["hamstrings_calves"])}
                    />
                  </g>

                  {/* CALVES (Gastrocnemius & Soleus Back) */}
                  <g
                    className="cursor-pointer transition-all duration-300"
                    onClick={() => handleMuscleClick("hamstrings_calves")}
                    onMouseEnter={() => setHoveredMuscle("hamstrings_calves")}
                    onMouseLeave={() => setHoveredMuscle(null)}
                  >
                    {/* Left Diamond Calf */}
                    <path
                      d="M124,430 C110,445 110,490 122,535 C128,540 136,495 136,450 Z"
                      fill={getSecondaryFill(["hamstrings_calves"])}
                      stroke={getStrokeColor(["hamstrings_calves"])}
                      strokeWidth="1.8"
                    />
                    {/* Right Diamond Calf */}
                    <path
                      d="M176,430 C190,445 190,490 178,535 C172,540 164,495 164,450 Z"
                      fill={getSecondaryFill(["hamstrings_calves"])}
                      stroke={getStrokeColor(["hamstrings_calves"])}
                      strokeWidth="1.8"
                    />
                    {/* Achilles Tendon */}
                    <path d="M122,538 L126,565 L124,565 L120,538 Z" fill="url(#tendon-grad)" />
                    <path d="M178,538 L174,565 L176,565 L180,538 Z" fill="url(#tendon-grad)" />
                  </g>
                </svg>
              </div>
            )}
          </div>

          <p className="text-[11px] font-mono text-slate-400 mt-2 text-center">
            💡 اضغط على أي عضلة لمعاينة تشريحها الطبي والتمارين الآمنة لفقرات L4-L5
          </p>
        </div>

        {/* Muscle Inspector & Clinical Protocol Card */}
        {!compactMode && (
          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-3xl bg-[#090d16] border border-slate-800/90 p-5 shadow-2xl backdrop-blur-xl space-y-4 relative overflow-hidden">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 flex items-center justify-center text-[#00f0ff]">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-black font-mono uppercase tracking-wider text-[#00f0ff]">
                      ANATOMICAL TARGET
                    </span>
                    <h3 className="text-base font-black text-white">
                      {activeCard?.nameAr || "الصدر والترايسبس"}
                    </h3>
                  </div>
                </div>

                <button
                  onClick={handleVoiceExplain}
                  className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 hover:text-[#00f0ff] transition text-xs font-mono flex items-center gap-1"
                  title="سماع الشرح التشريحي صوتياً"
                >
                  <Volume2 className="w-4 h-4" />
                  <span className="hidden sm:inline">صوت</span>
                </button>
              </div>

              {/* Bio Details */}
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
                  <span className="text-slate-400 font-mono block text-[10px] uppercase">
                    الوظيفة التشريحية والميكانيكا الحيوية
                  </span>
                  <p className="text-slate-200 leading-relaxed">
                    {activeCard?.functionAr}
                  </p>
                </div>

                {/* L4-L5 Protocol Badge */}
                <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-1">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold font-mono text-[11px]">
                    <ShieldCheck className="w-4 h-4" />
                    <span>دور الأمان وحماية الفقرات L4-L5:</span>
                  </div>
                  <p className="text-emerald-200 text-[11px] leading-relaxed">
                    {activeCard?.spineSafetyRole}
                  </p>
                </div>

                {/* Hypertrophy Focus */}
                <div className="p-3 rounded-2xl bg-[#00f0ff]/10 border border-[#00f0ff]/30 space-y-1">
                  <span className="text-[#00f0ff] font-mono text-[10px] uppercase block font-bold">
                    التركيز والتضخيم المستهدف:
                  </span>
                  <p className="text-slate-200 text-[11px] leading-relaxed">
                    {activeCard?.hypertrophyFocus}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
