"use client";

import React, { useState, useEffect } from "react";
import {
  Dumbbell,
  Play,
  CheckCircle2,
  ShieldCheck,
  ShieldAlert,
  Volume2,
  RotateCcw,
  Sparkles,
  ChevronRight,
  X,
  Timer,
  Flame,
  Award,
  Layers,
  ArrowRight,
} from "lucide-react";
import confetti from "canvas-confetti";
import { EXERCISE_LIBRARY, Exercise } from "@/lib/data";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";
import ExerciseVisualizer from "@/components/ExerciseVisualizer";

interface ExerciseLibraryProps {
  onHighlightMuscleIn3D?: (meshKey: string) => void;
}

export default function ExerciseLibrary({ onHighlightMuscleIn3D }: ExerciseLibraryProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [activeExerciseModal, setActiveExerciseModal] = useState<Exercise | null>(null);
  const [expandedAnimationId, setExpandedAnimationId] = useState<string | null>(null);

  // Workout Session State (Interactive Player)
  const [workoutExercise, setWorkoutExercise] = useState<Exercise | null>(null);
  const [currentSet, setCurrentSet] = useState<number>(1);
  const [isResting, setIsResting] = useState<boolean>(false);
  const [restTimerSeconds, setRestTimerSeconds] = useState<number>(45);

  const categories = [
    { key: "all", label: "جميع التمارين (21)" },
    { key: "biceps", label: "البايسبس والساعد (3)" },
    { key: "shoulders", label: "الكتف والقوام (3)" },
    { key: "chest", label: "الصدر (3)" },
    { key: "back", label: "الظهر والقطنية (3)" },
    { key: "triceps", label: "الترايسبس (3)" },
    { key: "abs", label: "البطن والكور (3)" },
    { key: "legs", label: "الأرجل والمقعدة (3)" },
  ];

  const filteredExercises =
    selectedCategory === "all"
      ? EXERCISE_LIBRARY
      : EXERCISE_LIBRARY.filter((ex) => ex.category === selectedCategory);

  // Rest Timer Effect
  useEffect(() => {
    if (!isResting) return;

    const interval = setInterval(() => {
      setRestTimerSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsResting(false);
          SpeechEngine.speak("انتهت فترة الراحة! استعد للجولة التالية وحافظ على استقامة ظهرك.");
          spatialAudio.playSpatialPulse();
          return 0;
        }
        if (prev <= 4 && prev > 2) {
          spatialAudio.playCountdown(false);
        } else if (prev === 2) {
          spatialAudio.playCountdown(true);
          HapticEngine.medium();
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isResting]);

  const handleVoiceCue = (exercise: Exercise) => {
    spatialAudio.playClick();
    HapticEngine.tap();
    SpeechEngine.speak(`${exercise.nameAr}. ${exercise.voiceCue}`);
  };

  const handleStartWorkoutSession = (exercise: Exercise) => {
    setWorkoutExercise(exercise);
    setCurrentSet(1);
    setIsResting(false);
    setRestTimerSeconds(exercise.restSeconds);
    setActiveExerciseModal(null);
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();

    if (onHighlightMuscleIn3D) {
      onHighlightMuscleIn3D(exercise.meshHighlightTarget);
    }

    SpeechEngine.speak(`بدء تمرين ${exercise.nameAr}. الجولة الأولى. ${exercise.voiceCue}`);
  };

  const handleCompleteSet = () => {
    if (!workoutExercise) return;

    if (currentSet < workoutExercise.sets) {
      setCurrentSet(currentSet + 1);
      setIsResting(true);
      setRestTimerSeconds(workoutExercise.restSeconds);
      spatialAudio.playRepComplete();
      HapticEngine.repDone();
      SpeechEngine.speak(`أحسنت! جولة ممتازة. خذ راحة لمدة ${workoutExercise.restSeconds} ثانية.`);
    } else {
      // Finished all sets
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
      spatialAudio.playRepComplete();
      HapticEngine.workoutComplete();
      SpeechEngine.speak(`تهانينا! أكملت جميع جولات ${workoutExercise.nameAr} بنجاح وقوة.`);
      setWorkoutExercise(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header Info */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-cyan-500/30 p-4 sm:p-5 shadow-xl backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              مكتبة التمارين الشاملة 2027
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              3 تمارين حقيقية لكل عضلة
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Dumbbell className="w-6 h-6 text-cyan-400" />
            21 تمريناً مخصصاً للتضخيم الصافي وحماية الفقرات
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            تمارين منزلية وبالأحبال والكيبل مع تركيز خاص على تمرين Face Pulls لعلاج القوام، و Supermans و Glute Bridges لحماية ديسك L4-L5.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-cyan-300 bg-slate-950/80 px-3 py-2 rounded-xl border border-cyan-500/20 shrink-0">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>{filteredExercises.length} تمرين متاح</span>
        </div>
      </div>

      {/* Muscle Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.key;
          return (
            <button
              key={cat.key}
              onClick={() => {
                setSelectedCategory(cat.key);
                spatialAudio.playClick();
                HapticEngine.tap();
                if (cat.key !== "all" && onHighlightMuscleIn3D) {
                  onHighlightMuscleIn3D(cat.key);
                }
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all border ${
                isActive
                  ? "bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_12px_rgba(0,243,255,0.25)] font-bold"
                  : "bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Exercises Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredExercises.map((exercise) => {
          const isTherapeutic = exercise.l4l5SafetyRating === "therapeutic";
          const isStrict = exercise.l4l5SafetyRating === "strict_form";

          return (
            <div
              key={exercise.id}
              className={`relative rounded-2xl bg-slate-900/80 border p-4 shadow-lg flex flex-col justify-between transition-all duration-200 hover:border-cyan-500/50 hover:shadow-[0_0_20px_rgba(0,243,255,0.15)] ${
                isTherapeutic
                  ? "border-emerald-500/40 bg-gradient-to-b from-slate-900/90 to-emerald-950/20"
                  : isStrict
                  ? "border-amber-500/30"
                  : "border-slate-800"
              }`}
            >
              <div>
                {/* Badges */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-500/30">
                    {exercise.categoryAr}
                  </span>

                  {isTherapeutic ? (
                    <span className="text-[10px] font-bold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/40 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      علاجي لـ L4-L5
                    </span>
                  ) : isStrict ? (
                    <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/40 flex items-center gap-1">
                      <ShieldAlert className="w-3 h-3 text-amber-400" />
                      تثبيت قطني صارم
                    </span>
                  ) : (
                    <span className="text-[10px] font-medium text-slate-400 bg-slate-950/60 px-2 py-0.5 rounded">
                      آمن تماماً
                    </span>
                  )}
                </div>

                {/* Exercise Title */}
                <h3 className="text-base font-bold text-white mb-0.5">
                  {exercise.nameAr}
                </h3>
                <span className="text-[11px] text-slate-400 font-mono block mb-2">
                  {exercise.nameEn}
                </span>

                {/* Focus description */}
                <p className="text-xs text-slate-300 leading-relaxed line-clamp-2 mb-3">
                  {exercise.focusDescription}
                </p>

                {/* Muscle Tags */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {exercise.targetMuscles.map((muscle, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] bg-slate-950/80 text-slate-300 px-2 py-0.5 rounded-md border border-slate-800"
                    >
                      {muscle}
                    </span>
                  ))}
                </div>

                {/* Inline Animated Biomechanics Player */}
                {expandedAnimationId === exercise.id && (
                  <div className="my-3 rounded-2xl overflow-hidden animate-in fade-in duration-200">
                    <ExerciseVisualizer
                      exerciseId={exercise.id}
                      category={exercise.category}
                      nameAr={exercise.nameAr}
                      nameEn={exercise.nameEn}
                    />
                  </div>
                )}
              </div>

              {/* Bottom Actions & Parameters */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <div className="text-[11px] text-cyan-300 font-mono">
                  <b>{exercise.sets}</b> جولات × <b>{exercise.reps}</b>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      setExpandedAnimationId(expandedAnimationId === exercise.id ? null : exercise.id);
                      spatialAudio.playClick();
                      HapticEngine.tap();
                    }}
                    title={expandedAnimationId === exercise.id ? "إغلاق المحاكاة" : "تشغيل محاكاة الحركة"}
                    className={`p-2 rounded-xl text-xs transition border flex items-center gap-1 ${
                      expandedAnimationId === exercise.id
                        ? "bg-indigo-500/20 text-indigo-300 border-indigo-400 font-bold"
                        : "bg-slate-800/90 hover:bg-indigo-500/20 text-slate-300 hover:text-indigo-300 border-slate-700 hover:border-indigo-400"
                    }`}
                  >
                    <Play className={`w-3.5 h-3.5 ${expandedAnimationId === exercise.id ? "fill-indigo-300" : ""}`} />
                    <span className="text-[10px]">حركة</span>
                  </button>

                  <button
                    onClick={() => handleVoiceCue(exercise)}
                    title="سماع التوجيه الصوتي"
                    className="p-2 rounded-xl bg-slate-800/90 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 border border-slate-700 hover:border-cyan-400 transition text-xs"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      setActiveExerciseModal(exercise);
                      if (onHighlightMuscleIn3D) {
                        onHighlightMuscleIn3D(exercise.meshHighlightTarget);
                      }
                      spatialAudio.playClick();
                      HapticEngine.tap();
                    }}
                    className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/40 text-xs font-bold transition flex items-center gap-1"
                  >
                    <span>التفاصيل</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>

                  <button
                    onClick={() => handleStartWorkoutSession(exercise)}
                    className="p-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 transition text-xs"
                    title="بدء التمرين الآن"
                  >
                    <Play className="w-3.5 h-3.5 fill-emerald-400 text-emerald-400" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Detailed Exercise Guide */}
      {activeExerciseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-cyan-500/40 p-5 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            {/* Close Button */}
            <button
              onClick={() => {
                setActiveExerciseModal(null);
                spatialAudio.playClick();
              }}
              className="absolute top-4 left-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div>
              <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider block mb-1">
                دليل التنفيذ الاحترافي
              </span>
              <h2 className="text-xl font-black text-white">
                {activeExerciseModal.nameAr}
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                {activeExerciseModal.nameEn}
              </span>
            </div>

            {/* Animated Exercise Visualizer (Biomechanical Animation) */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider block">
                محاكاة الحركة الحية والمسار البيوميكانيكي:
              </span>
              <ExerciseVisualizer
                exerciseId={activeExerciseModal.id}
                category={activeExerciseModal.category}
                nameAr={activeExerciseModal.nameAr}
                nameEn={activeExerciseModal.nameEn}
              />
            </div>

            {/* Spine Safety Notice */}
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-cyan-500/20">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-300 mb-1">
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                توجيه حماية الفقرات L4-L5 والعمود الفقري:
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {activeExerciseModal.spineGuidanceAr}
              </p>
            </div>

            {/* Step-by-step Execution */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white uppercase">خطوات الأداء الحركي:</h4>
              {activeExerciseModal.executionSteps.map((step, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5"
                >
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono font-bold flex items-center justify-center shrink-0 text-[11px]">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{step}</span>
                </div>
              ))}
            </div>

            {/* Target Muscles */}
            <div>
              <h4 className="text-xs font-bold text-slate-400 mb-1.5">العضلات المستهدفة:</h4>
              <div className="flex flex-wrap gap-1.5">
                {activeExerciseModal.targetMuscles.map((m, i) => (
                  <span
                    key={i}
                    className="text-xs bg-slate-800/80 text-cyan-300 px-2.5 py-1 rounded-lg border border-cyan-500/20 font-medium"
                  >
                    {m}
                  </span>
                ))}
              </div>
            </div>

            {/* Start Button */}
            <button
              onClick={() => handleStartWorkoutSession(activeExerciseModal)}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 font-black text-sm transition shadow-[0_0_20px_rgba(0,243,255,0.3)] flex items-center justify-center gap-2 hover:opacity-95"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>بدء جلسة التمرين الآن</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Active Workout Session Tracker */}
      {workoutExercise && (
        <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-50 rounded-3xl bg-slate-900/95 border-2 border-emerald-500/60 p-4 shadow-2xl backdrop-blur-xl animate-in slide-in-from-bottom duration-300">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
              <h4 className="text-xs font-bold text-white">جلسة تمرين نشطة</h4>
            </div>
            <button
              onClick={() => {
                setWorkoutExercise(null);
                spatialAudio.playClick();
              }}
              className="text-xs text-slate-400 hover:text-rose-400"
            >
              إنهاء
            </button>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-emerald-300">
                  {workoutExercise.nameAr}
                </h3>
                <span className="text-[11px] text-slate-400 font-mono">
                  الجولة {currentSet} من {workoutExercise.sets} ({workoutExercise.reps})
                </span>
              </div>
              <Award className="w-6 h-6 text-emerald-400" />
            </div>

            {/* Mini Animation inside live session */}
            <div className="rounded-2xl overflow-hidden my-2">
              <ExerciseVisualizer
                exerciseId={workoutExercise.id}
                category={workoutExercise.category}
                nameAr={workoutExercise.nameAr}
                nameEn={workoutExercise.nameEn}
              />
            </div>

            {/* Rest Timer or Action */}
            {isResting ? (
              <div className="p-3 rounded-2xl bg-cyan-950/60 border border-cyan-500/40 text-center space-y-1">
                <div className="text-xs text-cyan-300 flex items-center justify-center gap-1.5 font-bold">
                  <Timer className="w-4 h-4 animate-spin text-cyan-400" />
                  فترة استشفاء وترطيب للفقرات
                </div>
                <div className="text-2xl font-black text-white font-mono">
                  {restTimerSeconds} ثانية
                </div>
              </div>
            ) : (
              <button
                onClick={handleCompleteSet}
                className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition shadow-[0_0_15px_rgba(16,185,129,0.3)] flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {currentSet < workoutExercise.sets
                    ? `إكمال الجولة ${currentSet}`
                    : "إكمال التمرين كاملاً!"}
                </span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
