"use client";

import React, { useEffect, useRef, useState } from "react";
import { Play, Pause, RotateCcw, Activity, ShieldCheck, Sparkles, Zap, Flame, Eye, Volume2 } from "lucide-react";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

interface ExerciseVisualizerProps {
  exerciseId: string;
  category: string;
  nameAr: string;
  nameEn: string;
  isAutoPlay?: boolean;
}

export default function ExerciseVisualizer({
  exerciseId,
  category,
  nameAr,
  nameEn,
  isAutoPlay = true,
}: ExerciseVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(isAutoPlay);
  const [currentPhase, setCurrentPhase] = useState<string>("الانقباض (Concentric)");
  const [repCount, setRepCount] = useState<number>(0);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);

  const phaseRef = useRef<number>(0);
  const repRef = useRef<number>(0);
  const lastDirectionRef = useRef<number>(1);
  const reqRef = useRef<number | null>(null);

  // Type classification for precise biomechanical animation rendering
  const isFacePulls = exerciseId.includes("face-pulls");
  const isOverheadPress = exerciseId.includes("overhead-press") || exerciseId.includes("shoulder-press");
  const isLateralRaise = exerciseId.includes("lateral-raise");
  
  const isPushdown = exerciseId.includes("pushdown") || exerciseId.includes("tricep-pushdown");
  const isTricepExtension = exerciseId.includes("overhead-tricep") || exerciseId.includes("tricep-extension");
  const isDips = exerciseId.includes("dips");
  
  const isBicepCurl = exerciseId.includes("bicep-curl") || exerciseId.includes("hammer-curl");
  const isForearm = exerciseId.includes("forearm");
  
  const isPushupOrPress = exerciseId.includes("pushup") || exerciseId.includes("bench_press") || exerciseId.includes("press");
  const isFlyes = exerciseId.includes("fly");
  
  const isLatPulldown = exerciseId.includes("pulldown") || exerciseId.includes("lat");
  const isRow = exerciseId.includes("row");
  const isSuperman = exerciseId.includes("superman") || exerciseId.includes("extension");
  
  const isGluteBridge = exerciseId.includes("bridge") || exerciseId.includes("glute");
  const isPiriformis = exerciseId.includes("piriformis") || exerciseId.includes("stretch") || exerciseId.includes("floss");
  const isSquat = exerciseId.includes("squat") || exerciseId.includes("lunge");
  
  const isPlank = exerciseId.includes("plank");
  const isDeadBug = exerciseId.includes("dead-bug") || exerciseId.includes("crunch");

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let progress = 0;
    let direction = 1;
    let baseSpeed = 0.022 * speedMultiplier;

    const render = () => {
      if (isPlaying) {
        progress += baseSpeed * direction;
        if (progress >= 1) {
          progress = 1;
          direction = -1;
          setCurrentPhase("الاستطالة والتحكم (Eccentric)");
          if (lastDirectionRef.current !== direction) {
            repRef.current += 1;
            setRepCount(repRef.current);
            spatialAudio.playRepComplete();
            HapticEngine.repDone();
            lastDirectionRef.current = direction;
          }
        } else if (progress <= 0) {
          progress = 0;
          direction = 1;
          setCurrentPhase("الانقباض العضلي (Concentric)");
          lastDirectionRef.current = direction;
        }
      }

      phaseRef.current = progress;

      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      // 1. APEX Obsidian High-Tech Canvas Background
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, "#070b14");
      bgGrad.addColorStop(0.5, "#0b101e");
      bgGrad.addColorStop(1, "#04070e");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // 2. Precision Isometric Cyber Grid
      ctx.strokeStyle = "rgba(0, 240, 255, 0.06)";
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 24) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 24) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Base Platform Floor
      const floorY = h - 38;
      ctx.strokeStyle = "rgba(0, 240, 255, 0.35)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(25, floorY);
      ctx.lineTo(w - 25, floorY);
      ctx.stroke();

      // Platform Glow Ring
      ctx.strokeStyle = "rgba(0, 240, 255, 0.15)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(w / 2, floorY, 140, 18, 0, 0, Math.PI * 2);
      ctx.stroke();

      const cx = w / 2;
      const cy = h / 2;
      const t = progress; // 0 (start) to 1 (peak contraction)

      // Helpers
      const applyGlow = (color: string, blur = 12) => {
        ctx.shadowColor = color;
        ctx.shadowBlur = blur;
      };
      const clearGlow = () => {
        ctx.shadowColor = "transparent";
        ctx.shadowBlur = 0;
      };

      // Draw L4-L5 Lumbar Spine Bio-Protection Marker
      const drawSpineMarker = (x: number, y: number, isSafe = true) => {
        applyGlow(isSafe ? "#10b981" : "#f43f5e", 10);
        ctx.fillStyle = isSafe ? "#10b981" : "#f43f5e";
        ctx.beginPath();
        ctx.arc(x, y, 4.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(x, y, 1.8, 0, Math.PI * 2);
        ctx.fill();
        clearGlow();
      };

      // Draw Active Muscle Target Vector (Cyan/Orange Glow)
      const drawMuscleHighlight = (x1: number, y1: number, x2: number, y2: number, color = "#00f0ff") => {
        applyGlow(color, 16);
        ctx.strokeStyle = color;
        ctx.lineWidth = 7;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        clearGlow();
      };

      // Trajectory Arrow Curve
      const drawMotionVector = (x1: number, y1: number, x2: number, y2: number) => {
        ctx.strokeStyle = "rgba(0, 240, 255, 0.4)";
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        ctx.setLineDash([]);
      };

      // =========================================================================
      // DYNAMIC BIOMECHANICAL ANIMATIONS PER EXERCISE FAMILY
      // =========================================================================

      if (isFacePulls) {
        // --- 1. FACE PULLS (POSTURE RESTORATION & REAR DELTS) ---
        const anchorX = w - 40;
        const anchorY = cy - 25;

        // Pulley station
        ctx.fillStyle = "#1e293b";
        ctx.fillRect(anchorX - 5, 20, 10, h - 55);
        applyGlow("#00f0ff", 8);
        ctx.fillStyle = "#00f0ff";
        ctx.beginPath();
        ctx.arc(anchorX, anchorY, 6, 0, Math.PI * 2);
        ctx.fill();
        clearGlow();

        // Athlete Posture
        const feetX = 85;
        const hipX = 90;
        const hipY = cy + 28;
        const chestX = 100;
        const chestY = cy - 14;
        const headX = 95;
        const headY = cy - 48;

        // Legs (Athletic Base)
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(feetX - 12, floorY);
        ctx.lineTo(feetX + 2, cy + 58);
        ctx.lineTo(hipX, hipY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(feetX + 16, floorY);
        ctx.lineTo(feetX + 22, cy + 58);
        ctx.lineTo(hipX, hipY);
        ctx.stroke();

        // Spine
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(hipX, hipY);
        ctx.lineTo(chestX, chestY);
        ctx.stroke();

        drawSpineMarker(hipX + 2, hipY - 10, true);

        // Head
        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.arc(headX, headY, 11, 0, Math.PI * 2);
        ctx.fill();

        // Dynamic Rope Pull: t=0 (Extended arms forward) -> t=1 (High elbows back to ears)
        const handX = (1 - t) * (anchorX - 35) + t * (headX + 14);
        const handY = (1 - t) * anchorY + t * (headY + 6);
        const elbowX = (1 - t) * (chestX + 32) + t * (chestX - 16);
        const elbowY = (1 - t) * (chestY + 12) + t * (chestY - 18);

        // Rear Delt & Upper Back Activation Glow
        drawMuscleHighlight(chestX, chestY - 5, elbowX, elbowY, "#00f0ff");

        // Forearms to hands
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(elbowX, elbowY);
        ctx.lineTo(handX, handY);
        ctx.stroke();

        // Rope 2 prongs
        ctx.strokeStyle = "#f59e0b";
        ctx.lineWidth = 3;
        applyGlow("#f59e0b", 8);
        ctx.beginPath();
        ctx.moveTo(anchorX, anchorY);
        ctx.lineTo(handX, handY - t * 12);
        ctx.moveTo(anchorX, anchorY);
        ctx.lineTo(handX, handY + t * 12);
        ctx.stroke();
        clearGlow();

        // Handles
        ctx.fillStyle = "#fbbf24";
        ctx.beginPath();
        ctx.arc(handX, handY - t * 12, 4.5, 0, Math.PI * 2);
        ctx.arc(handX, handY + t * 12, 4.5, 0, Math.PI * 2);
        ctx.fill();

      } else if (isPushdown || isTricepExtension) {
        // --- 2. TRICEPS PUSHDOWN & OVERHEAD EXTENSION ---
        const anchorX = cx + 55;
        const anchorY = isPushdown ? 25 : floorY - 10;

        ctx.fillStyle = "#1e293b";
        ctx.fillRect(anchorX - 4, 15, 8, h - 50);
        applyGlow("#00f0ff", 8);
        ctx.fillStyle = "#00f0ff";
        ctx.beginPath();
        ctx.arc(anchorX, anchorY, 6, 0, Math.PI * 2);
        ctx.fill();
        clearGlow();

        const bodyX = cx - 35;
        const headY = cy - 45;
        const chestY = cy - 15;
        const hipY = cy + 28;

        // Legs
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(bodyX - 10, floorY);
        ctx.lineTo(bodyX - 6, cy + 58);
        ctx.lineTo(bodyX, hipY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(bodyX + 12, floorY);
        ctx.lineTo(bodyX + 8, cy + 58);
        ctx.lineTo(bodyX, hipY);
        ctx.stroke();

        // Torso
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(bodyX, hipY);
        ctx.lineTo(bodyX, chestY);
        ctx.stroke();

        drawSpineMarker(bodyX, hipY - 10, true);

        // Head
        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.arc(bodyX, headY, 11, 0, Math.PI * 2);
        ctx.fill();

        const elbowX = bodyX + 12;
        const elbowY = chestY + 12;

        let handX = elbowX + 24;
        let handY = elbowY;

        if (isPushdown) {
          // Angle from -30 deg to +85 deg
          const angle = (1 - t) * (-Math.PI / 4) + t * (Math.PI / 2.1);
          handX = elbowX + Math.cos(angle) * 34;
          handY = elbowY + Math.sin(angle) * 34;
        } else {
          // Overhead Extension: from behind head to overhead extension
          const angle = (1 - t) * (Math.PI * 0.9) + t * (-Math.PI / 3);
          handX = elbowX + Math.cos(angle) * 32;
          handY = (chestY - 18) + Math.sin(angle) * 32;
        }

        // Tricep Upper Arm (Horseshoe Focus Glow)
        drawMuscleHighlight(bodyX, chestY, elbowX, elbowY, "#f97316");

        // Forearm
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(elbowX, elbowY);
        ctx.lineTo(handX, handY);
        ctx.stroke();

        // Cable
        ctx.strokeStyle = "#fbbf24";
        ctx.lineWidth = 2.5;
        applyGlow("#fbbf24", 6);
        ctx.beginPath();
        ctx.moveTo(anchorX, anchorY);
        ctx.lineTo(handX, handY);
        ctx.stroke();
        clearGlow();

        ctx.fillStyle = "#fbbf24";
        ctx.beginPath();
        ctx.arc(handX, handY, 4.5, 0, Math.PI * 2);
        ctx.fill();

      } else if (isBicepCurl || isForearm) {
        // --- 3. BICEPS CURL & FOREARM ---
        const anchorX = cx + 55;
        const anchorY = floorY - 5;

        // Pulley
        ctx.fillStyle = "#1e293b";
        ctx.fillRect(anchorX - 4, 15, 8, h - 50);
        ctx.fillStyle = "#00f0ff";
        ctx.beginPath();
        ctx.arc(anchorX, anchorY, 6, 0, Math.PI * 2);
        ctx.fill();

        const bodyX = cx - 35;
        const headY = cy - 45;
        const chestY = cy - 15;
        const hipY = cy + 28;

        // Legs
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(bodyX - 8, floorY);
        ctx.lineTo(bodyX - 5, cy + 58);
        ctx.lineTo(bodyX, hipY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(bodyX + 12, floorY);
        ctx.lineTo(bodyX + 9, cy + 58);
        ctx.lineTo(bodyX, hipY);
        ctx.stroke();

        // Spine
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(bodyX, hipY);
        ctx.lineTo(bodyX, chestY);
        ctx.stroke();

        drawSpineMarker(bodyX, hipY - 10, true);

        // Head
        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.arc(bodyX, headY, 11, 0, Math.PI * 2);
        ctx.fill();

        const elbowX = bodyX + 10;
        const elbowY = chestY + 14;

        // Curl: hand from low extended to high chest
        const angle = (1 - t) * (Math.PI / 2) + t * (-Math.PI / 3);
        const handX = elbowX + Math.cos(angle) * 32;
        const handY = elbowY + Math.sin(angle) * 32;

        // Bicep Peak Glow
        drawMuscleHighlight(bodyX, chestY, elbowX, elbowY, "#00f0ff");

        // Forearm
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(elbowX, elbowY);
        ctx.lineTo(handX, handY);
        ctx.stroke();

        // Cable
        ctx.strokeStyle = "#fbbf24";
        ctx.lineWidth = 2.5;
        applyGlow("#fbbf24", 6);
        ctx.beginPath();
        ctx.moveTo(anchorX, anchorY);
        ctx.lineTo(handX, handY);
        ctx.stroke();
        clearGlow();

        ctx.fillStyle = "#fbbf24";
        ctx.beginPath();
        ctx.arc(handX, handY, 4.5, 0, Math.PI * 2);
        ctx.fill();

      } else if (isPushupOrPress || isFlyes) {
        // --- 4. BENCH PRESS / INCLINE FLYES / PUSHUPS ---
        const benchY = cy + 20;
        const benchW = 160;

        // Flat/Incline Bench
        ctx.strokeStyle = "#334155";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(cx - benchW / 2, benchY);
        ctx.lineTo(cx + benchW / 2, benchY);
        ctx.stroke();

        // Bench legs
        ctx.strokeStyle = "#1e293b";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(cx - benchW / 2 + 15, benchY);
        ctx.lineTo(cx - benchW / 2 + 15, floorY);
        ctx.moveTo(cx + benchW / 2 - 15, benchY);
        ctx.lineTo(cx + benchW / 2 - 15, floorY);
        ctx.stroke();

        // Athlete Lying Down
        const headX = cx - 55;
        const headY = benchY - 12;
        const chestX = cx - 20;
        const chestY = benchY - 8;
        const hipX = cx + 30;
        const hipY = benchY - 8;

        // Torso
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 7;
        ctx.beginPath();
        ctx.moveTo(headX + 12, headY);
        ctx.lineTo(hipX, hipY);
        ctx.stroke();

        // Feet grounded
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(hipX, hipY);
        ctx.lineTo(hipX + 25, benchY + 15);
        ctx.lineTo(hipX + 30, floorY);
        ctx.stroke();

        drawSpineMarker(hipX - 10, hipY - 2, true);

        // Head
        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.arc(headX, headY, 10, 0, Math.PI * 2);
        ctx.fill();

        // Dumbbells / Bar Press: from chest level (t=0) to lock (t=1)
        const pressY = (1 - t) * (chestY - 10) + t * (chestY - 55);
        const elbowX = (1 - t) * (chestX - 15) + t * (chestX - 2);
        const elbowY = (1 - t) * (chestY + 8) + t * (chestY - 25);

        // Chest Plate Glow
        drawMuscleHighlight(headX + 12, headY + 5, chestX + 10, chestY, "#00f0ff");

        // Arm
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(chestX, chestY);
        ctx.lineTo(elbowX, elbowY);
        ctx.lineTo(chestX, pressY);
        ctx.stroke();

        // Bar / Dumbbell
        ctx.strokeStyle = "#f59e0b";
        ctx.lineWidth = 4;
        applyGlow("#f59e0b", 10);
        ctx.beginPath();
        ctx.moveTo(chestX - 20, pressY);
        ctx.lineTo(chestX + 20, pressY);
        ctx.stroke();
        clearGlow();

      } else if (isGluteBridge) {
        // --- 5. GLUTE BRIDGE (L4-L5 DECOMPRESSION & GLUTE MAXIMUS) ---
        const groundY = floorY - 10;
        const shoulderX = cx - 65;
        const shoulderY = groundY - 10;
        const feetX = cx + 55;
        const feetY = groundY;

        // Dynamic Hip Thrust: t=0 (Hips down on mat) -> t=1 (Straight 180 deg plank bridge)
        const hipX = cx - 5;
        const hipY = (1 - t) * (groundY - 5) + t * (groundY - 45);
        const kneeX = cx + 38;
        const kneeY = (1 - t) * (groundY - 30) + t * (groundY - 48);

        // Head & Mat
        ctx.fillStyle = "#1e293b";
        ctx.fillRect(shoulderX - 35, groundY + 4, 150, 6);

        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.arc(shoulderX - 16, shoulderY, 11, 0, Math.PI * 2);
        ctx.fill();

        // Torso / Spine
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 7;
        ctx.beginPath();
        ctx.moveTo(shoulderX, shoulderY);
        ctx.lineTo(hipX, hipY);
        ctx.stroke();

        // Glute / Hamstrings Active Vector Glow
        drawMuscleHighlight(hipX, hipY, kneeX, kneeY, "#10b981");

        // Lower Leg (Knee to Foot)
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(kneeX, kneeY);
        ctx.lineTo(feetX, feetY);
        ctx.stroke();

        // L4-L5 Decompression Marker (Always Green & Safe)
        drawSpineMarker(hipX - 12, hipY, true);

      } else if (isPiriformis) {
        // --- 6. PIRIFORMIS STRETCH & SCIATIC NERVE FLOSS ---
        const groundY = floorY - 15;
        const headX = cx - 60;
        const headY = groundY - 12;
        const hipX = cx + 10;
        const hipY = groundY - 8;

        // Torso Flat
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(headX + 12, headY);
        ctx.lineTo(hipX, hipY);
        ctx.stroke();

        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.arc(headX, headY, 11, 0, Math.PI * 2);
        ctx.fill();

        // Dynamic Cross-Leg stretch pulse
        const kneeX = hipX - 15 + t * 8;
        const kneeY = groundY - 38 - t * 14;
        const footX = hipX + 22;
        const footY = groundY - 22;

        // Thigh
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(hipX, hipY);
        ctx.lineTo(kneeX, kneeY);
        ctx.stroke();

        // Crossed Leg (Sciatic Nerve release)
        drawMuscleHighlight(kneeX, kneeY, footX, footY, "#f43f5e");

        drawSpineMarker(hipX, hipY - 6, true);

      } else {
        // --- 7. GENERAL SQUAT / ROW / CORE PULL ---
        const bodyX = cx;
        const squatDepth = t * 24;

        const hipY = cy + 18 + squatDepth;
        const chestY = cy - 20 + squatDepth * 0.8;
        const headY = cy - 48 + squatDepth * 0.8;

        // Legs
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(bodyX - 25, floorY);
        ctx.lineTo(bodyX - 35, hipY + 12);
        ctx.lineTo(bodyX, hipY);
        ctx.lineTo(bodyX + 35, hipY + 12);
        ctx.lineTo(bodyX + 25, floorY);
        ctx.stroke();

        // Torso
        drawMuscleHighlight(bodyX, hipY, bodyX, chestY, "#00f0ff");

        drawSpineMarker(bodyX, hipY - 8, true);

        // Head
        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath();
        ctx.arc(bodyX, headY, 11, 0, Math.PI * 2);
        ctx.fill();
      }

      reqRef.current = requestAnimationFrame(render);
    };

    reqRef.current = requestAnimationFrame(render);

    return () => {
      if (reqRef.current) cancelAnimationFrame(reqRef.current);
    };
  }, [isPlaying, speedMultiplier, exerciseId, isFacePulls, isPushdown, isTricepExtension, isBicepCurl, isForearm, isPushupOrPress, isFlyes, isGluteBridge, isPiriformis]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  const resetAnimation = () => {
    phaseRef.current = 0;
    repRef.current = 0;
    setRepCount(0);
    setIsPlaying(true);
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  const handleVoiceExplanation = () => {
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    SpeechEngine.speak(
      `تمرين ${nameAr}. المرحلة الحالية: ${currentPhase}. حافظ على استقامة العمود الفقري وتثبيت الحوض لحماية الفقرات القطنية L4-L5.`
    );
  };

  return (
    <div className="w-full rounded-3xl bg-[#090d16] border border-slate-800/90 overflow-hidden shadow-2xl flex flex-col backdrop-blur-xl">
      {/* Top Header Bar */}
      <div className="px-4 py-3 bg-[#0d1220] border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-[#00f0ff]/15 border border-[#00f0ff]/40 flex items-center justify-center text-[#00f0ff]">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white font-mono">{nameEn}</h4>
            <span className="text-[10px] text-slate-400">{nameAr}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleVoiceExplanation}
            className="p-1.5 px-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 hover:text-[#00f0ff] transition flex items-center gap-1 text-[10px] font-mono"
            title="شرح صوتي للحركة"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>شرح صوتي</span>
          </button>

          {/* Speed switch */}
          <button
            onClick={() => {
              setSpeedMultiplier((prev) => (prev === 1 ? 1.5 : prev === 1.5 ? 0.75 : 1));
              spatialAudio.playClick();
              HapticEngine.tap();
            }}
            className="p-1.5 px-2 rounded-xl bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-300 hover:text-[#00f0ff] transition"
            title="سرعة المحاكاة"
          >
            {speedMultiplier}x
          </button>
        </div>
      </div>

      {/* Canvas Biomechanical Viewport */}
      <div className="relative w-full h-56 sm:h-64 bg-[#070b14] flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          width={420}
          height={260}
          className="w-full h-full object-contain cursor-pointer"
          onClick={togglePlay}
        />

        {/* Top Left Bio-Status Badge */}
        <div className="absolute top-3 left-3 bg-[#090d16]/95 border border-[#00f0ff]/40 px-2.5 py-1 rounded-xl text-[10px] font-mono text-[#00f0ff] flex items-center gap-1.5 backdrop-blur-md shadow-lg">
          <span className="w-2 h-2 rounded-full bg-[#00f0ff] animate-ping" />
          <span>BIOMECHANICAL MOTION 3D</span>
        </div>

        {/* Top Right Live Rep Counter */}
        <div className="absolute top-3 right-3 bg-[#090d16]/95 border border-slate-800 px-3 py-1 rounded-xl text-xs font-mono text-slate-300 flex items-center gap-1.5 shadow-lg backdrop-blur-md">
          <Flame className="w-3.5 h-3.5 text-orange-400" />
          <span>العدّاد:</span>
          <b className="text-white text-sm font-black text-[#00f0ff]">{repCount}</b>
        </div>

        {/* Bottom Phase Indicator */}
        <div className="absolute bottom-3 right-3 bg-[#090d16]/95 border border-slate-800/90 px-3 py-1.5 rounded-xl text-[11px] text-slate-200 font-medium backdrop-blur-md flex items-center gap-1.5 shadow-lg">
          <Activity className="w-3.5 h-3.5 text-[#00f0ff] animate-pulse" />
          <span>{currentPhase}</span>
        </div>

        {/* L4-L5 Spine Telemetry Indicator */}
        <div className="absolute bottom-3 left-3 bg-emerald-950/90 border border-emerald-500/40 px-2.5 py-1 rounded-xl text-[10px] font-mono text-emerald-300 flex items-center gap-1.5 backdrop-blur-md shadow-lg">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>L4-L5: محمي بالكامل ✓</span>
        </div>
      </div>

      {/* Controller & Action Toolbar */}
      <div className="p-3 bg-[#0d1220] border-t border-slate-800/80 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={togglePlay}
            className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-bold transition flex items-center gap-1.5 ${
              isPlaying
                ? "bg-[#00f0ff]/15 text-[#00f0ff] border-[#00f0ff]/40 shadow-[0_0_12px_rgba(0,240,255,0.2)]"
                : "bg-emerald-500/15 text-emerald-300 border-emerald-500/40"
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-[#00f0ff]" />
                <span>إيقاف مؤقت</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-emerald-300" />
                <span>تشغيل الحركة</span>
              </>
            )}
          </button>

          <button
            onClick={resetAnimation}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-xs transition"
            title="إعادة تعيين العداد"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="text-right">
          <span className="text-[10px] text-slate-400 font-mono block">التوجيه الحركي</span>
          <span className="text-[11px] text-[#00f0ff] font-bold">عصر كامل ونزول متحكم</span>
        </div>
      </div>
    </div>
  );
}
