"use client";

import React, { useState, useEffect, useMemo } from "react";
import Image from "next/image";
import {
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  Copy,
  Check,
  FileJson,
  Sparkles,
  Utensils,
  Dumbbell,
  Droplet,
  Save,
  Activity,
  Zap,
  Flame,
  Volume2,
  Eye,
  Plus,
  Minus,
} from "lucide-react";
import confetti from "canvas-confetti";
import {
  INITIAL_TODAY_PROGRAM,
  ProgramStep,
} from "@/lib/data";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";
import { fetchJsonBinData, saveJsonBinData, AppSyncState } from "@/lib/jsonbinSync";
import Svg2DMuscleViewer from "@/components/Svg2DMuscleViewer";
import ThreeMuscleViewer from "@/components/ThreeMuscleViewer";

interface DailySmartRoutineProps {
  onNavigateTab?: (tabId: string) => void;
  onSelectMuscleTarget?: (muscleKey: string) => void;
}

export default function DailySmartRoutine({
  onNavigateTab,
}: DailySmartRoutineProps) {
  // Master steps state
  const [programSteps, setProgramSteps] = useState<ProgramStep[]>(() => INITIAL_TODAY_PROGRAM);
  const [weightKg, setWeightKg] = useState<number>(60.5);
  const [stepsCount, setStepsCount] = useState<number>(8450);
  const [waterMl, setWaterMl] = useState<number>(3000);
  const [painScore, setPainScore] = useState<number>(1);
  const [notes, setNotes] = useState<string>(
    "تمارين الحبل Face Pulls أزالت التشنج تماماً، ولا يوجد أي ألم بعرق النسا مع المشي في صلالة."
  );

  const [copied, setCopied] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<string>("تمت المزامنة مع JSONBin");
  const [lastSyncTime, setLastSyncTime] = useState<string>("");
  const [activeSubTab, setActiveSubTab] = useState<"visual-dashboard" | "schedule" | "jsonbin-raw">("visual-dashboard");

  // Load from JSONBin / LocalStorage on mount
  useEffect(() => {
    let isMounted = true;
    const initData = async () => {
      setIsSyncing(true);
      const remote = await fetchJsonBinData();
      if (isMounted && remote && remote.todayProgram) {
        if (remote.todayProgram.steps && remote.todayProgram.steps.length > 0) {
          const merged = INITIAL_TODAY_PROGRAM.map((initStep) => {
            const found = remote.todayProgram.steps.find((s) => s.id === initStep.id);
            return found ? { ...initStep, isCompleted: found.isCompleted } : initStep;
          });
          setProgramSteps(merged);
        }
        if (remote.todayProgram.weightKg) setWeightKg(remote.todayProgram.weightKg);
        if (remote.todayProgram.stepsCount) setStepsCount(remote.todayProgram.stepsCount);
        if (remote.todayProgram.waterMl) setWaterMl(remote.todayProgram.waterMl);
        if (remote.todayProgram.painScore !== undefined) setPainScore(remote.todayProgram.painScore);
        if (remote.todayProgram.notes) setNotes(remote.todayProgram.notes);
        setSyncStatus("تم تحميل أحدث بيانات من JSONBin ✓");
        setLastSyncTime(new Date().toLocaleTimeString("ar-EG"));
      }
      setIsSyncing(false);
    };

    initData();

    const handleSyncSuccess = (e: CustomEvent) => {
      setSyncStatus("تم الحفظ في JSONBin ✓");
      setLastSyncTime(e.detail?.timestamp || new Date().toLocaleTimeString("ar-EG"));
    };
    window.addEventListener("apex-jsonbin-sync-success" as unknown as never, handleSyncSuccess as never);

    return () => {
      isMounted = false;
      window.removeEventListener("apex-jsonbin-sync-success" as unknown as never, handleSyncSuccess as never);
    };
  }, []);

  // Sync to JSONBin whenever any key variable changes
  const triggerAutoSync = (
    updatedSteps = programSteps,
    currentWeight = weightKg,
    currentSteps = stepsCount,
    currentWater = waterMl,
    currentPain = painScore,
    currentNotes = notes
  ) => {
    const payload: AppSyncState = {
      todayProgram: {
        steps: updatedSteps.map((s) => ({
          id: s.id,
          timeSlot: s.timeSlot,
          titleAr: s.titleAr,
          category: s.category,
          descriptionAr: s.descriptionAr,
          calorieImpact: s.calorieImpact,
          proteinImpact: s.proteinImpact,
          isCompleted: s.isCompleted,
          actionTab: s.actionTab,
          badge: s.badge,
        })),
        weightKg: currentWeight,
        stepsCount: currentSteps,
        waterMl: currentWater,
        painScore: currentPain,
        notes: currentNotes,
        lastUpdated: new Date().toISOString(),
      },
    };
    saveJsonBinData(payload, false);
  };

  const completedStepsCount = programSteps.filter((s) => s.isCompleted).length;
  const progressPercent = Math.round((completedStepsCount / programSteps.length) * 100);

  // Identify the NEXT uncompleted action / meal
  const nextAction = useMemo(() => {
    const uncompleted = programSteps.find((s) => !s.isCompleted);
    return uncompleted || programSteps[programSteps.length - 1];
  }, [programSteps]);

  // Next meal specifically
  const nextMeal = useMemo(() => {
    return (
      programSteps.find((s) => s.category === "meal" && !s.isCompleted) ||
      programSteps.find((s) => s.category === "meal")
    );
  }, [programSteps]);

  // Next workout action specifically
  const nextWorkout = useMemo(() => {
    return (
      programSteps.find((s) => s.category === "workout" && !s.isCompleted) ||
      programSteps.find((s) => s.category === "workout")
    );
  }, [programSteps]);

  const toggleStep = (id: string) => {
    const updated = programSteps.map((step) => {
      if (step.id === id) {
        const nextState = !step.isCompleted;
        if (nextState) {
          spatialAudio.playRepComplete();
          HapticEngine.success();
          if (completedStepsCount + 1 === programSteps.length) {
            confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
          }
        } else {
          spatialAudio.playClick();
          HapticEngine.tap();
        }
        return { ...step, isCompleted: nextState };
      }
      return step;
    });

    setProgramSteps(updated);
    triggerAutoSync(updated);
  };

  const handleManualSave = async () => {
    setIsSyncing(true);
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    const payload: AppSyncState = {
      todayProgram: {
        steps: programSteps,
        weightKg,
        stepsCount,
        waterMl,
        painScore,
        notes,
        lastUpdated: new Date().toISOString(),
      },
    };
    const ok = await saveJsonBinData(payload, true);
    setIsSyncing(false);
    if (ok) {
      setSyncStatus("تم الحفظ الفوري في السحابة بنجاح ✓");
      setLastSyncTime(new Date().toLocaleTimeString("ar-EG"));
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    }
  };

  const handleWaterChange = (delta: number) => {
    const newWater = Math.max(0, Math.min(6000, waterMl + delta));
    setWaterMl(newWater);
    spatialAudio.playWaterDrop();
    HapticEngine.tap();
    triggerAutoSync(programSteps, weightKg, stepsCount, newWater, painScore, notes);
  };

  const handleCopyJSON = () => {
    const data = {
      binId: "6a97dc6bda38895dfe2e721e",
      date: new Date().toISOString(),
      athlete: "Ashraf (60.5 kg - L4-L5 Protection Protocol)",
      metrics: { weightKg, stepsCount, waterMl, painScore, progressPercent },
      schedule: programSteps,
    };
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    setCopied(true);
    spatialAudio.playClick();
    HapticEngine.tap();
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadJSON = () => {
    const data = {
      binId: "6a97dc6bda38895dfe2e721e",
      date: new Date().toISOString(),
      athlete: "Ashraf (60.5 kg - L4-L5 Protection Protocol)",
      metrics: { weightKg, stepsCount, waterMl, painScore, progressPercent },
      schedule: programSteps,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `apex-today-program-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  const handleVoiceTodaySummary = () => {
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    SpeechEngine.speak(
      `برنامج اليوم: إجمالي الإنجاز ${progressPercent} بالمائة. الأكشن التالي: ${nextAction?.titleAr} في تمام الساعة ${nextAction?.timeSlot}. بروتوكول حماية L4-L5 نشط ومعدل شرب الماء الحالي ${waterMl} ملليلتر.`
    );
  };

  return (
    <div className="space-y-6" id="apex-today-program-master">
      {/* 1. TOP HEADER & CLOUD JSONBIN STATUS BAR */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-[#090d16] border border-slate-800/90 p-4 sm:p-5 rounded-3xl gap-4 backdrop-blur-xl shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 flex items-center justify-center text-[#00f0ff] shadow-[0_0_15px_rgba(0,240,255,0.25)]">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black font-mono tracking-tight text-white">
                APEX FITNESS <span className="text-[#00f0ff]">TODAY&apos;S PROGRAM</span>
              </h2>
              <span className="text-[10px] font-mono bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/40 px-2 py-0.5 rounded-full font-bold">
                الواجهة الرئيسية التفاعلية
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 font-mono mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>JSONBin ID: 6a97dc6bda38895dfe2e721e</span>
              {lastSyncTime && <span className="text-slate-500">• آخر مزامنة: {lastSyncTime}</span>}
            </div>
          </div>
        </div>

        {/* Action Buttons & Subtab Nav */}
        <div className="flex items-center gap-2 flex-wrap self-end md:self-auto">
          <button
            onClick={handleVoiceTodaySummary}
            className="p-2 px-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 hover:text-[#00f0ff] transition flex items-center gap-1.5 text-xs font-mono"
            title="سماع ملخص اليوم صوتياً"
          >
            <Volume2 className="w-4 h-4" />
            <span>ملخص صوتي</span>
          </button>

          <button
            onClick={handleManualSave}
            disabled={isSyncing}
            className="p-2 px-3 rounded-2xl bg-[#00f0ff]/20 border border-[#00f0ff]/50 text-[#00f0ff] hover:bg-[#00f0ff]/30 font-mono text-xs font-bold transition flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,240,255,0.2)]"
          >
            <Save className={`w-4 h-4 ${isSyncing ? "animate-spin" : ""}`} />
            <span>{isSyncing ? "جاري الحفظ..." : "حفظ سحابي فوري"}</span>
          </button>

          {/* Sub-tabs */}
          <div className="bg-slate-900 border border-slate-800 p-1 rounded-2xl flex items-center">
            <button
              onClick={() => setActiveSubTab("visual-dashboard")}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
                activeSubTab === "visual-dashboard"
                  ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              الواجهة البصرية
            </button>
            <button
              onClick={() => setActiveSubTab("schedule")}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
                activeSubTab === "schedule"
                  ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              الجدول ({completedStepsCount}/{programSteps.length})
            </button>
            <button
              onClick={() => setActiveSubTab("jsonbin-raw")}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
                activeSubTab === "jsonbin-raw"
                  ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              بيانات JSONBin
            </button>
          </div>
        </div>
      </div>

      {/* 2. HERO VISUAL SHOWCASE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* LEFT COLUMN: NEXT UPCOMING MEAL & WORKOUT HERO */}
        <div className="lg:col-span-7 space-y-5">
          {/* Card A: NEXT UPCOMING MEAL */}
          <div className="relative rounded-3xl bg-[#090d16] border border-slate-800/90 overflow-hidden shadow-2xl p-5 backdrop-blur-xl group">
            <div className="absolute top-0 right-0 w-60 h-60 bg-amber-500/10 rounded-full blur-[80px] pointer-events-none" />

            <div className="relative z-10 flex items-center justify-between pb-3 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
                <span className="text-xs font-black font-mono uppercase tracking-wider text-amber-400">
                  NEXT MEAL • الوجبة القادمة
                </span>
              </div>
              <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#00f0ff]" />
                {nextMeal?.timeSlot || "12:30 PM"}
              </span>
            </div>

            {/* Meal Hero Split */}
            <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4 pt-4">
              <div className="relative w-full sm:w-44 h-36 rounded-2xl overflow-hidden border border-slate-700/80 shadow-lg flex-shrink-0 bg-slate-950">
                <Image
                  src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80"
                  alt={nextMeal?.titleAr || "Next Meal"}
                  fill
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <span className="absolute bottom-2 left-2 text-[10px] font-mono font-bold bg-[#00f0ff] text-slate-950 px-2 py-0.5 rounded">
                  {nextMeal?.calorieImpact || 680} kcal
                </span>
              </div>

              <div className="flex-1 space-y-2.5 w-full">
                <div>
                  <h3 className="text-base font-black text-white">{nextMeal?.titleAr}</h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-0.5">
                    {nextMeal?.descriptionAr}
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono">
                  <div className="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block">بروتين</span>
                    <b className="text-[#00f0ff] text-xs font-bold">{nextMeal?.proteinImpact || 45}g</b>
                  </div>
                  <div className="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block">كارب</span>
                    <b className="text-orange-400 text-xs font-bold">55g</b>
                  </div>
                  <div className="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block">دهون صحية</span>
                    <b className="text-emerald-400 text-xs font-bold">14g</b>
                  </div>
                </div>

                <button
                  onClick={() => nextMeal && toggleStep(nextMeal.id)}
                  className={`w-full py-2 px-4 rounded-xl font-mono text-xs font-bold transition flex items-center justify-center gap-2 ${
                    nextMeal?.isCompleted
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : "bg-[#00f0ff] text-slate-950 hover:bg-[#00f0ff]/90 shadow-[0_0_15px_rgba(0,240,255,0.4)]"
                  }`}
                >
                  {nextMeal?.isCompleted ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>تم تناول الوجبة بنجاح ✓</span>
                    </>
                  ) : (
                    <>
                      <Utensils className="w-4 h-4" />
                      <span>تأكيد تناول الوجبة الآن</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Card B: NEXT UPCOMING WORKOUT ACTION */}
          <div className="relative rounded-3xl bg-[#090d16] border border-slate-800/90 overflow-hidden shadow-2xl p-5 backdrop-blur-xl">
            <div className="absolute top-0 left-0 w-60 h-60 bg-[#00f0ff]/10 rounded-full blur-[80px] pointer-events-none" />

            <div className="relative z-10 flex items-center justify-between pb-3 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#00f0ff] animate-ping" />
                <span className="text-xs font-black font-mono uppercase tracking-wider text-[#00f0ff]">
                  NEXT ACTION • تمرين الجولة القادمة
                </span>
              </div>
              <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#00f0ff]" />
                {nextWorkout?.timeSlot || "05:30 PM"}
              </span>
            </div>

            <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-md bg-[#00f0ff]/15 text-[#00f0ff] font-mono text-[10px] font-bold border border-[#00f0ff]/30">
                    {nextWorkout?.badge || "تضخيم وبناء"}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                    L4-L5 SAFE
                  </span>
                </div>
                <h3 className="text-base font-black text-white">{nextWorkout?.titleAr}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {nextWorkout?.descriptionAr}
                </p>
              </div>

              <div className="flex flex-col gap-2 w-full sm:w-auto flex-shrink-0">
                <button
                  onClick={() => onNavigateTab && onNavigateTab("exercises")}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/60 text-white font-mono text-xs font-bold transition flex items-center justify-center gap-2"
                >
                  <Dumbbell className="w-4 h-4 text-[#00f0ff]" />
                  <span>فتح محاكي التمارين (21)</span>
                </button>
                <button
                  onClick={() => nextWorkout && toggleStep(nextWorkout.id)}
                  className={`px-4 py-2.5 rounded-xl font-mono text-xs font-bold transition flex items-center justify-center gap-2 ${
                    nextWorkout?.isCompleted
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : "bg-[#00f0ff] text-slate-950 hover:bg-[#00f0ff]/90 shadow-[0_0_15px_rgba(0,240,255,0.4)]"
                  }`}
                >
                  {nextWorkout?.isCompleted ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>تم إنجاز الجولة ✓</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>تسجيل إنجاز التمرين الآن</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: 3D TARGET HOLOGRAM + WATER TRACKER */}
        <div className="lg:col-span-5 space-y-5">
          {/* Card C: 2D ANATOMICAL SVG PREVIEW */}
          <div className="rounded-3xl bg-[#090d16] border border-slate-800/90 p-4 shadow-2xl backdrop-blur-xl flex flex-col justify-between">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-[#00f0ff]/15 border border-[#00f0ff]/40 flex items-center justify-center text-[#00f0ff]">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs font-bold text-white font-mono">
                  TARGET: CHEST & TRICEPS 2D SVG
                </span>
              </div>
              <button
                onClick={() => onNavigateTab && onNavigateTab("3d-anatomy")}
                className="text-[10px] font-mono text-[#00f0ff] hover:underline flex items-center gap-1"
              >
                <span>تكبير التشريح</span>
                <Eye className="w-3 h-3" />
              </button>
            </div>

            <div className="w-full my-1 rounded-2xl overflow-hidden bg-slate-950 border border-slate-800/80 p-2">
              <Svg2DMuscleViewer
                activeMuscleTarget="chest_triceps"
                showCardGrid={false}
                compactMode={true}
              />
            </div>

            <div className="flex items-center justify-between text-[10px] font-mono pt-2 text-slate-400 border-t border-slate-800/80">
              <span className="text-emerald-400">L4-L5: حماية قطنية نشطة</span>
              <span className="text-[#00f0ff]">تضخيم الصدر والترايسبس</span>
            </div>
          </div>

          {/* Card D: WATER INTAKE & HYDRATION TRACKER */}
          <div className="rounded-3xl bg-[#090d16] border border-slate-800/90 p-4 shadow-2xl backdrop-blur-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Droplet className="w-4 h-4 text-[#00f0ff]" />
                <span className="text-xs font-bold text-white font-mono">
                  HYDRATION TRACKER (معدل شرب الماء)
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-[#00f0ff]">
                {waterMl} / 3,500 ml
              </span>
            </div>

            <div className="w-full h-3 rounded-full bg-slate-900 border border-slate-800 overflow-hidden p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#00f0ff] to-blue-500 shadow-[0_0_10px_rgba(0,240,255,0.5)] transition-all duration-300"
                style={{ width: `${Math.min(100, (waterMl / 3500) * 100)}%` }}
              />
            </div>

            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                onClick={() => handleWaterChange(-250)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs font-mono transition flex items-center gap-1"
              >
                <Minus className="w-3.5 h-3.5" />
                <span>250ml</span>
              </button>
              <button
                onClick={() => handleWaterChange(250)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-200 hover:text-[#00f0ff] text-xs font-mono transition flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+250ml</span>
              </button>
              <button
                onClick={() => handleWaterChange(500)}
                className="px-3 py-1.5 rounded-xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 text-[#00f0ff] text-xs font-mono font-bold transition flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+500ml</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3. SUB-VIEW: INTERACTIVE SCHEDULE OR JSONBIN VIEWER */}
      {activeSubTab === "schedule" && (
        <div className="rounded-3xl bg-[#090d16] border border-slate-800/90 p-5 shadow-2xl backdrop-blur-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#00f0ff]" />
              الجدول الزمني التفاعلي لليوم (Daily Schedule)
            </h3>
            <span className="text-xs font-mono text-[#00f0ff]">
              الإنجاز: {progressPercent}% ({completedStepsCount}/{programSteps.length})
            </span>
          </div>

          <div className="space-y-2.5">
            {programSteps.map((step) => (
              <div
                key={step.id}
                onClick={() => toggleStep(step.id)}
                className={`flex items-start justify-between p-3.5 rounded-2xl border cursor-pointer transition-all duration-200 ${
                  step.isCompleted
                    ? "bg-[#00f0ff]/10 border-[#00f0ff]/40 text-white"
                    : "bg-slate-900/60 border-slate-800/80 text-slate-300 hover:border-slate-700"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-5 h-5 rounded-lg flex items-center justify-center mt-0.5 transition ${
                      step.isCompleted
                        ? "bg-[#00f0ff] text-slate-950"
                        : "border border-slate-700 bg-slate-950 text-transparent"
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold font-mono text-[#00f0ff]">
                        {step.timeSlot}
                      </span>
                      <span className="text-slate-600">|</span>
                      <span className="text-xs font-bold text-white">{step.titleAr}</span>
                    </div>
                    <p className="text-xs text-slate-400">{step.descriptionAr}</p>
                  </div>
                </div>

                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 flex-shrink-0">
                  {step.badge || step.category}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === "jsonbin-raw" && (
        <div className="rounded-3xl bg-[#090d16] border border-slate-800/90 p-5 shadow-2xl backdrop-blur-xl space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
            <div>
              <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                <FileJson className="w-4 h-4 text-[#00f0ff]" />
                مخطط JSONBin السحابي المباشر
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Bin ID: 6a97dc6bda38895dfe2e721e
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyJSON}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 hover:text-[#00f0ff] text-xs font-mono transition flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? "تم النسخ!" : "نسخ JSON"}</span>
              </button>
              <button
                onClick={handleDownloadJSON}
                className="px-3 py-1.5 rounded-xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 text-[#00f0ff] text-xs font-mono font-bold transition flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تنزيل الملف</span>
              </button>
            </div>
          </div>

          <pre className="p-4 rounded-2xl bg-black/80 border border-slate-800 text-emerald-400 font-mono text-xs overflow-x-auto max-h-96 leading-relaxed">
            {JSON.stringify(
              {
                jsonbinConfig: {
                  binId: "6a97dc6bda38895dfe2e721e",
                  masterKey: "$2a$10$SYrYv.ct8hiMU9YeUxEQ.ecRkOrTqs.TDchJRV3wW.aKJnDXy2oVy",
                  accessKey: "$2a$10$J8o3WrPtnqmKAd///uDw6.BOWnGIBekHFOImbeEZZwsJ/h/XPbVUy",
                  endpoint: "https://api.jsonbin.io/v3/b/6a97dc6bda38895dfe2e721e",
                },
                athlete: {
                  name: "Ashraf (أشرف)",
                  targetWeightKg: 65,
                  currentWeightKg: weightKg,
                  dailySteps: stepsCount,
                  waterIntakeMl: waterMl,
                  painScoreL4L5: painScore,
                  progressPercent,
                },
                todaySchedule: programSteps,
              },
              null,
              2
            )}
          </pre>
        </div>
      )}
    </div>
  );
}
