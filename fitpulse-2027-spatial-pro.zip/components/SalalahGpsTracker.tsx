"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  MapPin,
  Navigation,
  Footprints,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Volume2,
  Compass,
  Activity,
  Award,
  Flame,
  Gauge,
  Mountain,
  Heart,
  VolumeX,
  Radio,
  LocateFixed,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react";
import confetti from "canvas-confetti";
import { SALALAH_ROUTES, SalalahRoute } from "@/lib/data";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

// Accurate Earth distance in Kilometers
function calculateHaversineDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export default function SalalahGpsTracker() {
  const [selectedRoute, setSelectedRoute] = useState<SalalahRoute>(SALALAH_ROUTES[0]);
  const [isTracking, setIsTracking] = useState<boolean>(false);
  const [gpsMode, setGpsMode] = useState<"real-device" | "salalah-sim">("real-device");

  // GPS Metrics
  const [steps, setSteps] = useState<number>(0);
  const [distanceKm, setDistanceKm] = useState<number>(0);
  const [currentSpeedKmh, setCurrentSpeedKmh] = useState<number>(0);
  const [cadenceSpm, setCadenceSpm] = useState<number>(0);
  const [elevationM, setElevationM] = useState<number>(18);
  const [ambientAudio, setAmbientAudio] = useState<boolean>(false);
  const [gpsStatus, setGpsStatus] = useState<"idle" | "searching" | "locked" | "denied">("idle");
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string>("");
  const [gpsAccuracy, setGpsAccuracy] = useState<number>(5);
  const [headingDeg, setHeadingDeg] = useState<number>(0);

  // Live Real Coords
  const [currentCoords, setCurrentCoords] = useState<{ lat: number; lng: number }>({
    lat: 17.0298,
    lng: 54.1487,
  });

  // Track History Points for real breadcrumb trail
  const [trailBreadcrumbs, setTrailBreadcrumbs] = useState<Array<{ lat: number; lng: number }>>([]);

  const lastCoordsRef = useRef<{ lat: number; lng: number; time: number } | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const stepTarget = 10000;
  const caloriesBurned = Math.round(steps * 0.042);
  const stepPercent = Math.min(100, Math.round((steps / stepTarget) * 100));
  const caloriePercent = Math.min(100, Math.round((caloriesBurned / 400) * 100));
  const distancePercent = Math.min(100, Math.round((distanceKm / (selectedRoute.distanceKm || 5)) * 100));

  // Pace Calculation (Minutes per Kilometer)
  const paceMinutesPerKm =
    currentSpeedKmh > 0.5 ? (60 / currentSpeedKmh).toFixed(1) : "--";

  // Main Tracking Effect
  useEffect(() => {
    let simInterval: NodeJS.Timeout | undefined;

    if (!isTracking) {
      if (watchIdRef.current !== null && typeof window !== "undefined" && "geolocation" in navigator) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      return;
    }

    if (gpsMode === "real-device") {
      if (typeof window !== "undefined" && "geolocation" in navigator) {
        const id = navigator.geolocation.watchPosition(
          (pos) => {
            const newLat = pos.coords.latitude;
            const newLng = pos.coords.longitude;
            const accuracy = Math.round(pos.coords.accuracy || 5);
            const altitude = pos.coords.altitude ? Math.round(pos.coords.altitude) : 18;
            const now = Date.now();

            setCurrentCoords({ lat: newLat, lng: newLng });
            setGpsAccuracy(accuracy);
            setElevationM(altitude);
            if (pos.coords.heading) setHeadingDeg(Math.round(pos.coords.heading));
            setGpsStatus("locked");

            // Compute True Distance & Speed via Haversine
            if (lastCoordsRef.current) {
              const prev = lastCoordsRef.current;
              const deltaKm = calculateHaversineDistanceKm(prev.lat, prev.lng, newLat, newLng);
              const timeDiffSec = (now - prev.time) / 1000;

              // Filter GPS Jitter: Ignore movement smaller than 2.5 meters
              if (deltaKm >= 0.0025 && timeDiffSec > 0) {
                setDistanceKm((prevDist) => {
                  const updatedDist = prevDist + deltaKm;
                  const newStepCount = Math.floor((updatedDist * 1000) / 0.76);
                  setSteps(newStepCount);

                  if (newStepCount >= 8000 && prevDist < 6.08) {
                    confetti({ particleCount: 80, spread: 65 });
                    spatialAudio.playRepComplete();
                    HapticEngine.workoutComplete();
                    SpeechEngine.speak(
                      "إنجاز رائع! حققت ثمانية آلاف خطوة بالـ GPS الفعلي. ترطيب هيدروليكي ممتاز لفقرات L4-L5."
                    );
                  }
                  return parseFloat(updatedDist.toFixed(3));
                });

                // Speed calculation
                let computedSpeed = 0;
                if (pos.coords.speed !== null && pos.coords.speed >= 0) {
                  computedSpeed = parseFloat((pos.coords.speed * 3.6).toFixed(1));
                } else {
                  computedSpeed = parseFloat(((deltaKm / timeDiffSec) * 3600).toFixed(1));
                }
                setCurrentSpeedKmh(Math.min(25, computedSpeed));
                setCadenceSpm(computedSpeed > 0.5 ? Math.round(computedSpeed * 22) : 0);

                // Add to breadcrumb trail
                setTrailBreadcrumbs((prevTrail) => [...prevTrail.slice(-60), { lat: newLat, lng: newLng }]);
                lastCoordsRef.current = { lat: newLat, lng: newLng, time: now };
              }
            } else {
              lastCoordsRef.current = { lat: newLat, lng: newLng, time: now };
              setTrailBreadcrumbs([{ lat: newLat, lng: newLng }]);
            }
          },
          (err) => {
            console.warn("Geolocation watch error:", err);
            if (err.code === 1) {
              setGpsStatus("denied");
              setGpsErrorMsg("يرجى السماح بصلاحية الموقع الجغرافي (GPS) في المتصفح لبدء التتبع الدقيق.");
            } else {
              setGpsStatus("searching");
              setGpsErrorMsg("جاري الاتصال بالأقمار الصناعية للـ GPS...");
            }
          },
          { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );

        watchIdRef.current = id;
      }
    } else {
      // Salalah Trail Simulation Mode
      simInterval = setInterval(() => {
        setSteps((prev) => {
          const next = prev + 6;
          if (next === 8000 || next === 10000) {
            confetti({ particleCount: 70, spread: 60 });
            spatialAudio.playRepComplete();
            SpeechEngine.speak(`إنجاز متميز! تم إتمام ${next} خطوة بمحاكي مسار صلالة.`);
          }
          return next;
        });

        setDistanceKm((prev) => parseFloat((prev + 0.0045).toFixed(3)));
        setCurrentSpeedKmh(4.8);
        setCadenceSpm(114);
      }, 1000);
    }

    return () => {
      if (simInterval) clearInterval(simInterval);
      if (watchIdRef.current !== null && typeof window !== "undefined" && "geolocation" in navigator) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
  }, [isTracking, gpsMode]);

  // Single Immediate GPS Fix Calibration Button
  const handleCalibrateImmediate = () => {
    if (typeof window !== "undefined" && "geolocation" in navigator) {
      setGpsStatus("searching");
      spatialAudio.playClick();
      HapticEngine.tap();
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setCurrentCoords({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
          setGpsAccuracy(Math.round(pos.coords.accuracy || 5));
          if (pos.coords.altitude) setElevationM(Math.round(pos.coords.altitude));
          setGpsStatus("locked");
          lastCoordsRef.current = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            time: Date.now(),
          };
          SpeechEngine.speak("تمت معايرة إشارة GPS وتحديد موقعك بدقة.");
        },
        (err) => {
          setGpsStatus("denied");
          setGpsErrorMsg("تعذر التقاط الموقع. يرجى تفعيل الموقع بالجهاز.");
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    }
  };

  // Ambient Nature Audio
  const toggleAmbientSound = () => {
    if (!ambientAudio) {
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          audioContextRef.current = ctx;

          const bufferSize = ctx.sampleRate * 2;
          const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          const output = noiseBuffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            output[i] = (Math.random() * 2 - 1) * 0.05;
          }

          const whiteNoise = ctx.createBufferSource();
          whiteNoise.buffer = noiseBuffer;
          whiteNoise.loop = true;

          const filter = ctx.createBiquadFilter();
          filter.type = "lowpass";
          filter.frequency.setValueAtTime(320, ctx.currentTime);

          const gain = ctx.createGain();
          gain.gain.setValueAtTime(0.06, ctx.currentTime);

          whiteNoise.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);
          whiteNoise.start(0);
        }
      } catch {}
      setAmbientAudio(true);
      spatialAudio.playClick();
    } else {
      if (audioContextRef.current) {
        try {
          audioContextRef.current.close();
        } catch {}
        audioContextRef.current = null;
      }
      setAmbientAudio(false);
      spatialAudio.playClick();
    }
  };

  // Draw Interactive Canvas Map
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Dark Background
    ctx.fillStyle = "#04070e";
    ctx.fillRect(0, 0, width, height);

    // Radar / Coordinate Grid
    ctx.strokeStyle = "rgba(0, 240, 255, 0.08)";
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Compass Concentric Circles
    ctx.strokeStyle = "rgba(0, 240, 255, 0.12)";
    ctx.beginPath();
    ctx.arc(width / 2, height / 2, 80, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(width / 2, height / 2, 140, 0, Math.PI * 2);
    ctx.stroke();

    // Draw Live Breadcrumb Trail if available
    if (trailBreadcrumbs.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = "#00f0ff";
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      trailBreadcrumbs.forEach((pt, index) => {
        const x = (width / 2) + ((pt.lng - currentCoords.lng) * 40000);
        const y = (height / 2) - ((pt.lat - currentCoords.lat) * 40000);
        if (index === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    }

    // Center Current GPS Node
    const centerX = width / 2;
    const centerY = height / 2;

    // Pulse Ring
    ctx.beginPath();
    ctx.arc(centerX, centerY, 20, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0, 240, 255, 0.2)";
    ctx.fill();

    // Center Dot
    ctx.beginPath();
    ctx.arc(centerX, centerY, 8, 0, Math.PI * 2);
    ctx.fillStyle = "#00f0ff";
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // GPS Details on Canvas
    ctx.fillStyle = "#00f0ff";
    ctx.font = "bold 11px monospace";
    ctx.textAlign = "center";
    ctx.fillText(`LAT: ${currentCoords.lat.toFixed(5)} | LNG: ${currentCoords.lng.toFixed(5)}`, width / 2, height - 20);
  }, [currentCoords, trailBreadcrumbs]);

  const handleToggleTracking = () => {
    const next = !isTracking;
    setIsTracking(next);
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();

    if (next) {
      SpeechEngine.speak(
        gpsMode === "real-device"
          ? "بدء تتبع GPS الحقيقي. يتم الآن قياس المسافة الحقيقية وحساب الخطوات بدقة لترطيب فقرات L4-L5."
          : `بدء محاكاة مسار مشي ${selectedRoute.nameAr}.`
      );
    } else {
      SpeechEngine.speak(`تم إيقاف تتبع المشي. المسافة الإجمالية: ${distanceKm} كيلومتر.`);
    }
  };

  const handleResetWalk = () => {
    setSteps(0);
    setDistanceKm(0);
    setCurrentSpeedKmh(0);
    setTrailBreadcrumbs([]);
    lastCoordsRef.current = null;
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  return (
    <div className="space-y-5" id="apex-salalah-gps-tracker">
      {/* 1. Header Toolbar */}
      <div className="rounded-3xl bg-[#090d16] border border-slate-800/90 p-5 shadow-2xl backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/30 flex items-center gap-1">
              <Radio className="w-3 h-3 text-[#00f0ff] animate-pulse" />
              ACCURATE REAL GPS ENGINE
            </span>
            <span className="px-2.5 py-0.5 rounded-md text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-mono">
              الهدف الطبي: 8,000 - 10,000 خطوة
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Footprints className="w-6 h-6 text-[#00f0ff]" />
            تتبع المشي بالـ GPS الفعلي وحماية L4-L5
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            قياس فيزيائي دقيق للمسافة بمعادلة Haversine والسرعة ومعدل الخطوات لضمان تغذية الديسك القطني وترطيبه هيدروليكياً.
          </p>
        </div>

        {/* Action Controls & GPS Mode Switcher */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Mode Switcher */}
          <div className="bg-slate-900 border border-slate-800 p-1 rounded-2xl flex items-center">
            <button
              onClick={() => {
                setGpsMode("real-device");
                spatialAudio.playClick();
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition flex items-center gap-1 ${
                gpsMode === "real-device"
                  ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <LocateFixed className="w-3.5 h-3.5" />
              <span>GPS الحقيقي للجهاز</span>
            </button>
            <button
              onClick={() => {
                setGpsMode("salalah-sim");
                spatialAudio.playClick();
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition flex items-center gap-1 ${
                gpsMode === "salalah-sim"
                  ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Mountain className="w-3.5 h-3.5" />
              <span>محاكي مسارات صلالة</span>
            </button>
          </div>

          <button
            onClick={handleCalibrateImmediate}
            className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 hover:text-[#00f0ff] transition"
            title="معايرة إحداثيات GPS فورياً"
          >
            <LocateFixed className="w-4 h-4" />
          </button>

          <button
            onClick={toggleAmbientSound}
            className={`p-2.5 rounded-2xl border transition ${
              ambientAudio
                ? "bg-[#00f0ff]/20 text-[#00f0ff] border-[#00f0ff]/50 shadow-[0_0_10px_rgba(0,240,255,0.3)]"
                : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
            }`}
            title="أصوات طبيعة صلالة والأمواج"
          >
            {ambientAudio ? <Volume2 className="w-4 h-4 text-[#00f0ff] animate-pulse" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={handleToggleTracking}
            className={`px-5 py-2.5 rounded-2xl text-xs font-bold font-mono transition flex items-center gap-2 shadow-lg ${
              isTracking
                ? "bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 shadow-rose-500/20"
                : "bg-[#00f0ff] hover:bg-[#00f0ff]/90 text-slate-950 font-black shadow-[0_0_20px_rgba(0,240,255,0.4)]"
            }`}
          >
            {isTracking ? (
              <>
                <Pause className="w-4 h-4 stroke-[3]" />
                <span>إيقاف التتبع</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-slate-950 stroke-none" />
                <span>بدء تتبع المشي الفعلي</span>
              </>
            )}
          </button>

          <button
            onClick={handleResetWalk}
            className="p-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
            title="إعادة تعيين المسافة والخطوات"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* GPS Status / Error Alert Banner if needed */}
      {gpsErrorMsg && (
        <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-300 text-xs font-mono flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>{gpsErrorMsg}</span>
        </div>
      )}

      {/* 2. Top Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-[#090d16] border border-slate-800/90 shadow-xl backdrop-blur-xl">
          <span className="text-[10px] font-mono text-slate-400 block">إجمالي الخطوات المحسوبة</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-black font-mono text-white">{steps.toLocaleString()}</span>
            <span className="text-xs font-mono text-[#00f0ff]">/ 10,000</span>
          </div>
          <div className="w-full bg-slate-900 h-1.5 rounded-full mt-2 overflow-hidden">
            <div className="bg-[#00f0ff] h-full rounded-full transition-all" style={{ width: `${stepPercent}%` }} />
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-[#090d16] border border-slate-800/90 shadow-xl backdrop-blur-xl">
          <span className="text-[10px] font-mono text-slate-400 block">المسافة الحقيقية (Haversine)</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-black font-mono text-[#00f0ff]">{distanceKm}</span>
            <span className="text-xs font-mono text-slate-400">كم</span>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 block mt-2">دقة الـ GPS: ±{gpsAccuracy}m</span>
        </div>

        <div className="p-4 rounded-3xl bg-[#090d16] border border-slate-800/90 shadow-xl backdrop-blur-xl">
          <span className="text-[10px] font-mono text-slate-400 block">السرعة ومعدل الخطوات</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-black font-mono text-amber-400">{currentSpeedKmh}</span>
            <span className="text-xs font-mono text-slate-400">km/h</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400 block mt-2">الإيقاع: {cadenceSpm} خطوة/د</span>
        </div>

        <div className="p-4 rounded-3xl bg-[#090d16] border border-slate-800/90 shadow-xl backdrop-blur-xl">
          <span className="text-[10px] font-mono text-slate-400 block">المعدل الزمني (Pace) & السعرات</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-black font-mono text-emerald-400">{paceMinutesPerKm}</span>
            <span className="text-xs font-mono text-slate-400">د/كم</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400 block mt-2">الحرق: {caloriesBurned} kcal</span>
        </div>
      </div>

      {/* 3. Live Canvas Map & Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Visual Map Canvas */}
        <div className="lg:col-span-8 rounded-3xl bg-[#090d16] border border-slate-800/90 p-4 shadow-2xl backdrop-blur-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#00f0ff]" />
              <span className="text-xs font-bold text-white font-mono">
                LIVE GPS RADAR & BREADCRUMB TRAIL
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono">
              <span className={`w-2 h-2 rounded-full ${gpsStatus === "locked" ? "bg-emerald-400 animate-pulse" : "bg-amber-400"}`} />
              <span className="text-slate-300">
                {gpsStatus === "locked" ? "إشارة GPS نشطة ومقفلة ✓" : "جاري البحث..."}
              </span>
            </div>
          </div>

          <div className="relative w-full h-80 rounded-2xl overflow-hidden bg-[#04070e] border border-slate-800/90">
            <canvas
              ref={canvasRef}
              width={700}
              height={320}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
            <span>الارتفاع: {elevationM} متر عن سطح البحر</span>
            <span className="text-emerald-400">تفريغ ديسك L4-L5: 100% نشط</span>
          </div>
        </div>

        {/* Salalah Routes & Medical Guidelines */}
        <div className="lg:col-span-4 space-y-4">
          <div className="rounded-3xl bg-[#090d16] border border-slate-800/90 p-5 shadow-2xl backdrop-blur-xl space-y-3">
            <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#00f0ff]" />
              مسارات صلالة المعتمدة طبياً:
            </h3>

            <div className="space-y-2">
              {SALALAH_ROUTES.map((route) => (
                <button
                  key={route.id}
                  onClick={() => {
                    setSelectedRoute(route);
                    spatialAudio.playClick();
                  }}
                  className={`w-full text-right p-3 rounded-2xl border transition-all text-xs ${
                    selectedRoute.id === route.id
                      ? "bg-[#00f0ff]/15 border-[#00f0ff]/50 text-white"
                      : "bg-slate-900/60 border-slate-800/80 text-slate-300 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span>{route.nameAr}</span>
                    <span className="text-[#00f0ff] font-mono">{route.distanceKm} km</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">{route.terrainType}</p>
                </button>
              ))}
            </div>

            {/* L4-L5 Walking Protocol */}
            <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-xs space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold font-mono">
                <ShieldCheck className="w-4 h-4" />
                <span>توجيه طبي لأشرف:</span>
              </div>
              <p className="text-emerald-200 text-[11px] leading-relaxed">
                المشي المنتظم بصلالة ينشط الدورة الدموية حول الجذور العصبية L4-L5 دون أي صدمات أو انحناءات خطيرة.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
