"use client";

import React, { useState } from "react";
import {
  Clock,
  CheckCircle2,
  Volume2,
  Copy,
  Calendar,
  Sparkles,
  Sun,
  Moon,
  Coffee,
  Dumbbell,
  Footprints,
  Utensils,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

interface RoutineSlot {
  id: string;
  time: string;
  period: "morning" | "afternoon" | "evening" | "night";
  titleAr: string;
  descriptionAr: string;
  category: "diet" | "workout" | "spine" | "walking" | "rest";
  completed: boolean;
}

export default function DynamicRoutine() {
  const [routine, setRoutine] = useState<RoutineSlot[]>([
    {
      id: "slot-1",
      time: "07:00 AM",
      period: "morning",
      titleAr: "الاستيقاظ + 500 مل ماء + إطالة الكمثرية",
      descriptionAr: "شرب كوبين ماء لترطيب ديسك L4-L5 بعد النوم + إطالة عضلة الكمثرية 30 ثانية لكل ساق لتحرير العصب الوركي.",
      category: "spine",
      completed: true,
    },
    {
      id: "slot-2",
      time: "07:30 AM",
      period: "morning",
      titleAr: "وجبة الإفطار (450 Kcal / 28g P)",
      descriptionAr: "3 بيضات مسلوقة + خبز أسمر + خيار وطماطم طازجة لبدء التخليق البروتيني الصباحي.",
      category: "diet",
      completed: true,
    },
    {
      id: "slot-3",
      time: "10:30 AM",
      period: "morning",
      titleAr: "استراحة القوام وترطيب الفقرات",
      descriptionAr: "شرب 500 مل ماء + الوقوف وتعديل استقامة العمود الفقري والكتفين للوراء.",
      category: "spine",
      completed: false,
    },
    {
      id: "slot-4",
      time: "01:30 PM",
      period: "afternoon",
      titleAr: "وجبة الغداء الرئيسية (680 Kcal / 45g P)",
      descriptionAr: "صدر دجاج مشوي أو تونة أو عدس + 7 ملاعق أرز + سلطة خضراء مع زيت زيتون.",
      category: "diet",
      completed: false,
    },
    {
      id: "slot-5",
      time: "04:30 PM",
      period: "afternoon",
      titleAr: "سناك شحنة الطاقة قبل التمرين (220 Kcal)",
      descriptionAr: "كوب حليب/لبن + موزة ناضجة قبل موعد التمرين بساعة لشحن جليكوجين العضلات.",
      category: "diet",
      completed: false,
    },
    {
      id: "slot-6",
      time: "05:30 PM",
      period: "evening",
      titleAr: "جلسة التمارين الموجهة (التضخيم الصافي)",
      descriptionAr: "تنفيذ تمارين البايسبس، الصدر، الأكتاف، مع الالتزام الصارم بـ Face Pulls و Supermans.",
      category: "workout",
      completed: false,
    },
    {
      id: "slot-7",
      time: "07:00 PM",
      period: "evening",
      titleAr: "المشي الميداني بصلالة (8,000 - 10,000 خطوة)",
      descriptionAr: "ممشى كورنيش الدهاريز أو سهل إتين لضخ السوائل الزلالية للفقرات القطنية L4-L5.",
      category: "walking",
      completed: false,
    },
    {
      id: "slot-8",
      time: "09:00 PM",
      period: "evening",
      titleAr: "وجبة العشاء والاستشفاء (380 Kcal / 25g P)",
      descriptionAr: "علبة زبادي + جبن قريش أو أبيض مع زيت زيتون وخيار لتغذية العضلات بالكازين الليلي.",
      category: "diet",
      completed: false,
    },
    {
      id: "slot-9",
      time: "10:30 PM",
      period: "night",
      titleAr: "جلسة جسر المقعدة + النوم العميق",
      descriptionAr: "3 جولات تمرين Glute Bridges لتفريغ الضغط قبل النوم ثم نوم عميق 8 ساعات لإفراز هرمون النمو.",
      category: "rest",
      completed: false,
    },
  ]);

  const toggleSlotCompleted = (id: string) => {
    setRoutine(
      routine.map((slot) => {
        if (slot.id === id) {
          const next = !slot.completed;
          if (next) {
            spatialAudio.playRepComplete();
            HapticEngine.success();
          } else {
            spatialAudio.playClick();
            HapticEngine.tap();
          }
          return { ...slot, completed: next };
        }
        return slot;
      })
    );
  };

  const handleVoiceRoutine = () => {
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    const text = `جدولك اليومي بالساعات: تبدأ السابعة صباحاً بإطالة الكمثرية وشرب الماء، ثم الإفطار، فالغداء في الواحدة والنصف، سناك الطاقة في الرابعة والنصف، التمرين في الخامسة والنصف، مشي صلالة في السابعة مساءً، والعشاء في التاسعة.`;
    SpeechEngine.speak(text);
  };

  const handleCopyRoutine = () => {
    if (typeof window !== "undefined" && navigator.clipboard) {
      const formatted = routine
        .map((r) => `[${r.time}] ${r.titleAr}\n${r.descriptionAr}\n`)
        .join("\n");
      navigator.clipboard.writeText(`📅 جدول FitPulse 2027 Spatial Pro اليومي بالساعات:\n\n${formatted}`);
      spatialAudio.playClick();
      HapticEngine.tap();
      SpeechEngine.speak("تم نسخ الجدول الزمني للحافظة.");
    }
  };

  const completedTotal = routine.filter((r) => r.completed).length;

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 p-4 sm:p-5 shadow-xl backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 flex items-center gap-1">
              <Clock className="w-3 h-3 text-indigo-400" />
              DYNAMIC HOURLY ROUTINE GENERATOR
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              تم إنجاز {completedTotal} من {routine.length} مهام
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Calendar className="w-6 h-6 text-indigo-400" />
            مولد الجداول الزمنية المفصلة بالساعات
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            جدول إيقاعي منظم يضمن تناغم استهلاك السعرات (1850 Kcal) مع أوقات التمارين والمشي بصلالة لتحقيق أقصى استشفاء لفقرات L4-L5.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleVoiceRoutine}
            className="px-3.5 py-2 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-400/40 text-xs font-bold transition flex items-center gap-1.5 shadow-[0_0_15px_rgba(99,102,241,0.2)]"
          >
            <Volume2 className="w-4 h-4 text-indigo-400" />
            قراءة الجدول
          </button>
          <button
            onClick={handleCopyRoutine}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold transition flex items-center gap-1.5"
          >
            <Copy className="w-4 h-4 text-cyan-400" />
            نسخ
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4 shadow-lg flex items-center justify-between gap-4">
        <div className="w-full">
          <div className="flex justify-between text-xs text-slate-300 mb-1.5 font-mono">
            <span>معدل الالتزام الزمني اليومي:</span>
            <span className="text-cyan-400 font-bold">
              {Math.round((completedTotal / routine.length) * 100)}%
            </span>
          </div>
          <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 via-cyan-400 to-emerald-400 rounded-full transition-all duration-300"
              style={{ width: `${(completedTotal / routine.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Timeline Slots List */}
      <div className="space-y-2.5">
        {routine.map((slot) => {
          const isDone = slot.completed;

          return (
            <div
              key={slot.id}
              onClick={() => toggleSlotCompleted(slot.id)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all duration-200 flex items-start justify-between gap-3 ${
                isDone
                  ? "bg-emerald-950/20 border-emerald-500/40"
                  : "bg-slate-900/80 border-slate-800 hover:border-cyan-500/40"
              }`}
            >
              <div className="flex items-start gap-3">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleSlotCompleted(slot.id);
                  }}
                  className={`p-2 rounded-xl border mt-0.5 transition ${
                    isDone
                      ? "bg-emerald-500 text-slate-950 border-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.3)]"
                      : "bg-slate-950 text-slate-600 border-slate-800 hover:border-cyan-400"
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                </button>

                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono font-bold text-cyan-400 bg-slate-950 px-2.5 py-0.5 rounded-lg border border-cyan-500/20 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      {slot.time}
                    </span>
                    <span
                      className={`text-sm font-bold transition ${
                        isDone ? "text-emerald-300 line-through opacity-80" : "text-white"
                      }`}
                    >
                      {slot.titleAr}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                    {slot.descriptionAr}
                  </p>
                </div>
              </div>

              {/* Category Icon Badge */}
              <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-400 shrink-0">
                {slot.category === "diet" && <Utensils className="w-4 h-4 text-amber-400" />}
                {slot.category === "workout" && <Dumbbell className="w-4 h-4 text-cyan-400" />}
                {slot.category === "spine" && <ShieldCheck className="w-4 h-4 text-rose-400" />}
                {slot.category === "walking" && <Footprints className="w-4 h-4 text-teal-400" />}
                {slot.category === "rest" && <Moon className="w-4 h-4 text-indigo-400" />}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
