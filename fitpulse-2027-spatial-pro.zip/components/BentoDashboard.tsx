"use client";

import React, { useState } from "react";
import {
  Activity,
  Zap,
  ShieldAlert,
  Sparkles,
  Scale,
  Footprints,
  Volume2,
  ChevronRight,
  RotateCw,
  Dumbbell,
  CheckCircle2,
  Flame,
  Bot,
  Compass,
} from "lucide-react";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

interface BentoDashboardProps {
  onNavigateTab: (tabId: string) => void;
  onSelectMuscleIn3D?: (muscleKey: string) => void;
}

export default function BentoDashboard({
  onNavigateTab,
  onSelectMuscleIn3D,
}: BentoDashboardProps) {
  const [selectedMuscle, setSelectedMuscle] = useState<string>("spine");
  const [isRotating, setIsRotating] = useState<boolean>(true);
  const [stepsCount, setStepsCount] = useState<number>(8432);
  const [isAiListening, setIsAiListening] = useState<boolean>(false);

  const handleVoiceBrief = () => {
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    SpeechEngine.speak(
      "نظام فيت بلس 2027 بينتو جريد: المزامنة العصبية نشطة، تم تحقيق ثمانية آلاف وأربعمائة خطوة في مسار صلالة، وهدف اليوم 1850 سعرة حرارية مع بروتوكول حماية L4-L5."
    );
  };

  const handleSelectMuscle = (key: string) => {
    setSelectedMuscle(key);
    spatialAudio.playClick();
    HapticEngine.tap();
    if (onSelectMuscleIn3D) {
      onSelectMuscleIn3D(key);
    }
  };

  const handleAddStep = () => {
    setStepsCount((prev) => Math.min(10000, prev + 250));
    spatialAudio.playRepComplete();
    HapticEngine.repDone();
  };

  return (
    <div className="space-y-4">
      {/* Top Bento Quick Summary Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-900/60 border border-slate-800 p-4 sm:p-5 rounded-3xl gap-4 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/25 text-white">
            <Zap className="w-6 h-6 fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                لوحة Bento Grid الشاملة
              </h2>
              <span className="text-[10px] font-mono uppercase bg-slate-800 px-2 py-0.5 rounded-md text-indigo-400 border border-slate-700">
                SPATIAL_PRO_V4.2
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              SYSTEM STATUS: NEURAL SYNC ACTIVE | حالة التضخيم الصافي 82.7%
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-between sm:justify-end">
          <div className="text-right hidden sm:block">
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
              Salalah GPS
            </p>
            <p className="text-xs font-medium text-slate-300">مسار صلالة | 24°C</p>
          </div>

          <button
            onClick={handleVoiceBrief}
            className="px-3.5 py-2 rounded-2xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-indigo-500/10"
          >
            <Volume2 className="w-4 h-4 text-indigo-400" />
            <span>إيجاز صوتي للمؤشرات</span>
          </button>
        </div>
      </div>

      {/* Main Bento Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Bento Box 1: Spatial Muscle Analysis (5 cols) */}
        <div className="md:col-span-12 lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 relative overflow-hidden group flex flex-col justify-between shadow-xl">
          <div className="absolute top-0 right-0 p-4 text-[10px] font-mono text-indigo-400/50">
            THREE.JS_RENDER_V4.2
          </div>

          <div>
            <div className="mb-4">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                Spatial Muscle Analysis | التشريح العضلي ثلاثي الأبعاد
              </h3>
              <p className="text-xs text-slate-300">
                التركيز الحالي: استهداف الصدر والظهر مع حماية السلسلة الخلفية
              </p>
            </div>

            {/* Interactive 3D Holographic Display */}
            <div className="my-4 p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 relative flex flex-col items-center justify-center min-h-[190px]">
              <div className="absolute w-44 h-44 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

              {/* Muscle Silhouette Mock Graphic */}
              <div className="relative flex flex-col items-center">
                <div className="w-24 h-32 bg-slate-900 rounded-full border border-indigo-500/30 flex flex-col items-center justify-center gap-1.5 overflow-hidden shadow-inner">
                  {/* Chest highlight */}
                  <div
                    onClick={() => handleSelectMuscle("chest")}
                    className={`w-16 h-7 rounded-full cursor-pointer transition-all duration-300 ${
                      selectedMuscle === "chest"
                        ? "bg-indigo-500 shadow-[0_0_15px_#6366f1]"
                        : "bg-indigo-500/30 hover:bg-indigo-500/50"
                    }`}
                    title="الصدر"
                  />
                  {/* Core / Spine highlight */}
                  <div
                    onClick={() => handleSelectMuscle("spine")}
                    className={`w-14 h-5 rounded-full cursor-pointer transition-all duration-300 ${
                      selectedMuscle === "spine"
                        ? "bg-rose-500 shadow-[0_0_15px_#f43f5e] animate-pulse"
                        : "bg-rose-500/30 hover:bg-rose-500/60"
                    }`}
                    title="الفقرات L4-L5"
                  />
                  {/* Legs highlight */}
                  <div
                    onClick={() => handleSelectMuscle("legs")}
                    className={`w-18 h-9 rounded-full cursor-pointer transition-all duration-300 ${
                      selectedMuscle === "legs"
                        ? "bg-indigo-400 shadow-[0_0_15px_#818cf8]"
                        : "bg-indigo-500/20 hover:bg-indigo-500/40"
                    }`}
                    title="الأرجل"
                  />
                </div>

                <div className="mt-3 text-center">
                  <p className="text-xs text-indigo-400 font-bold tracking-wider">
                    360° SPATIAL ENGINE ACTIVE
                  </p>
                  <p className="text-[10px] text-slate-500">
                    اضغط لتغيير المجموعة العضلية أو انتقل للمجسم الكامل
                  </p>
                </div>
              </div>

              {/* Muscle Selector Mini Chips */}
              <div className="flex flex-wrap justify-center gap-1 mt-3">
                {[
                  { id: "chest", name: "الصدر" },
                  { id: "spine", name: "الفقرات L4-L5" },
                  { id: "back", name: "الظهر" },
                  { id: "biceps", name: "البايسبس" },
                  { id: "legs", name: "الأرجل" },
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => handleSelectMuscle(m.id)}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-mono transition ${
                      selectedMuscle === m.id
                        ? "bg-indigo-500 text-white font-bold"
                        : "bg-slate-800/80 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {m.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* L4-L5 Safety Alert Bento Box */}
          <div className="mt-3 p-3.5 bg-red-500/10 border border-red-500/20 rounded-2xl">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                <p className="text-xs font-bold text-red-400 uppercase tracking-wide">
                  توجيه طبي حاسم | L4-L5 SAFETY ALERT
                </p>
              </div>
              <button
                onClick={() => onNavigateTab("spine-protocol")}
                className="text-[10px] text-red-400 hover:underline flex items-center gap-0.5"
              >
                التفاصيل <ChevronRight className="w-3 h-3 rotate-180" />
              </button>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              إلغاء مشد الظهر فوراً لمنع ضمور العضلات العميقة، والاعتماد على تمارين Face Pulls وجسر المقعدة وإطالة الكمثرية.
            </p>
          </div>

          <button
            onClick={() => onNavigateTab("3d-anatomy")}
            className="w-full mt-3 py-2 px-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition"
          >
            <span>فتح المجسم التفاعلي الكامل 3D</span>
            <ChevronRight className="w-3.5 h-3.5 rotate-180 text-indigo-400" />
          </button>
        </div>

        {/* Bento Box 2: InBody Analytics (4 cols) */}
        <div className="md:col-span-6 lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                InBody Analytics | تكوين الجسم
              </h3>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                LEAN: 82.7%
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/50">
                <p className="text-[10px] text-slate-400 mb-1">الوزن الكلي</p>
                <p className="text-xl font-bold text-white font-mono">
                  61.80 <span className="text-xs font-normal text-slate-400">KG</span>
                </p>
                <span className="text-[9px] text-slate-500">طبيعي متوازن</span>
              </div>

              <div className="bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/50">
                <p className="text-[10px] text-slate-400 mb-1">الكتلة العضلية</p>
                <p className="text-xl font-bold text-indigo-400 font-mono">
                  51.10 <span className="text-xs font-normal text-slate-400">KG</span>
                </p>
                <span className="text-[9px] text-emerald-400">أداء عضلي ممتاز</span>
              </div>

              <div className="bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/50">
                <p className="text-[10px] text-slate-400 mb-1">نسبة الدهون</p>
                <p className="text-xl font-bold text-emerald-400 font-mono">
                  13.0 <span className="text-xs font-normal text-slate-400">%</span>
                </p>
                <span className="text-[9px] text-slate-500">تحت الجلد: 9.1%</span>
              </div>

              <div className="bg-slate-800/50 p-3.5 rounded-2xl border border-slate-700/50">
                <p className="text-[10px] text-slate-400 mb-1">الدهون الحشوية</p>
                <p className="text-xl font-bold text-slate-200 font-mono">LVL 5</p>
                <span className="text-[9px] text-slate-500">مستوى صحي آمن</span>
              </div>
            </div>

            {/* Additional InBody Ratios */}
            <div className="mt-4 p-3 bg-slate-800/30 rounded-2xl border border-slate-800 space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">معدل الأيض الأساسي (BMR)</span>
                <span className="text-indigo-300 font-mono font-bold">1473 Kcal</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">مؤشر الكتلة اللادهنية (FFMI)</span>
                <span className="text-emerald-300 font-mono font-bold">17.7 (بناء واعد)</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab("inbody")}
            className="w-full mt-4 py-2 px-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition"
          >
            <span>محاكي InBody وتفاصيل الأيض</span>
            <ChevronRight className="w-3.5 h-3.5 rotate-180 text-indigo-400" />
          </button>
        </div>

        {/* Bento Box 3: Clean Bulking Protocol (3 cols) */}
        <div className="md:col-span-6 lg:col-span-3 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Clean Bulking Protocol | التغذية
              </h3>
              <Flame className="w-4 h-4 text-amber-400" />
            </div>

            <div className="space-y-2.5">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-xs font-medium text-slate-300">الإفطار</span>
                <span className="text-xs text-indigo-400 font-mono">450 Kcal | 28g P</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-xs font-medium text-slate-300">سناك التمرين</span>
                <span className="text-xs text-indigo-400 font-mono">220 Kcal | 8g P</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-xs font-medium text-slate-300">الغداء</span>
                <span className="text-xs text-indigo-400 font-mono">680 Kcal | 45g P</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-xs font-medium text-slate-300">العشاء</span>
                <span className="text-xs text-indigo-400 font-mono">380 Kcal | 25g P</span>
              </div>
            </div>

            {/* Calorie Bar */}
            <div className="mt-4 pt-2">
              <div className="flex justify-between items-end mb-1.5">
                <p className="text-[10px] text-slate-400 uppercase tracking-tight">
                  الهدف اليومي للسعرات
                </p>
                <p className="text-base font-bold text-white font-mono">
                  1850 <span className="text-xs font-normal text-slate-400">kcal</span>
                </p>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className="w-[85%] h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full" />
              </div>
              <div className="flex justify-between mt-1 text-[9px] font-mono text-slate-500">
                <span>BMR: 1473</span>
                <span>فائض نظيف: +377</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab("diet")}
            className="w-full mt-4 py-2 px-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition"
          >
            <span>عرض تفاصيل الوجبات والماء</span>
            <ChevronRight className="w-3.5 h-3.5 rotate-180 text-indigo-400" />
          </button>
        </div>

        {/* Bento Box 4: Featured Routine Hero Card (4 cols) */}
        <div className="md:col-span-6 lg:col-span-4 bg-indigo-600 rounded-3xl p-5 sm:p-6 text-white relative overflow-hidden shadow-xl shadow-indigo-600/20 flex flex-col justify-between">
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-indigo-200">
                FEATURED ROUTINE | التمرين الأهم
              </p>
              <span className="px-2 py-0.5 rounded bg-indigo-700 text-[10px] font-bold text-indigo-100">
                V-TAPER POSTURE
              </span>
            </div>

            <h4 className="text-2xl font-black mb-2 tracking-tight">
              سحب الوجه بالحبل (Face Pulls)
            </h4>
            <p className="text-xs text-indigo-100 mb-3 opacity-95 leading-relaxed">
              البديل العلاجي المعتمد لشد القوام وتفريغ الضغط عن الفقرات القطنية L4-L5 دون ارتداء مشد خانق.
            </p>

            <ul className="text-xs space-y-1.5 text-indigo-50">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 flex-shrink-0" />
                <span>تصحيح تقوس الكتفين وبناء قوام رياضي منتصب</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 flex-shrink-0" />
                <span>إزالة الضغط عن مسار العصب الوركي (عرق النسا)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 flex-shrink-0" />
                <span>تفعيل عضلات أعلى الظهر الدوارة الخارجية</span>
              </li>
            </ul>
          </div>

          <div className="relative z-10 mt-4 flex items-center gap-2">
            <button
              onClick={() => onNavigateTab("exercises")}
              className="flex-1 py-2 px-3 rounded-xl bg-white text-indigo-950 hover:bg-indigo-50 text-xs font-bold transition shadow-md flex items-center justify-center gap-1"
            >
              <Dumbbell className="w-3.5 h-3.5 text-indigo-600" />
              <span>بدء التمرين في المشغل</span>
            </button>
            <button
              onClick={() => onNavigateTab("spine-protocol")}
              className="py-2 px-3 rounded-xl bg-indigo-700/80 hover:bg-indigo-700 text-white text-xs font-medium transition"
            >
              البروتوكول
            </button>
          </div>

          {/* Background Decorative SVG */}
          <Dumbbell className="absolute -right-6 -bottom-6 w-36 h-36 text-indigo-700/40 pointer-events-none" />
        </div>

        {/* Bento Box 5: Activity & GPS Tracking (5 cols) */}
        <div className="md:col-span-6 lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Activity & GPS Tracking | نشاط المشي
              </h3>
              <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-mono rounded border border-emerald-500/20 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                LIVE_SYNC
              </span>
            </div>

            <div className="flex gap-4 items-center">
              <div className="flex-grow">
                <p className="text-[10px] text-slate-400 mb-1 uppercase tracking-tight">
                  خطوات المشي اليومية - صلالة
                </p>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl sm:text-4xl font-black font-mono tracking-tighter text-white">
                    {stepsCount.toLocaleString()}
                  </p>
                  <span className="text-xs text-slate-400 font-mono">/ 10,000 خطوة</span>
                </div>

                {/* Segmented Step Indicator */}
                <div className="flex items-center gap-1.5 mt-3">
                  {[...Array(10)].map((_, i) => (
                    <div
                      key={i}
                      className={`h-2.5 w-2 rounded-sm transition-all ${
                        i < Math.floor((stepsCount / 10000) * 10)
                          ? "bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]"
                          : "bg-slate-800"
                      }`}
                    />
                  ))}
                  <span className="text-[10px] font-mono text-slate-400 mr-2">
                    {Math.round((stepsCount / 10000) * 100)}%
                  </span>
                </div>
              </div>

              {/* Mini Trail Visual */}
              <div className="w-20 h-20 sm:w-24 sm:h-24 bg-slate-800/80 rounded-2xl border border-slate-700/80 flex flex-col items-center justify-center p-2 text-center flex-shrink-0">
                <Footprints className="w-6 h-6 text-indigo-400 mb-1" />
                <p className="text-[9px] text-slate-400 leading-tight">شاطئ الدهاريز</p>
                <p className="text-[9px] text-emerald-400 font-mono font-bold">4.2 كم</p>
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2">
            <button
              onClick={handleAddStep}
              className="flex-1 py-1.5 px-3 rounded-xl bg-slate-800/70 hover:bg-slate-800 text-xs font-mono text-indigo-300 border border-slate-700 transition"
            >
              + تسجيل مشي (+250 خطوة)
            </button>
            <button
              onClick={() => onNavigateTab("salalah-gps")}
              className="py-1.5 px-3 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-xs font-medium border border-indigo-500/30 transition flex items-center gap-1"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>خريطة صلالة</span>
            </button>
          </div>
        </div>

        {/* Bento Box 6: Tri-Module Health & AI Status (3 cols) */}
        <div className="md:col-span-12 lg:col-span-3 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col justify-between shadow-xl">
          <div>
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
              Neural & Spine Telemetry | المؤشرات العصبية
            </h3>

            <div className="space-y-3">
              {/* Sciatica */}
              <div className="space-y-0.5 border-b border-slate-800 pb-2.5">
                <p className="text-[10px] text-slate-400 uppercase tracking-tight">
                  تفريغ ضغط عرق النسا
                </p>
                <p className="text-base font-bold text-emerald-400 font-mono">OPTIMAL (مثالي)</p>
                <p className="text-[10px] text-slate-400 leading-tight">
                  إطالة الكمثرية الصباحية تمنع انضغاط العصب الوركي.
                </p>
              </div>

              {/* Neural Fatigue */}
              <div className="space-y-0.5 border-b border-slate-800 pb-2.5">
                <p className="text-[10px] text-slate-400 uppercase tracking-tight">
                  الإجهاد العصبي المركزي
                </p>
                <p className="text-base font-bold text-amber-400 font-mono">LOW (منخفض 18%)</p>
                <p className="text-[10px] text-slate-400 leading-tight">
                  يوصى بنوم 7.5 ساعات لترطيب الغضاريف طبيعياً.
                </p>
              </div>

              {/* Voice AI Coach */}
              <div className="space-y-1">
                <p className="text-[10px] text-slate-400 uppercase tracking-tight">
                  الكوتش الذكي AI
                </p>
                <div className="flex items-center gap-2">
                  <div className="flex gap-0.5 items-center">
                    <div className="w-0.5 h-3 bg-indigo-400 animate-pulse" />
                    <div className="w-0.5 h-5 bg-indigo-400" />
                    <div className="w-0.5 h-2 bg-indigo-400" />
                    <div className="w-0.5 h-4 bg-indigo-400" />
                  </div>
                  <span className="text-[10px] font-mono text-slate-300">READY TO ASSIST</span>
                </div>
                <p className="text-[10px] text-slate-400 italic">
                  &quot;هل أكملت وجبة الغداء 680 Kcal اليوم؟&quot;
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab("ai-coach")}
            className="w-full mt-3 py-2 px-3 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-xs font-bold border border-indigo-500/40 flex items-center justify-center gap-1.5 transition"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>محادثة الكوتش الذكي</span>
          </button>
        </div>
      </div>
    </div>
  );
}
