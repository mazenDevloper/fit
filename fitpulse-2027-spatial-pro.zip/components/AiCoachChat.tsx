"use client";

import React, { useState, useRef } from "react";
import {
  Sparkles,
  Send,
  Bot,
  User,
  Volume2,
  RotateCcw,
  Zap,
  ShieldAlert,
  Dumbbell,
  Utensils,
  Footprints,
} from "lucide-react";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

interface Message {
  id: string;
  sender: "user" | "coach";
  text: string;
  timestamp: string;
}

export default function AiCoachChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "m-0",
      sender: "coach",
      text: "أهلاً بك يا بطل! أنا كوتش FitPulse 2027 Spatial Pro الذكي. أنا هنا لتوجيهك في خطة التضخيم الصافي (1800 - 1850 سعرة حرارية)، وبروتوكول حماية الفقرات L4-L5، ومتابعة المشي بصلالة. كيف يمكنني مساعدتك الآن؟",
      timestamp: "الآن",
    },
  ]);
  const [inputValue, setInputValue] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const msgIdRef = useRef<number>(1);

  const quickPrompts = [
    { label: "🛡️ بروتوكول سلامة L4-L5", query: "اشرح لي لماذا تم إلغاء مشد الظهر وما هي التمارين البديلة لحماية الفقرات L4-L5؟" },
    { label: "🍗 نظام الـ 1850 سعرة", query: "ما هو توزيع الوجبات والبروتين المستهدف للتضخيم الصافي على وزني 61.8 كجم؟" },
    { label: "💪 تمرين Face Pulls", query: "كيف أقوم بتمرين Face Pulls لشد القوام وعلاج انحناء الكتفين؟" },
    { label: "📍 مشي صلالة وترطيب الديسك", query: "كيف يساهم مشي 10,000 خطوة في صلالة في توسيع وترطيب غضاريف أسفل الظهر؟" },
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputValue.trim();
    if (!text || isLoading) return;

    msgIdRef.current += 1;
    const currentId = msgIdRef.current;
    const userMsg: Message = {
      id: `u-${currentId}`,
      sender: "user",
      text,
      timestamp: "الآن",
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);
    spatialAudio.playClick();
    HapticEngine.tap();

    try {
      const res = await fetch("/api/coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          context: {
            weight: 61.8,
            muscleMass: 51.1,
            bodyFat: 13.0,
            bmr: 1473,
            calorieTarget: 1850,
            spineFocus: "L4-L5 Lumbar & Sciatica Decompression",
          },
        }),
      });

      const data = await res.json();
      const coachReply = data.reply || "تمت معالجة استفسارك بنجاح. تذكر الاستمرار بتمارين Face Pulls وإطالة الكمثرية.";

      msgIdRef.current += 1;
      const coachMsg: Message = {
        id: `c-${msgIdRef.current}`,
        sender: "coach",
        text: coachReply,
        timestamp: "الآن",
      };

      setMessages((prev) => [...prev, coachMsg]);
      spatialAudio.playRepComplete();
      HapticEngine.medium();
    } catch (e) {
      msgIdRef.current += 1;
      const fallbackMsg: Message = {
        id: `c-${msgIdRef.current}`,
        sender: "coach",
        text: "وفقاً لبروتوكول FitPulse Pro: احرص على تناول 1850 سعرة حرارية مع 120 جم بروتين، ومارس تمرين Face Pulls لشد القوام، مع إكمال خطوات المشي بصلالة لتفريغ الضغط عن ديسك L4-L5.",
        timestamp: "الآن",
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeakMessage = (text: string) => {
    spatialAudio.playClick();
    HapticEngine.tap();
    SpeechEngine.speak(text);
  };

  return (
    <div className="rounded-2xl bg-slate-900/90 border border-cyan-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col h-[560px]">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-500 flex items-center justify-center text-slate-950 font-bold shadow-[0_0_12px_rgba(0,243,255,0.3)]">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              الكوتش الرياضي والطبي الذكي (Gemini Spatial AI)
            </h3>
            <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              متصل | خوارزميات التضخيم وسلامة L4-L5
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            setMessages([
              {
                id: "m-0",
                sender: "coach",
                text: "أهلاً بك يا بطل! أنا جاهز للإجابة عن أي استفسار حول تمارينك ونظامك الغذائي وحماية فقرات L4-L5.",
                timestamp: "الآن",
              },
            ]);
            spatialAudio.playClick();
          }}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs transition"
          title="محادثة جديدة"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Prompt Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-2 mb-2 scrollbar-none">
        {quickPrompts.map((item, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(item.query)}
            className="px-3 py-1 rounded-xl text-[11px] font-medium bg-slate-950/80 border border-slate-800 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 whitespace-nowrap transition"
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1 scrollbar-none mb-3">
        {messages.map((msg) => {
          const isCoach = msg.sender === "coach";

          return (
            <div
              key={msg.id}
              className={`flex gap-2.5 ${isCoach ? "justify-start" : "justify-end"}`}
            >
              {isCoach && (
                <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5 border border-cyan-500/30">
                  <Bot className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`p-3.5 rounded-2xl max-w-[85%] text-xs leading-relaxed ${
                  isCoach
                    ? "bg-slate-950/80 text-slate-200 border border-cyan-500/20 shadow-md"
                    : "bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-medium shadow-md"
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>

                <div className="flex items-center justify-between gap-3 mt-2 pt-1.5 border-t border-slate-800/40 text-[10px] text-slate-400">
                  <span>{msg.timestamp}</span>

                  {isCoach && (
                    <button
                      onClick={() => handleSpeakMessage(msg.text)}
                      className="text-cyan-400 hover:text-cyan-200 flex items-center gap-1"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>قراءة</span>
                    </button>
                  )}
                </div>
              </div>

              {!isCoach && (
                <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5 border border-blue-500/30">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-2.5 items-center text-xs text-cyan-400 p-2">
            <Bot className="w-4 h-4 animate-spin" />
            <span>الكوتش يحلل البروتوكول ويجهز الإجابة...</span>
          </div>
        )}
      </div>

      {/* Input Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex items-center gap-2 pt-2 border-t border-slate-800"
      >
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="اسأل الكوتش عن التمارين، الوجبات، أو صحة الفقرات L4-L5..."
          className="flex-1 bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition"
        />

        <button
          type="submit"
          disabled={isLoading || !inputValue.trim()}
          className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 disabled:opacity-40 font-bold transition shadow-lg shrink-0"
        >
          <Send className="w-4 h-4 fill-slate-950 rotate-180" />
        </button>
      </form>
    </div>
  );
}
