"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import Image from "next/image";
import * as THREE from "three";
import {
  RotateCw,
  ZoomIn,
  ZoomOut,
  Sparkles,
  Eye,
  ShieldAlert,
  Layers,
  Volume2,
  Maximize2,
  RefreshCw,
  Activity,
  Flame,
  CheckCircle2,
} from "lucide-react";
import { MUSCLE_ANATOMY_CARDS } from "@/lib/data";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

export interface ThreeMuscleViewerProps {
  activeMuscleTarget?: string;
  onSelectMuscle?: (target: string) => void;
  showCardGrid?: boolean;
  compactMode?: boolean;
}

export default function ThreeMuscleViewer({
  activeMuscleTarget = "chest_triceps",
  onSelectMuscle,
  showCardGrid = true,
  compactMode = false,
}: ThreeMuscleViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedMuscle, setSelectedMuscle] = useState<string>(() => {
    return activeMuscleTarget === "chest" || activeMuscleTarget === "triceps"
      ? "chest_triceps"
      : activeMuscleTarget;
  });
  const [prevPropTarget, setPrevPropTarget] = useState<string>(activeMuscleTarget);

  if (activeMuscleTarget !== prevPropTarget) {
    setPrevPropTarget(activeMuscleTarget);
    const mapped =
      activeMuscleTarget === "chest" || activeMuscleTarget === "triceps"
        ? "chest_triceps"
        : activeMuscleTarget;
    setSelectedMuscle(mapped);
  }

  const selectedMuscleRef = useRef<string>(selectedMuscle);
  useEffect(() => {
    selectedMuscleRef.current = selectedMuscle;
  }, [selectedMuscle]);

  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const autoRotateRef = useRef<boolean>(false);
  const [viewAngle, setViewAngle] = useState<"front" | "back">("front");
  const [activeLayer, setActiveLayer] = useState<"muscles" | "spine_deep" | "hologram">("muscles");
  
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const bodyGroupRef = useRef<THREE.Group | null>(null);
  const muscleMeshesRef = useRef<{ [key: string]: THREE.Mesh[] }>({});
  const glowMeshesRef = useRef<{ [key: string]: THREE.Mesh[] }>({});
  const spineNodesRef = useRef<THREE.Mesh[]>([]);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  // Main Three.js Scene Setup & Anatomical Body Sculpting
  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth || 400;
    const height = containerRef.current.clientHeight || (compactMode ? 320 : 420);

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // 2. Camera: Positioned for anatomical upper torso focus matching the reference image
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 1000);
    camera.position.set(0, 1.45, 3.8);
    cameraRef.current = camera;

    // 3. Renderer with Antialias, Alpha, ToneMapping
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    rendererRef.current = renderer;

    while (containerRef.current.firstChild) {
      containerRef.current.removeChild(containerRef.current.firstChild);
    }
    containerRef.current.appendChild(renderer.domElement);

    // 4. Lighting Rig tailored for dark obsidian mannequin with neon cyan rims
    const ambientLight = new THREE.AmbientLight(0x0f172a, 1.2);
    scene.add(ambientLight);

    // Key Light (Crisp studio top-front)
    const keyLight = new THREE.DirectionalLight(0xe2e8f0, 1.8);
    keyLight.position.set(3, 6, 5);
    scene.add(keyLight);

    // Neon Cyan Rim Light (Left & Back)
    const cyanRim = new THREE.DirectionalLight(0x00f0ff, 2.8);
    cyanRim.position.set(-4, 3, -3);
    scene.add(cyanRim);

    // Electric Blue Rim Light (Right & Back)
    const blueRim = new THREE.DirectionalLight(0x0077ff, 2.4);
    blueRim.position.set(4, 2, -3);
    scene.add(blueRim);

    // Soft Bottom Fill Light
    const bottomLight = new THREE.PointLight(0x0284c7, 1.5, 8);
    bottomLight.position.set(0, -1, 2);
    scene.add(bottomLight);

    // 5. Build Anatomical Mannequin Physique Group
    const bodyGroup = new THREE.Group();
    bodyGroupRef.current = bodyGroup;
    scene.add(bodyGroup);

    // Materials
    const baseDarkSkinMat = new THREE.MeshStandardMaterial({
      color: 0x0f1422,
      roughness: 0.28,
      metalness: 0.72,
    });

    const wireframeOverlayMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      wireframe: true,
      transparent: true,
      opacity: 0.08,
    });

    const muscleMeshes: { [key: string]: THREE.Mesh[] } = {
      chest_triceps: [],
      chest: [],
      triceps: [],
      biceps: [],
      shoulders: [],
      back: [],
      abs: [],
      spine: [],
      legs: [],
      glutes: [],
    };

    const glowMeshes: { [key: string]: THREE.Mesh[] } = {
      chest_triceps: [],
      chest: [],
      triceps: [],
      biceps: [],
      shoulders: [],
      back: [],
      abs: [],
      spine: [],
      legs: [],
      glutes: [],
    };

    // Helper to add sculpted muscle segment with inner core & optional glow shell
    const addMuscleSegment = (
      geo: THREE.BufferGeometry,
      pos: [number, number, number],
      rot: [number, number, number] = [0, 0, 0],
      scale: [number, number, number] = [1, 1, 1],
      groupKeys: string[] = []
    ) => {
      const mesh = new THREE.Mesh(geo, baseDarkSkinMat.clone());
      mesh.position.set(...pos);
      mesh.rotation.set(...rot);
      mesh.scale.set(...scale);
      bodyGroup.add(mesh);

      // Subtle wireframe rim
      const wire = new THREE.Mesh(geo, wireframeOverlayMat);
      wire.position.set(...pos);
      wire.rotation.set(...rot);
      wire.scale.set(scale[0] * 1.015, scale[1] * 1.015, scale[2] * 1.015);
      bodyGroup.add(wire);

      // Outer Neon Glow Shell for active state
      const glowMat = new THREE.MeshBasicMaterial({
        color: 0x00f0ff,
        transparent: true,
        opacity: 0,
        side: THREE.BackSide,
      });
      const glowMesh = new THREE.Mesh(geo, glowMat);
      glowMesh.position.set(...pos);
      glowMesh.rotation.set(...rot);
      glowMesh.scale.set(scale[0] * 1.04, scale[1] * 1.04, scale[2] * 1.04);
      bodyGroup.add(glowMesh);

      groupKeys.forEach((key) => {
        if (muscleMeshes[key]) muscleMeshes[key].push(mesh);
        if (glowMeshes[key]) glowMeshes[key].push(glowMesh);
      });

      return mesh;
    };

    // --- HIGH-PRECISION ANATOMICAL SCULPTING (UPPER TORSO FOCUS) ---

    // 1. Head, Cranium & Jawline
    addMuscleSegment(new THREE.SphereGeometry(0.26, 32, 32), [0, 2.38, 0], [0, 0, 0], [1, 1.15, 1.05]);
    // Jaw & Chin
    addMuscleSegment(new THREE.BoxGeometry(0.22, 0.16, 0.22), [0, 2.18, 0.08], [0.15, 0, 0], [1, 0.8, 1]);
    // Neck & Sternocleidomastoid
    addMuscleSegment(new THREE.CylinderGeometry(0.14, 0.18, 0.28, 24), [0, 2.02, -0.02], [0, 0, 0]);

    // 2. Trapezius (Upper Back & Neck Transition)
    addMuscleSegment(new THREE.BoxGeometry(0.58, 0.22, 0.28), [0, 1.96, -0.08], [0.1, 0, 0], [1, 0.7, 0.9], ["back"]);

    // 3. Clavicles (Collarbones)
    addMuscleSegment(new THREE.CylinderGeometry(0.04, 0.04, 0.78, 16), [0, 1.84, 0.12], [0, 0, Math.PI / 2]);

    // 4. Deltoids (Shoulders) - Anterior, Lateral & Posterior Caps
    // Left Deltoid
    addMuscleSegment(new THREE.SphereGeometry(0.21, 24, 24), [-0.68, 1.76, 0.02], [0, 0, -0.2], [1.1, 1.25, 1.0], ["shoulders"]);
    addMuscleSegment(new THREE.SphereGeometry(0.16, 20, 20), [-0.75, 1.74, 0.05], [0, 0, 0], [1, 1, 1], ["shoulders"]);
    // Right Deltoid
    addMuscleSegment(new THREE.SphereGeometry(0.21, 24, 24), [0.68, 1.76, 0.02], [0, 0, 0.2], [1.1, 1.25, 1.0], ["shoulders"]);
    addMuscleSegment(new THREE.SphereGeometry(0.16, 20, 20), [0.75, 1.74, 0.05], [0, 0, 0], [1, 1, 1], ["shoulders"]);

    // 5. Pectoralis Major & Minor (Chest Plates) - EXACT MATCH to Reference Hologram
    // Left Upper Pectoral (Clavicular head)
    addMuscleSegment(
      new THREE.BoxGeometry(0.34, 0.24, 0.18),
      [-0.21, 1.72, 0.17],
      [-0.08, 0.15, -0.08],
      [1.1, 1.05, 1.1],
      ["chest", "chest_triceps"]
    );
    // Right Upper Pectoral
    addMuscleSegment(
      new THREE.BoxGeometry(0.34, 0.24, 0.18),
      [0.21, 1.72, 0.17],
      [-0.08, -0.15, 0.08],
      [1.1, 1.05, 1.1],
      ["chest", "chest_triceps"]
    );
    // Left Lower Pectoral (Sternal head & sweep)
    addMuscleSegment(
      new THREE.BoxGeometry(0.35, 0.25, 0.17),
      [-0.22, 1.51, 0.16],
      [0.05, 0.1, -0.06],
      [1.15, 1.0, 1.1],
      ["chest", "chest_triceps"]
    );
    // Right Lower Pectoral
    addMuscleSegment(
      new THREE.BoxGeometry(0.35, 0.25, 0.17),
      [0.22, 1.51, 0.16],
      [0.05, -0.1, 0.06],
      [1.15, 1.0, 1.1],
      ["chest", "chest_triceps"]
    );

    // 6. Biceps (Anterior Arms)
    // Left Bicep
    addMuscleSegment(
      new THREE.CapsuleGeometry(0.11, 0.28, 16, 16),
      [-0.78, 1.38, 0.06],
      [0.15, 0, -0.18],
      [1, 1.1, 1],
      ["biceps"]
    );
    // Right Bicep
    addMuscleSegment(
      new THREE.CapsuleGeometry(0.11, 0.28, 16, 16),
      [0.78, 1.38, 0.06],
      [0.15, 0, 0.18],
      [1, 1.1, 1],
      ["biceps"]
    );

    // 7. Triceps (Posterior Arms & Horseshoe Contour) - EXACT MATCH to Reference Hologram
    // Left Tricep
    addMuscleSegment(
      new THREE.CylinderGeometry(0.12, 0.09, 0.38, 20),
      [-0.79, 1.36, -0.08],
      [-0.2, 0, 0.18],
      [1.1, 1.05, 1.1],
      ["triceps", "chest_triceps"]
    );
    addMuscleSegment(
      new THREE.SphereGeometry(0.1, 16, 16),
      [-0.82, 1.44, -0.06],
      [0, 0, 0],
      [1, 1.2, 0.9],
      ["triceps", "chest_triceps"]
    );
    // Right Tricep
    addMuscleSegment(
      new THREE.CylinderGeometry(0.12, 0.09, 0.38, 20),
      [0.79, 1.36, -0.08],
      [-0.2, 0, -0.18],
      [1.1, 1.05, 1.1],
      ["triceps", "chest_triceps"]
    );
    addMuscleSegment(
      new THREE.SphereGeometry(0.1, 16, 16),
      [0.82, 1.44, -0.06],
      [0, 0, 0],
      [1, 1.2, 0.9],
      ["triceps", "chest_triceps"]
    );

    // Forearms
    addMuscleSegment(new THREE.CylinderGeometry(0.09, 0.07, 0.44, 16), [-0.88, 0.92, 0.14], [0.35, 0, 0.2]);
    addMuscleSegment(new THREE.CylinderGeometry(0.09, 0.07, 0.44, 16), [0.88, 0.92, 0.14], [0.35, 0, -0.2]);

    // 8. Serratus Anterior & External Obliques (Rib contours)
    for (let r = 0; r < 3; r++) {
      addMuscleSegment(
        new THREE.BoxGeometry(0.14, 0.07, 0.14),
        [-0.42, 1.38 - r * 0.11, 0.06],
        [0, 0, 0.35],
        [1, 1, 1],
        ["abs"]
      );
      addMuscleSegment(
        new THREE.BoxGeometry(0.14, 0.07, 0.14),
        [0.42, 1.38 - r * 0.11, 0.06],
        [0, 0, -0.35],
        [1, 1, 1],
        ["abs"]
      );
    }

    // 9. Six-Pack Rectus Abdominis Grid (Linea Alba & Inscribed Muscle Bricks)
    const absYStarts = [1.32, 1.16, 1.0];
    absYStarts.forEach((y, rowIdx) => {
      // Left Ab Pad
      addMuscleSegment(
        new THREE.BoxGeometry(0.16, 0.12, 0.12),
        [-0.11, y, 0.16],
        [0.05, 0.05, 0],
        [1.05, 1, 1],
        ["abs"]
      );
      // Right Ab Pad
      addMuscleSegment(
        new THREE.BoxGeometry(0.16, 0.12, 0.12),
        [0.11, y, 0.16],
        [0.05, -0.05, 0],
        [1.05, 1, 1],
        ["abs"]
      );
    });

    // 10. Latissimus Dorsi (V-Taper Wings)
    addMuscleSegment(new THREE.BoxGeometry(0.42, 0.58, 0.24), [-0.38, 1.42, -0.1], [0, 0.12, -0.18], [1, 1, 1], ["back"]);
    addMuscleSegment(new THREE.BoxGeometry(0.42, 0.58, 0.24), [0.38, 1.42, -0.1], [0, -0.12, 0.18], [1, 1, 1], ["back"]);

    // 11. Lumbar Spinal Column (L1-L5 Disc Protection Focus)
    const spineNodes: THREE.Mesh[] = [];
    const spineGroup = new THREE.Group();
    for (let i = 0; i < 5; i++) {
      const isL4L5 = i >= 3;
      const discGeo = new THREE.CylinderGeometry(0.1, 0.11, 0.06, 20);
      const discMat = new THREE.MeshStandardMaterial({
        color: isL4L5 ? 0xef4444 : 0x00f0ff,
        emissive: isL4L5 ? 0xf43f5e : 0x0284c7,
        emissiveIntensity: 0.9,
        roughness: 0.2,
      });
      const disc = new THREE.Mesh(discGeo, discMat);
      disc.position.set(0, 0.88 + i * 0.08, -0.14);
      disc.rotation.x = Math.PI / 2;
      spineGroup.add(disc);
      spineNodes.push(disc);
    }
    bodyGroup.add(spineGroup);
    spineNodesRef.current = spineNodes;
    muscleMeshes["spine"] = spineNodes;

    // 12. Pelvis, Glutes & Upper Thighs
    addMuscleSegment(new THREE.BoxGeometry(0.68, 0.38, 0.38), [0, 0.62, -0.02], [0, 0, 0], [1, 1, 1], ["glutes"]);
    addMuscleSegment(new THREE.CylinderGeometry(0.19, 0.14, 0.65, 20), [-0.25, 0.15, 0.02], [0, 0, -0.06], [1, 1, 1], ["legs"]);
    addMuscleSegment(new THREE.CylinderGeometry(0.19, 0.14, 0.65, 20), [0.25, 0.15, 0.02], [0, 0, 0.06], [1, 1, 1], ["legs"]);

    // Holographic Base Ring & Ground Radial Grid
    const ringGeo = new THREE.RingGeometry(1.3, 1.45, 48);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.3,
    });
    const groundRing = new THREE.Mesh(ringGeo, ringMat);
    groundRing.rotation.x = Math.PI / 2;
    groundRing.position.y = -0.25;
    scene.add(groundRing);

    const innerGrid = new THREE.GridHelper(4, 12, 0x00f0ff, 0x1e293b);
    innerGrid.position.y = -0.26;
    scene.add(innerGrid);

    muscleMeshesRef.current = muscleMeshes;
    glowMeshesRef.current = glowMeshes;

    // 6. Interactive Pointer Orbiting
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onPointerDown = (e: PointerEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!isDragging || !bodyGroupRef.current) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      bodyGroupRef.current.rotation.y += deltaX * 0.012;
      bodyGroupRef.current.rotation.x += deltaY * 0.006;
      bodyGroupRef.current.rotation.x = Math.max(-0.35, Math.min(0.35, bodyGroupRef.current.rotation.x));
    };

    const onPointerUp = () => {
      isDragging = false;
    };

    const domElem = renderer.domElement;
    domElem.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);

    // 7. Animation Loop with Bio-Electric Pulsing Shaders
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      if (autoRotateRef.current && bodyGroupRef.current) {
        bodyGroupRef.current.rotation.y += 0.008;
      }

      // Bio-pulse for active target muscles
      const activeKey = selectedMuscleRef.current;
      const glowList = glowMeshesRef.current[activeKey] || [];
      const pulseVal = 0.55 + Math.sin(elapsed * 4.5) * 0.35;

      glowList.forEach((glowMesh) => {
        const mat = glowMesh.material as THREE.MeshBasicMaterial;
        mat.opacity = pulseVal * 0.45;
      });

      // L4-L5 Lumbar Pulse
      spineNodes.forEach((node, idx) => {
        if (idx >= 3) {
          const mat = node.material as THREE.MeshStandardMaterial;
          mat.emissiveIntensity = 0.6 + Math.sin(elapsed * 5.0) * 0.5;
        }
      });

      // Holographic Ring Spin
      groundRing.rotation.z += 0.004;

      renderer.render(scene, camera);
    };

    animate();

    // 8. Resize Observer
    const handleResize = () => {
      if (!containerRef.current || !renderer || !camera) return;
      const newWidth = containerRef.current.clientWidth;
      const newHeight = containerRef.current.clientHeight || (compactMode ? 320 : 420);
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      domElem.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      renderer.dispose();
    };
  }, [compactMode]);

  // Update Highlighted Muscle Colors & Glow Materials
  useEffect(() => {
    const meshes = muscleMeshesRef.current;
    const glowMeshes = glowMeshesRef.current;
    if (!meshes) return;

    Object.keys(meshes).forEach((key) => {
      const isTarget = key === selectedMuscle;
      const groupMeshes = meshes[key] || [];
      const groupGlows = glowMeshes[key] || [];

      groupMeshes.forEach((mesh) => {
        const mat = mesh.material as THREE.MeshStandardMaterial;
        if (isTarget) {
          if (key === "spine") {
            mat.color.setHex(0xef4444);
            mat.emissive.setHex(0xf43f5e);
            mat.emissiveIntensity = 1.4;
          } else if (key === "chest_triceps" || key === "chest") {
            // Hyper-vibrant Electric Cyan to match reference image
            mat.color.setHex(0x00f0ff);
            mat.emissive.setHex(0x00b4d8);
            mat.emissiveIntensity = 1.8;
          } else if (key === "triceps") {
            mat.color.setHex(0xf97316);
            mat.emissive.setHex(0xea580c);
            mat.emissiveIntensity = 1.6;
          } else {
            mat.color.setHex(0x38bdf8);
            mat.emissive.setHex(0x0284c7);
            mat.emissiveIntensity = 1.5;
          }
        } else {
          mat.color.setHex(0x0f1422);
          mat.emissive.setHex(0x000000);
          mat.emissiveIntensity = 0;
        }
      });

      groupGlows.forEach((glow) => {
        const mat = glow.material as THREE.MeshBasicMaterial;
        if (isTarget) {
          if (key === "spine") mat.color.setHex(0xf43f5e);
          else if (key === "triceps") mat.color.setHex(0xf97316);
          else mat.color.setHex(0x00f0ff);
          mat.opacity = 0.35;
        } else {
          mat.opacity = 0;
        }
      });
    });
  }, [selectedMuscle]);

  const handleSelectGroup = (key: string) => {
    setSelectedMuscle(key);
    spatialAudio.playClick();
    HapticEngine.tap();
    if (onSelectMuscle) onSelectMuscle(key);
  };

  const handleFlipView = (angle: "front" | "back") => {
    setViewAngle(angle);
    if (!bodyGroupRef.current) return;
    bodyGroupRef.current.rotation.y = angle === "back" ? Math.PI : 0;
    bodyGroupRef.current.rotation.x = 0;
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  const handleZoom = (dir: "in" | "out") => {
    if (!cameraRef.current) return;
    const delta = dir === "in" ? -0.4 : 0.4;
    const newZ = cameraRef.current.position.z + delta;
    if (newZ >= 2.2 && newZ <= 6.5) {
      cameraRef.current.position.z = newZ;
      spatialAudio.playClick();
      HapticEngine.tap();
    }
  };

  const handleVoiceAnatomy = () => {
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    const targetInfo = getTargetLabel(selectedMuscle);
    SpeechEngine.speak(
      `المجموعة العضلية النشطة: ${targetInfo.titleAr}. الاستهداف: ${targetInfo.descAr}. بروتوكول حماية الفقرات L4-L5 مفعل.`
    );
  };

  const getTargetLabel = (key: string) => {
    switch (key) {
      case "chest_triceps":
        return {
          titleEn: "CHEST & TRICEPS",
          titleAr: "الصدر والترايسبس (استهداف القوة الدافعة)",
          descAr: "تضخيم الصدر العلوي والأوسط مع تقوية الرأس الطويل للترايسبس دون إجهاد قطني",
          color: "text-[#00f0ff]",
          badgeBg: "bg-[#00f0ff]/10 border-[#00f0ff]/40",
        };
      case "chest":
        return {
          titleEn: "CHEST (PECTORALS)",
          titleAr: "عضلات الصدر (الكبرى والصغرى)",
          descAr: "بناء درع علوي وتكثيف خط الصدر الداخلي",
          color: "text-[#00f0ff]",
          badgeBg: "bg-[#00f0ff]/10 border-[#00f0ff]/40",
        };
      case "triceps":
        return {
          titleEn: "TRICEPS HORSESHOE",
          titleAr: "الترايسبس (65% من الذراع)",
          descAr: "نحت حذوة الحصان والدفع الصاروخي",
          color: "text-orange-400",
          badgeBg: "bg-orange-500/10 border-orange-500/40",
        };
      case "spine":
        return {
          titleEn: "L4-L5 LUMBAR SPINE",
          titleAr: "الفقرات القطنية L4-L5 وعرق النسا",
          descAr: "تفريغ الضغط الغضروفي وحماية العصب الوركي",
          color: "text-rose-400",
          badgeBg: "bg-rose-500/10 border-rose-500/40",
        };
      case "back":
        return {
          titleEn: "BACK & V-TAPER",
          titleAr: "الظهر والمجنص (V-Taper)",
          descAr: "توسيع إطار الظهر وتعديل استقامة القوام",
          color: "text-indigo-400",
          badgeBg: "bg-indigo-500/10 border-indigo-500/40",
        };
      case "shoulders":
        return {
          titleEn: "DELTOIDS & POSTURE",
          titleAr: "الكتف والقوام (Face Pulls)",
          descAr: "تعريض الكتف الجانبي وفتح الصدر كبديل لمشد الظهر",
          color: "text-blue-400",
          badgeBg: "bg-blue-500/10 border-blue-500/40",
        };
      case "abs":
        return {
          titleEn: "CORE & 6-PACK",
          titleAr: "البطن والكور (الحزام الطبيعي)",
          descAr: "تقوية عضلات البطن المستعرضة لتثبيت القطنية",
          color: "text-teal-400",
          badgeBg: "bg-teal-500/10 border-teal-500/40",
        };
      case "legs":
      case "glutes":
        return {
          titleEn: "LEGS & GLUTES",
          titleAr: "الأرجل وإطالة الكمثرية",
          descAr: "جسر المقعدة وتحرير العصب الوركي",
          color: "text-amber-400",
          badgeBg: "bg-amber-500/10 border-amber-500/40",
        };
      default:
        return {
          titleEn: "CHEST & TRICEPS",
          titleAr: "الصدر والترايسبس",
          descAr: "استهداف التضخيم النظيف",
          color: "text-[#00f0ff]",
          badgeBg: "bg-[#00f0ff]/10 border-[#00f0ff]/40",
        };
    }
  };

  const activeTargetInfo = getTargetLabel(selectedMuscle);

  const musclePresets = [
    { key: "chest_triceps", label: "CHEST & TRICEPS (المظهر المطابق)", badge: "مطابق للصورة" },
    { key: "spine", label: "L4-L5 الغضروف القطني", badge: "طبي" },
    { key: "shoulders", label: "الكتف والقوام (Face Pulls)", badge: "" },
    { key: "back", label: "الظهر والمجنص (V-Taper)", badge: "" },
    { key: "biceps", label: "البايسبس والساعد", badge: "" },
    { key: "abs", label: "البطن والكور (6-Pack)", badge: "" },
    { key: "glutes", label: "الأرجل وعرق النسا", badge: "" },
  ];

  return (
    <div className="space-y-4" id="apex-anatomy-viewer">
      {/* 3D Model Main Obsidian Card Matching APEX FITNESS Reference */}
      <div className="relative w-full rounded-3xl bg-[#090d16] border border-slate-800/90 p-4 sm:p-6 shadow-2xl overflow-hidden backdrop-blur-xl">
        {/* Glow backdrop blur */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-[#00f0ff]/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 right-10 w-60 h-60 bg-indigo-600/10 rounded-full blur-[90px] pointer-events-none" />

        {/* Top Header Controls */}
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 flex items-center justify-center text-[#00f0ff] shadow-[0_0_12px_rgba(0,240,255,0.2)]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase">
                  APEX FITNESS
                </span>
                <span className="text-slate-600">|</span>
                <span className="text-xs font-bold text-white tracking-wide">
                  SPATIAL ANATOMY 3D
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono">
                مجسم تشريحي ثلاثي الأبعاد دقيق للغاية مع محاكاة التوهج العضلي
              </p>
            </div>
          </div>

          {/* Tools & View Actions */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {/* Flip Front / Back */}
            <div className="bg-slate-900 border border-slate-800 p-0.5 rounded-xl flex items-center">
              <button
                onClick={() => handleFlipView("front")}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-mono transition ${
                  viewAngle === "front"
                    ? "bg-[#00f0ff]/20 text-[#00f0ff] font-bold border border-[#00f0ff]/40 shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                أمامي (Front)
              </button>
              <button
                onClick={() => handleFlipView("back")}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-mono transition ${
                  viewAngle === "back"
                    ? "bg-[#00f0ff]/20 text-[#00f0ff] font-bold border border-[#00f0ff]/40 shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                خلفي (Back)
              </button>
            </div>

            {/* Voice Anatomy */}
            <button
              onClick={handleVoiceAnatomy}
              className="p-1.5 px-2.5 rounded-xl text-xs bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 hover:text-[#00f0ff] transition flex items-center gap-1"
              title="سماع الشرح صوتياً"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span className="text-[10px]">صوت</span>
            </button>

            {/* Auto Rotate */}
            <button
              onClick={() => {
                setAutoRotate(!autoRotate);
                spatialAudio.playClick();
                HapticEngine.tap();
              }}
              className={`p-1.5 px-2 rounded-xl text-xs border transition ${
                autoRotate
                  ? "bg-[#00f0ff]/20 border-[#00f0ff] text-[#00f0ff] shadow-[0_0_10px_rgba(0,240,255,0.3)]"
                  : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
              }`}
              title="تدوير 360°"
            >
              <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? "animate-spin" : ""}`} />
            </button>

            {/* Zoom In / Out */}
            <button
              onClick={() => handleZoom("in")}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 transition"
              title="تكبير"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => handleZoom("out")}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-[#00f0ff]/50 text-slate-300 transition"
              title="تصغير"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 3D Canvas Viewport (Matching Reference Holographic Mannequin) */}
        <div className="relative w-full h-[320px] sm:h-[400px] my-3 rounded-2xl bg-gradient-to-b from-[#060913] via-[#090e1b] to-[#04060c] border border-slate-800/80 flex flex-col items-center justify-between touch-none overflow-hidden group">
          {/* Three.js Render Target */}
          <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

          {/* Top Instruction Badge */}
          <div className="absolute top-3 left-3 bg-[#090d16]/90 border border-slate-800/90 rounded-xl px-2.5 py-1 text-[10px] text-slate-300 flex items-center gap-1.5 shadow-md backdrop-blur-md font-mono">
            <Eye className="w-3 h-3 text-[#00f0ff]" />
            <span>اسحب 360° للتدوير التفاعلي</span>
          </div>

          {/* Exact Hologram Text from Reference Image: TARGET: CHEST & TRICEPS */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center pointer-events-none">
            <div className="flex items-center gap-2 px-4 py-1.5 rounded-2xl bg-[#090d16]/95 border border-[#00f0ff]/40 shadow-[0_0_20px_rgba(0,240,255,0.25)] backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-[#00f0ff] animate-ping" />
              <span className="text-xs sm:text-sm font-black tracking-widest text-[#00f0ff] font-mono uppercase drop-shadow-[0_0_10px_rgba(0,240,255,0.8)]">
                TARGET: {activeTargetInfo.titleEn}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 mt-1 font-mono tracking-tight text-center">
              {activeTargetInfo.titleAr}
            </span>
          </div>

          {/* L4-L5 Spine Telemetry Alert Overlay if selected */}
          {selectedMuscle === "spine" && (
            <div className="absolute bottom-16 right-3 bg-red-950/90 border border-red-500/50 rounded-2xl p-3 text-xs text-red-200 max-w-[260px] shadow-2xl backdrop-blur-md z-20">
              <div className="flex items-center gap-1.5 text-red-400 font-bold text-xs mb-1">
                <ShieldAlert className="w-4 h-4" />
                <span>حماية غضروف L4-L5</span>
              </div>
              <p className="text-[10px] leading-relaxed text-slate-300">
                إلغاء مشد الظهر + تمارين Face Pulls وجسر المقعدة يمنعان الضغط على العصب الوركي.
              </p>
            </div>
          )}
        </div>

        {/* Quick Muscle Selector Pills */}
        <div className="relative z-10 pt-1 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>المجموعات العضلية المعتمدة:</span>
            <span className="text-[#00f0ff] font-mono text-[11px] font-bold">
              {activeTargetInfo.titleEn}
            </span>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {musclePresets.map((preset) => {
              const isSelected = preset.key === selectedMuscle;
              return (
                <button
                  key={preset.key}
                  onClick={() => handleSelectGroup(preset.key)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all duration-200 flex items-center gap-1.5 ${
                    isSelected
                      ? "bg-[#00f0ff]/15 border-[#00f0ff] text-[#00f0ff] font-bold shadow-[0_0_15px_rgba(0,240,255,0.25)] scale-105"
                      : "bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                  }`}
                >
                  <span>{preset.label}</span>
                  {preset.badge && (
                    <span
                      className={`text-[9px] px-1 py-0.2 rounded font-mono ${
                        preset.badge === "مطابق للصورة"
                          ? "bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/30"
                          : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                      }`}
                    >
                      {preset.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Muscle Visual Reference Cards Grid */}
      {showCardGrid && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#00f0ff]" />
              البطاقات التشريحية للسلسلة العضلية (8 مجموعات رئيسية)
            </h3>
            <span className="text-xs text-slate-500 font-mono">3D NEURAL SYNC</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {MUSCLE_ANATOMY_CARDS.map((card) => {
              const isSelected =
                card.key === selectedMuscle ||
                (selectedMuscle === "chest_triceps" && (card.key === "chest" || card.key === "triceps"));

              return (
                <div
                  key={card.key}
                  onClick={() => handleSelectGroup(card.key === "chest" ? "chest_triceps" : card.key)}
                  className={`rounded-3xl border overflow-hidden cursor-pointer transition-all duration-200 flex flex-col justify-between shadow-xl ${
                    isSelected
                      ? "bg-[#0b101e] border-[#00f0ff] ring-1 ring-[#00f0ff]/40 shadow-[0_0_20px_rgba(0,240,255,0.15)]"
                      : "bg-[#090d16] border-slate-800/80 hover:border-slate-700"
                  }`}
                >
                  <div className="relative h-28 w-full bg-slate-950 overflow-hidden">
                    <Image
                      src={card.imageUrl}
                      alt={card.nameAr}
                      fill
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#090d16] via-[#090d16]/50 to-transparent" />
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded-lg text-[10px] font-bold bg-[#090d16]/90 text-[#00f0ff] border border-slate-700 font-mono">
                      {card.nameEn}
                    </span>
                    <span className="absolute bottom-2 left-2 text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                      {card.targetCount} تمارين معتمدة
                    </span>
                  </div>

                  <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className={`text-xs font-bold ${isSelected ? "text-[#00f0ff]" : "text-white"}`}>
                        {card.nameAr}
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        {card.functionAr}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 space-y-1 text-[10px]">
                      <div className="text-amber-300/90 font-medium">
                        <b>التضخيم:</b> {card.hypertrophyFocus}
                      </div>
                      <div className="text-cyan-300/90 font-medium">
                        <b>الأمان القطني:</b> {card.spineSafetyRole}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
