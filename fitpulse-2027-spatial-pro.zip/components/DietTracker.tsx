"use client";

import React, { useState } from "react";
import Image from "next/image";
import {
  Utensils,
  Flame,
  CheckCircle2,
  Droplet,
  Plus,
  Sparkles,
  Clock,
  Volume2,
  Scale,
  Award,
  ChevronDown,
  ChevronUp,
  Circle,
  Apple,
  Check,
} from "lucide-react";
import { DAILY_MEALS, MealItem } from "@/lib/data";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

export default function DietTracker() {
  const [meals, setMeals] = useState<MealItem[]>(DAILY_MEALS);
  const [completedMealIds, setCompletedMealIds] = useState<string[]>(["breakfast"]);
  const [waterGlasses, setWaterGlasses] = useState<number>(8); // 8 x 250ml = 2000ml out of 3500ml
  const [expandedMealId, setExpandedMealId] = useState<string | null>("breakfast");

  const totalCaloriesTarget = 1830;
  const totalProteinTarget = 118;
  const totalCarbsTarget = 187;
  const totalFatsTarget = 45;
  const waterTargetMl = 3500;

  // Calculate consumed
  const consumedCalories = meals
    .filter((m) => completedMealIds.includes(m.id))
    .reduce((acc, m) => acc + m.calories, 0);

  const consumedProtein = meals
    .filter((m) => completedMealIds.includes(m.id))
    .reduce((acc, m) => acc + m.protein, 0);

  const consumedCarbs = meals
    .filter((m) => completedMealIds.includes(m.id))
    .reduce((acc, m) => acc + m.carbs, 0);

  const consumedFats = meals
    .filter((m) => completedMealIds.includes(m.id))
    .reduce((acc, m) => acc + m.fats, 0);

  const currentWaterMl = waterGlasses * 250;

  const toggleMealCompleted = (id: string) => {
    const isCompleted = completedMealIds.includes(id);
    const newCompleted = isCompleted
      ? completedMealIds.filter((item) => item !== id)
      : [...completedMealIds, id];

    setCompletedMealIds(newCompleted);

    if (!isCompleted) {
      spatialAudio.playRepComplete();
      HapticEngine.success();
    } else {
      spatialAudio.playClick();
      HapticEngine.tap();
    }
  };

  const handleAddWater = () => {
    if (waterGlasses < 16) {
      setWaterGlasses(waterGlasses + 1);
      spatialAudio.playClick();
      HapticEngine.tap();
    }
  };

  const handleVoiceDiet = () => {
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    const text = `جدول الوجبات للتضخيم الصافي 1830 سعرة حرارية و 118 جرام بروتين: الإفطار 3 بيضات مسلوقة وخبز أسمر مع خيار وطماطم. السناك كوب حليب وموزة قبل التمرين. الغداء صدر دجاج أو تونة أو عدس مع 7 ملاعق أرز وسلطة. العشاء زبادي وجبن قريش مع زيت زيتون وخيار.`;
    SpeechEngine.speak(text);
  };

  return (
    <div className="space-y-4">
      {/* Diet Top Header */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              CLEAN HYPERTROPHY NUTRITION
            </span>
            <span className="px-2.5 py-0.5 rounded-md text-[10px] bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-mono">
              1800 - 1850 Kcal | 118g Protein
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Utensils className="w-6 h-6 text-amber-400" />
            وجبات التضخيم الصافي وحلقات الماكروز الحية
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
            وجبات منزلية واقعية محسوبة السعرات لدعم البناء العضلي الصافي وترطيب الديسك L4-L5 بدون زيادة دهون حشوية.
          </p>
        </div>

        <button
          onClick={handleVoiceDiet}
          className="px-4 py-2 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-xs font-bold transition flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 shrink-0"
        >
          <Volume2 className="w-4 h-4 text-amber-400" />
          قراءة الوجبات صوتياً
        </button>
      </div>

      {/* Infographic Macro Rings & Hydration Bento */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Calories Ring */}
        <div className="rounded-3xl bg-slate-900 border border-slate-800 p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] text-slate-400 font-bold">السعرات</span>
            <Flame className="w-4 h-4 text-amber-400" />
          </div>
          <div className="space-y-1">
            <div className="flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-bold text-amber-400 font-mono">
                {consumedCalories}
              </span>
              <span className="text-[10px] text-slate-500 font-mono">/ {totalCaloriesTarget}</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-orange-400 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (consumedCalories / totalCaloriesTarget) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Protein Ring */}
        <div className="rounded-3xl bg-slate-900 border border-slate-800 p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] text-slate-400 font-bold">البروتين النقي</span>
            <Scale className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="space-y-1">
            <div className="flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-bold text-emerald-400 font-mono">
                {consumedProtein}g
              </span>
              <span className="text-[10px] text-slate-500 font-mono">/ {totalProteinTarget}g</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (consumedProtein / totalProteinTarget) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Carbs */}
        <div className="rounded-3xl bg-slate-900 border border-slate-800 p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] text-slate-400 font-bold">الكربوهيدرات</span>
            <Apple className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="space-y-1">
            <div className="flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-bold text-indigo-400 font-mono">
                {consumedCarbs}g
              </span>
              <span className="text-[10px] text-slate-500 font-mono">/ {totalCarbsTarget}g</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-blue-400 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (consumedCarbs / totalCarbsTarget) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Disc Hydration Water */}
        <div className="rounded-3xl bg-slate-900 border border-cyan-500/30 p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] text-cyan-300 font-bold">ترطيب L4-L5</span>
            <button
              onClick={handleAddWater}
              className="px-2 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/40 text-[10px] font-bold border border-cyan-500/40 transition"
              title="إضافة 250 مل ماء"
            >
              +250ml
            </button>
          </div>
          <div className="space-y-1">
            <div className="flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-bold text-cyan-400 font-mono">
                {(currentWaterMl / 1000).toFixed(2)}L
              </span>
              <span className="text-[10px] text-slate-500 font-mono">/ 3.5L</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (currentWaterMl / waterTargetMl) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Visual Meal Cards Grid with Ultra-Crisp Photography */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {meals.map((meal) => {
          const isDone = completedMealIds.includes(meal.id);
          const isExpanded = expandedMealId === meal.id;

          return (
            <div
              key={meal.id}
              className={`rounded-3xl border transition-all duration-200 overflow-hidden shadow-lg flex flex-col justify-between ${
                isDone
                  ? "bg-slate-900/90 border-emerald-500/40"
                  : "bg-slate-900 border-slate-800 hover:border-amber-500/40"
              }`}
            >
              {/* Photo Banner with Badges */}
              <div className="relative h-44 w-full bg-slate-950 overflow-hidden">
                <Image
                  src={meal.imageUrl}
                  alt={meal.nameAr}
                  fill
                  className="object-cover transition-transform duration-500 hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                {/* Floating Badges */}
                <div className="absolute top-3 right-3 flex items-center gap-1.5 flex-wrap">
                  <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-slate-950/80 backdrop-blur text-white border border-slate-700/60 shadow-md">
                    {meal.badge}
                  </span>
                  <span className="px-2.5 py-1 rounded-xl text-[10px] font-mono font-bold bg-indigo-950/80 backdrop-blur text-indigo-300 border border-indigo-500/30">
                    {meal.timeSlot}
                  </span>
                </div>

                {/* Checkbox Overlay */}
                <button
                  onClick={() => toggleMealCompleted(meal.id)}
                  className={`absolute top-3 left-3 p-2 rounded-2xl backdrop-blur transition border ${
                    isDone
                      ? "bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/30"
                      : "bg-slate-950/80 text-slate-400 border-slate-700 hover:text-white"
                  }`}
                  title={isDone ? "تم تناول الوجبة" : "تسجيل تناول الوجبة"}
                >
                  {isDone ? <Check className="w-4 h-4 stroke-[3]" /> : <Circle className="w-4 h-4" />}
                </button>

                {/* Macro summary pills at bottom of banner */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs font-mono">
                  <span className="text-white font-bold text-sm bg-slate-950/80 px-2.5 py-1 rounded-xl border border-slate-800">
                    {meal.calories} Kcal
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded-lg border border-emerald-500/30 text-[10px]">
                      {meal.protein}g P
                    </span>
                    <span className="text-indigo-300 bg-indigo-950/80 px-2 py-0.5 rounded-lg border border-indigo-500/30 text-[10px]">
                      {meal.carbs}g C
                    </span>
                    <span className="text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded-lg border border-amber-500/30 text-[10px]">
                      {meal.fats}g F
                    </span>
                  </div>
                </div>
              </div>

              {/* Content Body */}
              <div className="p-4 sm:p-5 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <h3
                    className={`text-base font-bold transition mb-1 ${
                      isDone ? "text-slate-300 line-through decoration-emerald-500/80" : "text-white"
                    }`}
                  >
                    {meal.nameAr}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{meal.descriptionAr}</p>
                </div>

                {/* Ingredients List */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    المكونات المحسوبة:
                  </span>
                  <div className="space-y-1">
                    {meal.components.map((comp, idx) => (
                      <div
                        key={idx}
                        className="text-[11px] text-slate-300 bg-slate-950/60 p-2 rounded-xl border border-slate-800 flex items-center gap-2"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                        <span>{comp}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Physiology Tip */}
                <div className="p-2.5 rounded-xl bg-amber-950/20 border border-amber-500/20 text-[11px] text-amber-300 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{meal.tipsAr}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
