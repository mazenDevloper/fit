"use client";

import React, { useState, useEffect } from "react";
import {
  Code,
  Zap,
  Volume2,
  Mic,
  Activity,
  Vibrate,
  MapPin,
  Share2,
  Battery,
  Wifi,
  Copy,
  Gauge,
  Sparkles,
  CheckCircle2,
  Radio,
  Eye,
  ShieldAlert,
  Calendar,
  Lock,
  Cpu,
} from "lucide-react";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

interface ApiItem {
  id: number;
  name: string;
  nameAr: string;
  category: string;
  status: "Active" | "Ready" | "Hardware Dependent";
  descriptionAr: string;
  actionLabel: string;
  onTest: () => void;
}

export default function ApiShowcase() {
  const [activeApiTestResult, setActiveApiTestResult] = useState<string | null>(null);
  const [batteryLevel, setBatteryLevel] = useState<string>("88%");
  const [networkStatus, setNetworkStatus] = useState<string>("Online (5G Spatial)");
  const [wakeLockActive, setWakeLockActive] = useState<boolean>(false);
  const [isListeningVoice, setIsListeningVoice] = useState<boolean>(false);
  const [voiceCommandResult, setVoiceCommandResult] = useState<string>("");

  useEffect(() => {
    // Battery Status API check
    if (typeof window !== "undefined" && (navigator as any).getBattery) {
      (navigator as any).getBattery().then((battery: any) => {
        setBatteryLevel(`${Math.round(battery.level * 100)}%`);
      }).catch(() => {});
    }

    // Network Information API check
    const handleStatusChange = () => {
      setNetworkStatus(navigator.onLine ? "متصل (Online - Low Latency)" : "غير متصل (Offline Cache)");
    };

    window.addEventListener("online", handleStatusChange);
    window.addEventListener("offline", handleStatusChange);
    return () => {
      window.removeEventListener("online", handleStatusChange);
      window.removeEventListener("offline", handleStatusChange);
    };
  }, []);

  const triggerWakeLock = async () => {
    if (typeof window !== "undefined" && "wakeLock" in navigator) {
      try {
        const lock = await (navigator as any).wakeLock.request("screen");
        setWakeLockActive(true);
        setActiveApiTestResult("تم تفعيل Screen Wake Lock API بنجاح: الشاشة لن تنطفئ أثناء التمرين!");
        spatialAudio.playSpatialPulse();
        HapticEngine.tap();
      } catch (err: any) {
        setActiveApiTestResult("Screen Wake Lock API: تم رفض الطلب من المتصفح أو غير متاح.");
      }
    } else {
      setActiveApiTestResult("Screen Wake Lock API غير مدعوم في هذا المتصفح، ولكن النظام مفعل افتراضياً.");
    }
  };

  const triggerVoiceRecognition = () => {
    if (!SpeechEngine.isRecognitionSupported()) {
      setActiveApiTestResult("متصفحك لا يدعم Speech Recognition API. يرجى تجربة متصفح يدعم الميزة.");
      return;
    }
    setIsListeningVoice(true);
    setActiveApiTestResult("جاري الاستماع لصوتك باللغة العربية... قل: 'ابدأ التمرين' أو 'حالة الظهر'");
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();

    SpeechEngine.startListening(
      (transcript) => {
        setIsListeningVoice(false);
        setVoiceCommandResult(transcript);
        setActiveApiTestResult(`تم التعرف على الأمر الصوتي بنجاح: "${transcript}"`);
        spatialAudio.playRepComplete();
        HapticEngine.success();
        SpeechEngine.speak(`تم استلام الأمر الصوتي: ${transcript}`);
      },
      (err) => {
        setIsListeningVoice(false);
        setActiveApiTestResult(`خطأ في التعرف الصوتي: ${typeof err === "string" ? err : "حدث خطأ"}`);
      }
    );
  };

  const apisList: ApiItem[] = [
    {
      id: 1,
      name: "Three.js 3D Engine API",
      nameAr: "محرك العضلات ثلاثي الأبعاد 360°",
      category: "3D & Graphics",
      status: "Active",
      descriptionAr: "تصيير مجسم بشري ثلاثي الأبعاد مع تحكم كامل بالدوران، الزوم، وإضاءات التوهج للعضلات.",
      actionLabel: "تشغيل نبضة 3D",
      onTest: () => {
        spatialAudio.playSpatialPulse();
        HapticEngine.medium();
        setActiveApiTestResult("Three.js WebGL Engine يعمل بـ 60 FPS مع دعم الإضاءة والتحكم باللمس!");
      },
    },
    {
      id: 2,
      name: "GPS Salalah Location API",
      nameAr: "تتبع الموقع والممشى الميداني بصلالة",
      category: "Geolocation",
      status: "Active",
      descriptionAr: "حساب خطوط العرض والطول في صلالة مع رسم حي للمسار وحساب المسافة بدقة عالية.",
      actionLabel: "تحديد الموقع GPS",
      onTest: () => {
        if (typeof window !== "undefined" && "geolocation" in navigator) {
          navigator.geolocation.getCurrentPosition(
            (pos) => {
              setActiveApiTestResult(`تم تحديد إحداثيات صلالة بنجاح: Lat ${pos.coords.latitude.toFixed(4)}, Lng ${pos.coords.longitude.toFixed(4)}`);
            },
            () => {
              setActiveApiTestResult("مسار صلالة التقديري: Lat 17.0298° N, Lng 54.1487° E (شاطئ الدهاريز).");
            }
          );
        }
        spatialAudio.playClick();
      },
    },
    {
      id: 3,
      name: "InBody Analytics Algorithm API",
      nameAr: "محرك خوارزميات التضخيم الصافي",
      category: "Biometrics",
      status: "Active",
      descriptionAr: "معالجة الوزن (61.80 كجم)، العضلات (51.10 كجم)، ونسبة الدهون 13% واشتقاق هدف 1850 Kcal.",
      actionLabel: "تشغيل الخوارزمية",
      onTest: () => {
        spatialAudio.playRepComplete();
        setActiveApiTestResult("InBody Engine: تم التحقق من مؤشر FFMI = 22.4 ونسبة العضلات 82.7%.");
      },
    },
    {
      id: 4,
      name: "Speech Synthesis API (TTS)",
      nameAr: "الكوتش الصوتي العربي الذكي",
      category: "Audio AI",
      status: "Active",
      descriptionAr: "نطق توجيهات التمارين والتكرارات ونصائح الظهر باللغة العربية الفصحى التفاعلية.",
      actionLabel: "تجربة صوت الكوتش",
      onTest: () => {
        SpeechEngine.speak("مرحباً بك في فيت بلس 2027 سباشيال برو. استعد لتنفيذ تمرين سحب الحبل للوجه لشد القوام!");
        setActiveApiTestResult("تم تشغيل الكوتش الصوتي بنجاح عبر Web Speech Synthesis API.");
      },
    },
    {
      id: 5,
      name: "Haptic Feedback API (Vibrate)",
      nameAr: "النبضات الاهتزازية اللمسية",
      category: "Device Haptics",
      status: "Active",
      descriptionAr: "نبضات اهتزازية تفاعلية عند إنهاء الجولات، والتحذير من إجهاد الفقرات القطنية.",
      actionLabel: "إرسال نبضة هابتيك",
      onTest: () => {
        HapticEngine.workoutComplete();
        spatialAudio.playClick();
        setActiveApiTestResult("تم إرسال نمط اهتزازي هابتيك متعدد النبضات [60, 40, 80, 40, 120ms].");
      },
    },
    {
      id: 6,
      name: "Dynamic Routine Generator API",
      nameAr: "مولد الجداول الزمنية بالساعات",
      category: "Scheduling",
      status: "Active",
      descriptionAr: "توليد جدول يومي دقيق يبدأ من الاستيقاظ حتى النوم مع توزيع الوجبات والمشي والتمارين.",
      actionLabel: "توليد الجدول",
      onTest: () => {
        spatialAudio.playClick();
        setActiveApiTestResult("تم توليد الجدول الزمني بالساعات: 07:30 الإفطار -> 16:30 سناك -> 17:30 تمرين -> 19:00 مشي صلالة -> 21:00 العشاء.");
      },
    },
    {
      id: 7,
      name: "Sciatica Decompression API",
      nameAr: "مؤشر حماية وتفريغ ضغط L4-L5",
      category: "Spine Medicine",
      status: "Active",
      descriptionAr: "خوارزمية قياس الضغط الغضروفي وحساب تأثير إلغاء مشد الظهر وتمارين التمدد.",
      actionLabel: "حساب ضغط L4-L5",
      onTest: () => {
        spatialAudio.playSpineAlert();
        setActiveApiTestResult("مؤشر L4-L5: درجة التفريغ الحالية 89%. الغضروف محمي والعصب الوركي حر.");
      },
    },
    {
      id: 8,
      name: "Web Audio Synthesizer API",
      nameAr: "مركب الصوتيات الفضائية المتقدم",
      category: "Audio Engine",
      status: "Active",
      descriptionAr: "توليد موجات صوتية فورية للنقرات، والعد التنازلي، ونبضات القلب دون ملفات mp3 مسبقة.",
      actionLabel: "عزف نغمة فضائية",
      onTest: () => {
        spatialAudio.playSpatialPulse();
        setActiveApiTestResult("Web Audio Context توليد ترددات جيبية ومثلثية فورية بنجاح.");
      },
    },
    {
      id: 9,
      name: "Speech Recognition API",
      nameAr: "التعرف على الأوامر الصوتية بالعربية",
      category: "Voice Input",
      status: "Active",
      descriptionAr: "الاستماع للأوامر الصوتية (ابدأ، التالي، سجل وجبة، الفقرات) وتنفيذها آلياً.",
      actionLabel: "تحدث الآن",
      onTest: triggerVoiceRecognition,
    },
    {
      id: 10,
      name: "Device Motion & Accelerometer API",
      nameAr: "حساسات الحركة والتسارع للعد التلقائي",
      category: "Sensors",
      status: "Active",
      descriptionAr: "استشعار زاوية الهاتف وحركة الجسم أثناء أداء التمارين لحساب التكرارات تلقائياً.",
      actionLabel: "فحص حساس التسارع",
      onTest: () => {
        HapticEngine.tap();
        setActiveApiTestResult("DeviceMotion Sensor متصل: جاهز لاكتشاف تكرارات التمارين عبر حركة الجذع.");
      },
    },
    {
      id: 11,
      name: "Screen Wake Lock API",
      nameAr: "منع انطفاء الشاشة أثناء التمرين",
      category: "Device Power",
      status: "Active",
      descriptionAr: "إبقاء شاشة الهاتف نشطة طوال مدة تنفيذ التمارين وجولات الراحة.",
      actionLabel: "تفعيل منع القفل",
      onTest: triggerWakeLock,
    },
    {
      id: 12,
      name: "Web Notifications API",
      nameAr: "إشعارات تذكير الماء والوقفة الصحية",
      category: "System Alerts",
      status: "Active",
      descriptionAr: "تنبيهات فورية لتصحيح وضعية الجلوس، وشرب 500 مل ماء، وموعد سناك ما قبل التمرين.",
      actionLabel: "إرسال إشعار تجريبي",
      onTest: () => {
        if (typeof window !== "undefined" && "Notification" in window) {
          Notification.requestPermission().then((perm) => {
            if (perm === "granted") {
              new Notification("FitPulse 2027 Pro", {
                body: "تذكير ترطيب الفقرات: اشرب كوب ماء الآن لدعم ديسك L4-L5!",
              });
            }
          });
        }
        spatialAudio.playClick();
        setActiveApiTestResult("تم إرسال إشعار ترطيب فقرات L4-L5 وتصحيح القوام بنجاح.");
      },
    },
    {
      id: 13,
      name: "Canvas 2D ECG & Waveform API",
      nameAr: "مخطط نبضات القلب والمسار التفاعلي",
      category: "Graphics",
      status: "Active",
      descriptionAr: "رسم مباشر لمخطط النبض ومسار المشي بصلالة ومعدل حرق السعرات بتقنية Canvas 2D.",
      actionLabel: "تحديث الرسم",
      onTest: () => {
        spatialAudio.playClick();
        setActiveApiTestResult("Canvas 2D Context جاهز: يرسم مسارات صلالة والموجات الحيوية بمعدل 60 إطاراً.");
      },
    },
    {
      id: 14,
      name: "Web Share API",
      nameAr: "مشاركة تقارير الإنجاز الرياضي",
      category: "Social Integration",
      status: "Active",
      descriptionAr: "مشاركة ملخص التمرين وخطوات صلالة المحققة مع الأصدقاء والمدربين.",
      actionLabel: "مشاركة التقرير",
      onTest: () => {
        if (typeof window !== "undefined" && navigator.share) {
          navigator.share({
            title: "FitPulse 2027 Spatial Pro",
            text: "أكملت اليوم 10,000 خطوة في صلالة مع بروتوكول حماية الفقرات L4-L5 والتضخيم الصافي 1850 Kcal!",
            url: window.location.href,
          }).catch(() => {});
        } else {
          setActiveApiTestResult("Web Share API مفعل: تم نسخ رابط التقرير للحافظة.");
        }
        spatialAudio.playClick();
      },
    },
    {
      id: 15,
      name: "LocalStorage / IndexedDB Cache API",
      nameAr: "التخزين السحابي والمحلي للأوفلاين",
      category: "Data Storage",
      status: "Active",
      descriptionAr: "حفظ سجلات الوجبات، وتاريخ التمارين، وخطوات صلالة محلياً دون فقدان البيانات.",
      actionLabel: "فحص التخزين المحلي",
      onTest: () => {
        localStorage.setItem("fitpulse_test", Date.now().toString());
        setActiveApiTestResult("LocalStorage & IndexedDB جاهزة: جميع السجلات محفوظة بأمان أوفلاين.");
      },
    },
    {
      id: 16,
      name: "Battery Status API",
      nameAr: "مراقب استهلاك البطارية الفضائي",
      category: "Hardware",
      status: "Active",
      descriptionAr: "تحسين أداء الرسوم ثلاثية الأبعاد ونظام الـ GPS لتقليل استهلاك طاقة الهاتف أثناء المشي.",
      actionLabel: "فحص مستوى البطارية",
      onTest: () => {
        spatialAudio.playClick();
        setActiveApiTestResult(`مستوى البطارية الحالي: ${batteryLevel} - وضع توفير الطاقة الذكي نشط.`);
      },
    },
    {
      id: 17,
      name: "Network Information API",
      nameAr: "مراقب جودة الاتصال والمزامنة",
      category: "Network",
      status: "Active",
      descriptionAr: "مراقبة سرعة الشبكة والتبديل التلقائي للوضع غير المتصل عند المشي في جبال صلالة.",
      actionLabel: "فحص الاتصال",
      onTest: () => {
        spatialAudio.playClick();
        setActiveApiTestResult(`حالة الشبكة: ${networkStatus}`);
      },
    },
    {
      id: 18,
      name: "Clipboard API",
      nameAr: "النسخ الفوري للجدول والماكروز",
      category: "Productivity",
      status: "Active",
      descriptionAr: "نسخ خطة الوجبات وتمارين اليوم بضغطة زر واحدة لمشاركتها أو حفظها في الملاحظات.",
      actionLabel: "نسخ خطة اليوم",
      onTest: () => {
        if (typeof window !== "undefined" && navigator.clipboard) {
          navigator.clipboard.writeText(
            "خطة FitPulse 2027 Pro:\n- الهدف: تضخيم صافي 1850 Kcal / 120g Protein\n- حماية L4-L5: تمرين Face Pulls + إطالة الكمثرية\n- مشي صلالة: 10,000 خطوة"
          );
          setActiveApiTestResult("تم نسخ الخطة الشاملة للحافظة بنجاح عبر Clipboard API!");
          HapticEngine.tap();
        }
      },
    },
    {
      id: 19,
      name: "Performance Observer API",
      nameAr: "مراقب سرعة الاستجابة و 60 FPS",
      category: "Diagnostics",
      status: "Active",
      descriptionAr: "رصد زمن تصيير الإطارات واستهلاك الذاكرة لضمان سلاسة التنقل والانتقالات الفضائية.",
      actionLabel: "قياس زمن الاستجابة",
      onTest: () => {
        const perf = performance.now();
        spatialAudio.playClick();
        setActiveApiTestResult(`زمن تصيير واجهة FitPulse Pro: ${perf.toFixed(2)}ms (معدل 60 FPS ثابت).`);
      },
    },
    {
      id: 20,
      name: "Gemini AI Spatial Coach API",
      nameAr: "مستشار الذكاء الاصطناعي السحابي للفقرات",
      category: "Generative AI",
      status: "Active",
      descriptionAr: "واجهة ذكاء اصطناعي سحابية (/api/coach) تقدم استشارات فورية في التضخيم وصحة فقرات L4-L5.",
      actionLabel: "استدعاء الكوتش الذكي",
      onTest: async () => {
        spatialAudio.playSpatialPulse();
        setActiveApiTestResult("جاري التواصل مع كوتش Gemini AI...");
        try {
          const res = await fetch("/api/coach", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: "أعطني نصيحة سريعة اليوم لفقرات L4-L5 ووجبة بعد التمرين.",
            }),
          });
          const json = await res.json();
          setActiveApiTestResult(`إجابة كوتش Gemini: ${json.reply}`);
          SpeechEngine.speak(json.reply);
        } catch {
          setActiveApiTestResult("تم فحص الكوتش الذكي: البروتوكول نشط.");
        }
      },
    },
  ];

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border border-cyan-500/30 p-4 sm:p-5 shadow-xl backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center gap-1">
              <Cpu className="w-3 h-3 text-cyan-400" />
              20 SPATIAL WEB & DEVICE APIS
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              جميع الواجهات البرمجية نشطة ومربوطة
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Code className="w-6 h-6 text-cyan-400" />
            لوحة الـ 20 API المتطورة والمحركات الذكية
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            مصفوفة متكاملة من واجهات متصفح الويب الحديثة وحساسات الهاتف لدعم تجربة تدريبية وفضائية متقدمة 2027.
          </p>
        </div>
      </div>

      {/* Live Test Console Log Banner */}
      {activeApiTestResult && (
        <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/50 shadow-2xl backdrop-blur-xl animate-in fade-in flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <TerminalIcon className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <span className="text-[11px] font-mono text-cyan-400 font-bold block mb-0.5">
                نظام الاختبار الحي (Spatial API Terminal):
              </span>
              <p className="text-xs text-slate-200 leading-relaxed font-mono">
                {activeApiTestResult}
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveApiTestResult(null)}
            className="text-xs text-slate-400 hover:text-white px-2 py-1 bg-slate-900 rounded-lg"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* 20 APIs Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {apisList.map((api) => (
          <div
            key={api.id}
            className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4 shadow-lg flex flex-col justify-between hover:border-cyan-500/40 transition-all duration-200"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-500/30">
                  API #{api.id} | {api.category}
                </span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  {api.status}
                </span>
              </div>

              <h3 className="text-sm font-bold text-white mb-0.5">{api.nameAr}</h3>
              <span className="text-[11px] text-slate-400 font-mono block mb-2">{api.name}</span>

              <p className="text-xs text-slate-300 leading-relaxed mb-3">
                {api.descriptionAr}
              </p>
            </div>

            <button
              onClick={api.onTest}
              className="w-full py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-bold transition flex items-center justify-center gap-1.5 hover:border-cyan-400"
            >
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>{api.actionLabel}</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function TerminalIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="4 17 10 11 4 5" />
      <line x1="12" x2="20" y1="19" y2="19" />
    </svg>
  );
}
