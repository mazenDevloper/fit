"use client";

import React, { useState } from "react";
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  HeartPulse,
  Activity,
  CheckCircle2,
  Sparkles,
  Footprints,
  Volume2,
  Maximize2,
  Zap,
  Play,
} from "lucide-react";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";
import ExerciseVisualizer from "@/components/ExerciseVisualizer";

export default function SpineProtocol() {
  const [completedStretches, setCompletedStretches] = useState<{ [key: string]: boolean }>({
    facePulls: false,
    gluteBridges: false,
    piriformisStretch: false,
    salalahWalk: false,
  });

  const [activeAnimatedExercise, setActiveAnimatedExercise] = useState<string | null>("face-pulls");

  const toggleStretch = (key: string) => {
    const newState = !completedStretches[key];
    setCompletedStretches({ ...completedStretches, [key]: newState });
    spatialAudio.playRepComplete();
    HapticEngine.repDone();
  };

  const completedCount = Object.values(completedStretches).filter(Boolean).length;
  const decompressionScore = Math.min(100, Math.round(55 + completedCount * 11.25));

  const handleVoiceSpineBriefing = () => {
    spatialAudio.playSpineAlert();
    HapticEngine.spineAlert();
    const text = `بروتوكول سلامة الفقرات والعصب القطني L4-L5: القرار الطبي الحاسم هو إلغاء مشد الظهر فوراً لمنع ضمور العضلات. البديل لشد القوام هو تمرين سحب الحبل للوجه. ولعلاج عرق النسا، التزم بجسر المقعدة وإطالة عضلة الكمثرية والمشي اليومي في صلالة حتى عشرة آلاف خطوة لتوسيع وترطيب الغضاريف.`;
    SpeechEngine.speak(text);
  };

  return (
    <div className="space-y-4">
      {/* Critical Medical Directive Banner */}
      <div className="relative rounded-2xl bg-gradient-to-br from-rose-950/90 via-slate-900/90 to-amber-950/80 border border-rose-500/50 p-4 sm:p-5 shadow-2xl backdrop-blur-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/50 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                قرار طبي صارم وحاسم
              </span>
              <span className="px-2 py-0.5 rounded-full text-[11px] bg-slate-900/80 text-cyan-300 border border-cyan-500/30">
                بروتوكول الفقرات والعصب القطني L4-L5
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-rose-400 animate-pulse" />
              إلغاء حزام / سترة شد الظهر فوراً وتفعيل البديل العلاجي
            </h2>
            <p className="text-xs sm:text-sm text-rose-200/90 mt-2 max-w-2xl leading-relaxed">
              <b>لماذا تم المنع؟</b> استخدام الرباطات والمشدات الخارجية يعود العضلات العميقة المسؤولة عن دعم العمود الفقري (Multifidus & Erector Spinae) على الخمول والكسل، مما يؤدي لضمورها ونقل كل الحمل الانضغاطي على ديسك الفقرات L4-L5 وتفاقم عرق النسا.
            </p>
          </div>

          <button
            onClick={handleVoiceSpineBriefing}
            className="px-4 py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-400/40 text-xs font-bold transition flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(244,63,94,0.25)] shrink-0"
          >
            <Volume2 className="w-4 h-4 text-rose-400" />
            استماع لتوجيهات الكوتش الطبي
          </button>
        </div>
      </div>

      {/* Lumbar Decompression Gauge & Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Decompression Meter */}
        <div className="rounded-2xl bg-slate-900/80 border border-cyan-500/30 p-4 sm:p-5 shadow-xl backdrop-blur-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <HeartPulse className="w-4 h-4 text-cyan-400" />
                مؤشر تفريغ الضغط القطني (L4-L5 Index)
              </h3>
              <span className="text-xs font-mono font-bold text-cyan-400">
                {decompressionScore}% محصن
              </span>
            </div>

            {/* Gauge Visual */}
            <div className="relative w-full h-4 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800 my-3">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-cyan-400 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${decompressionScore}%` }}
              />
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mt-2">
              حالة الضغط الغضروفي: <b className="text-emerald-400 font-semibold">تفريغ صحي ممتاز</b>. كلما أكملت التمارين العلاجية وخطوات صلالة، زادت المساحة بين الفقرات وتدفق السائل الزلالي المرطب.
            </p>
          </div>

          {/* Interactive Checkbox List */}
          <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
            <span className="text-[11px] font-bold text-slate-400 block mb-1">
              قائمة الإجراءات العلاجية لليوم:
            </span>

            {[
              { key: "facePulls", label: "تمرين Face Pulls (4 جولات × 15 عدة)" },
              { key: "gluteBridges", label: "تمرين جسر المقعدة (Glute Bridges)" },
              { key: "piriformisStretch", label: "إطالة عضلة الكمثرية (Piriformis 30s)" },
              { key: "salalahWalk", label: "مشي صلالة الميداني (8,000 - 10,000 خطوة)" },
            ].map((item) => (
              <button
                key={item.key}
                onClick={() => toggleStretch(item.key)}
                className={`w-full p-2 rounded-xl text-xs flex items-center justify-between border transition ${
                  completedStretches[item.key]
                    ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300"
                    : "bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <span>{item.label}</span>
                <CheckCircle2
                  className={`w-4 h-4 ${
                    completedStretches[item.key] ? "text-emerald-400" : "text-slate-600"
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        {/* 3 Therapeutic Pillars */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Pillar 1: Face Pulls Posture */}
          <div className="rounded-2xl bg-slate-900/80 border border-blue-500/30 p-4 shadow-lg flex flex-col justify-between hover:border-blue-500/60 transition">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/40">
                  <Sparkles className="w-4 h-4" />
                </div>
                <button
                  onClick={() => setActiveAnimatedExercise(activeAnimatedExercise === "face-pulls" ? null : "face-pulls")}
                  className="px-2 py-1 rounded-lg bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-500/40 flex items-center gap-1"
                >
                  <Play className="w-2.5 h-2.5 fill-blue-300" />
                  <span>{activeAnimatedExercise === "face-pulls" ? "إخفاء المحاكاة" : "تشغيل حركة الحبل"}</span>
                </button>
              </div>
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block mb-1">
                البديل العلاجي لشد القوام
              </span>
              <h4 className="text-sm font-bold text-white mb-1.5">
                تمرين سحب الحبل للوجه (Face Pulls)
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-2">
                يقوي عضلات الكتف الخلفي والترابيس السفلية ولوح الكتف، فيشد القوام ويفتح الصدر طبيعياً كبديل فسيولوجي دائم لحزام الظهر.
              </p>

              {activeAnimatedExercise === "face-pulls" && (
                <div className="my-2 rounded-xl overflow-hidden">
                  <ExerciseVisualizer
                    exerciseId="face-pulls-rope"
                    category="shoulders"
                    nameAr="سحب الحبل للوجه"
                    nameEn="Face Pulls"
                  />
                </div>
              )}
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800/80 text-[11px] text-blue-300 font-mono">
              4 جولات × 15 تكرار نقي
            </div>
          </div>

          {/* Pillar 2: Sciatica Decompression */}
          <div className="rounded-2xl bg-slate-900/80 border border-emerald-500/30 p-4 shadow-lg flex flex-col justify-between hover:border-emerald-500/60 transition">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <button
                  onClick={() => setActiveAnimatedExercise(activeAnimatedExercise === "glute-bridges" ? null : "glute-bridges")}
                  className="px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40 flex items-center gap-1"
                >
                  <Play className="w-2.5 h-2.5 fill-emerald-300" />
                  <span>{activeAnimatedExercise === "glute-bridges" ? "إخفاء المحاكاة" : "تشغيل حركة الجسر"}</span>
                </button>
              </div>
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                علاج عرق النسا والضغط القطني
              </span>
              <h4 className="text-sm font-bold text-white mb-1.5">
                جسر المقعدة + إطالة الكمثرية
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-2">
                <b>جسر المقعدة (Glute Bridges)</b> يقوي الحوض ويثبت الفقرات القطنية، و<b>إطالة الكمثرية (Piriformis Stretch)</b> تلغي اختناق العصب الوركي وتزيل التنميل فوراً.
              </p>

              {activeAnimatedExercise === "glute-bridges" && (
                <div className="my-2 rounded-xl overflow-hidden">
                  <ExerciseVisualizer
                    exerciseId="glute-bridges"
                    category="back"
                    nameAr="جسر المقعدة الأرضي"
                    nameEn="Glute Bridges"
                  />
                </div>
              )}
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800/80 text-[11px] text-emerald-300 font-mono">
              ثبات 30 ثانية × 3 جولات
            </div>
          </div>

          {/* Pillar 3: Salalah Walking Hydration */}
          <div className="rounded-2xl bg-slate-900/80 border border-teal-500/30 p-4 shadow-lg flex flex-col justify-between hover:border-teal-500/60 transition">
            <div>
              <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center mb-2.5 border border-teal-500/40">
                <Footprints className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold text-teal-400 uppercase tracking-wider block mb-1">
                ترطيب الديسك وتوسيع الفقرات
              </span>
              <h4 className="text-sm font-bold text-white mb-1.5">
                المشي الميداني بصلالة
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                المشي على مسارات صلالة (الدهاريز وسهل إتين) بمعدل 8,000 إلى 10,000 خطوة يحدث ضخاً هيدروليكياً طبيعياً للغضاريف يعيد ترطيبها ويوسع مسار العصب.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800/80 text-[11px] text-teal-300 font-mono">
              8,000 - 10,000 خطوة يومياً
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
