"use client";

import React, { useState } from "react";
import {
  Activity,
  Flame,
  Scale,
  Zap,
  TrendingUp,
  Award,
  Sliders,
  RotateCcw,
  CheckCircle2,
  Droplet,
  Sparkles,
} from "lucide-react";
import { INITIAL_INBODY_DATA, InBodyData } from "@/lib/data";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

export default function InBodyAnalytics() {
  const [data, setData] = useState<InBodyData>(INITIAL_INBODY_DATA);
  const [isEditing, setIsEditing] = useState<boolean>(false);

  const calculateLeanPercentage = (weight: number, muscle: number) => {
    return ((muscle / weight) * 100).toFixed(1);
  };

  const handleVoiceReport = () => {
    spatialAudio.playSpatialPulse();
    HapticEngine.medium();
    const reportText = `تقرير تحليل الإن بدي لتطبيق فيت بلس 2027: الوزن الكلي 61.8 كيلوجرام، والكتلة العضلية 51.1 كيلوجرام بنسبة دهون 13 بالمائة. خوارزمية التضخيم الصافي توصي باستهلاك 1800 إلى 1850 سعرة حرارية مع 120 جرام بروتين يومياً.`;
    SpeechEngine.speak(reportText);
  };

  const handleReset = () => {
    setData(INITIAL_INBODY_DATA);
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  return (
    <div className="space-y-4">
      {/* Top Bento Banner with InBody Pro Status */}
      <div className="relative rounded-3xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl backdrop-blur-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                INBODY 2027 BENTO ANALYTICS
              </span>
              <span className="px-2.5 py-0.5 rounded-md text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1 font-mono">
                <CheckCircle2 className="w-3 h-3" />
                حالة مثالية للتضخيم الصافي
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              <Scale className="w-6 h-6 text-indigo-400" />
              تحليل التكوين العضلي وتوجيه الخوارزميات
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl leading-relaxed">
              تحليل دقيق للكتلة اللادهنية، معدل الأيض الأساسي (BMR)، ونسبة الدهون لتوجيه خطة التضخيم الصافي دون زيادة دهون ضارة.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={handleVoiceReport}
              className="px-3.5 py-2 rounded-2xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-xs font-bold transition flex items-center gap-2 shadow-md shadow-indigo-500/10"
            >
              <Zap className="w-4 h-4 text-indigo-400" />
              قراءة التقرير بالصوت
            </button>
            <button
              onClick={() => {
                setIsEditing(!isEditing);
                spatialAudio.playClick();
                HapticEngine.tap();
              }}
              className="p-2.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs transition"
              title="تعديل القراءات"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Editor Panel if active */}
      {isEditing && (
        <div className="rounded-3xl bg-slate-900 border border-indigo-500/40 p-5 shadow-xl backdrop-blur-xl animate-in fade-in duration-300">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <h4 className="text-sm font-bold text-indigo-300 flex items-center gap-2">
              <Sliders className="w-4 h-4" />
              محاكي قراءات InBody الحيوية
            </h4>
            <button
              onClick={handleReset}
              className="text-xs text-slate-400 hover:text-indigo-300 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              استعادة القيم الأصلية
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">الوزن الكلي (كجم)</label>
              <input
                type="number"
                step="0.1"
                value={data.totalWeight}
                onChange={(e) => setData({ ...data, totalWeight: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-indigo-300 font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">الكتلة العضلية (كجم)</label>
              <input
                type="number"
                step="0.1"
                value={data.muscleMass}
                onChange={(e) => setData({ ...data, muscleMass: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-emerald-300 font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">نسبة الدهون (%)</label>
              <input
                type="number"
                step="0.1"
                value={data.bodyFatPercentage}
                onChange={(e) => setData({ ...data, bodyFatPercentage: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-amber-300 font-mono"
              />
            </div>
          </div>
        </div>
      )}

      {/* Main Metric Cards Grid (Bento Style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Weight */}
        <div className="relative rounded-3xl bg-slate-900 border border-slate-800 p-5 hover:border-slate-700 transition-all duration-200 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">الوزن الكلي</span>
            <Scale className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-white font-mono">{data.totalWeight.toFixed(2)}</span>
            <span className="text-xs text-slate-400">كجم</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-400 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>كتلة مثالية للبدء بالتضخيم</span>
          </div>
        </div>

        {/* Card 2: Skeletal Muscle Mass (SMM) */}
        <div className="relative rounded-3xl bg-slate-900 border border-slate-800 p-5 hover:border-indigo-500/50 transition-all duration-200 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-indigo-300">الكتلة العضلية (SMM)</span>
            <Activity className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-indigo-400 font-mono">{data.muscleMass.toFixed(2)}</span>
            <span className="text-xs text-slate-400">كجم</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-300 flex items-center justify-between">
            <span>نسبة العضلات الصافية:</span>
            <span className="font-mono text-indigo-300 font-bold">{calculateLeanPercentage(data.totalWeight, data.muscleMass)}%</span>
          </div>
        </div>

        {/* Card 3: Body Fat Percentage */}
        <div className="relative rounded-3xl bg-slate-900 border border-slate-800 p-5 hover:border-slate-700 transition-all duration-200 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-emerald-300">نسبة الدهون الكلية</span>
            <Award className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-emerald-400 font-mono">{data.bodyFatPercentage.toFixed(1)}%</span>
            <span className="text-xs text-slate-400">نطاق مثالي</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>تحت الجلد: <b className="text-slate-200 font-mono">{data.subcutaneousFat}%</b></span>
            <span>الحشوية: <b className="text-emerald-400 font-mono">مستوى {data.visceralFatLevel}</b></span>
          </div>
        </div>

        {/* Card 4: BMR & Caloric Surplus Target */}
        <div className="relative rounded-3xl bg-slate-900 border border-slate-800 p-5 hover:border-slate-700 transition-all duration-200 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-amber-300">الأيض الأساسي (BMR)</span>
            <Flame className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-amber-400 font-mono">{data.bmr}</span>
            <span className="text-xs text-slate-400">سعرة/يوم</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-300 font-semibold flex items-center justify-between">
            <span>هدف التضخيم الصافي:</span>
            <span className="font-mono text-indigo-300 font-bold">{data.targetCaloriesMin}-{data.targetCaloriesMax} Kcal</span>
          </div>
        </div>
      </div>

      {/* Deep Algorithm Directives & Composition Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Algorithmic Blueprint */}
        <div className="lg:col-span-2 rounded-3xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            التوجيه البرمجي والخوارزمي للتضخيم الصافي (Hypertrophy Engine)
          </h3>

          <div className="space-y-3">
            <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-indigo-300">1. فائض السعرات المحسوب بدقة (+350 Kcal)</span>
                <span className="text-[11px] font-mono text-indigo-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                  1800 - 1850 Kcal/day
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                معدل الأيض 1473 سعرة + النشاط الحركي والمشي بصلالة يتطلب فائضاً نظيفاً لتغذية الكتلة العضلية (51.1 كجم) دون تحفيز تخزين الدهون في المستوى الحشوي.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-emerald-300">2. معدل البروتين النقي المستهدف (1.9 - 2.0g/kg)</span>
                <span className="text-[11px] font-mono text-emerald-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                  115 - 120g Protein
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                توزيع البروتين على 4 وجبات منتظمة (الإفطار 28g، الغداء 45g، السناك 8g، العشاء 25g) يضمن استمرار إشارات البناء العضلي (mTOR) طوال 24 ساعة.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-blue-300">3. مؤشر ترطيب الغضاريف والفقرات القطنية</span>
                <span className="text-[11px] font-mono text-blue-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                  3.5 Liters/day
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                غضاريف فقرات L4-L5 تتكون من 80% ماء. شرب 3.5 لتر بالتزامن مع خطوات المشي بصلالة يعيد ملء الوسائد الغضروفية ويمنع اختناق العصب الوركي.
              </p>
            </div>
          </div>
        </div>

        {/* Right Col: Body Composition Visual Bars */}
        <div className="rounded-3xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Activity className="w-4 h-4 text-indigo-400" />
            مؤشرات التكوين البدني المتقدمة
          </h3>

          {/* Muscle Mass Ratio Bar */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-300">نسبة الكتلة اللادهنية</span>
              <span className="text-emerald-400 font-mono font-bold">82.7% (ممتازة)</span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div className="h-full bg-gradient-to-r from-emerald-500 to-indigo-400 rounded-full w-[82.7%]" />
            </div>
          </div>

          {/* Fat Ratio Bar */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-300">نسبة الدهون الكلية</span>
              <span className="text-emerald-400 font-mono font-bold">13.0% (نطاق مثالي)</span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full w-[13%]" />
            </div>
          </div>

          {/* Visceral Fat Level Bar */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-300">الدهون الحشوية (Visceral)</span>
              <span className="text-indigo-400 font-mono font-bold">المستوى 5 من 12</span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full w-[41.6%]" />
            </div>
          </div>

          {/* FFMI Score */}
          <div className="mt-4 p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/50 text-center">
            <span className="text-[11px] text-slate-400 block font-mono">مؤشر الكتلة اللادهنية (FFMI)</span>
            <span className="text-2xl font-black text-indigo-300 font-mono">22.4</span>
            <span className="text-[10px] text-emerald-400 block mt-0.5 font-medium">
              تصنيف النخبة الطبيعية (Elite Natural Potential)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
