"use client";

import React, { useState } from "react";
import {
  Sparkles,
  CalendarCheck,
  Box,
  Dumbbell,
  Scale,
  ShieldAlert,
  Utensils,
  Footprints,
  Clock,
  Bot,
  Code,
  Volume2,
  VolumeX,
  Zap,
  LayoutGrid,
  Layers,
} from "lucide-react";
import DailySmartRoutine from "@/components/DailySmartRoutine";
import ApexPhoneMockup from "@/components/ApexPhoneMockup";
import Svg2DMuscleViewer from "@/components/Svg2DMuscleViewer";
import ThreeMuscleViewer from "@/components/ThreeMuscleViewer";
import FloatingPiPWidget from "@/components/FloatingPiPWidget";
import ExerciseLibrary from "@/components/ExerciseLibrary";
import InBodyAnalytics from "@/components/InBodyAnalytics";
import SpineProtocol from "@/components/SpineProtocol";
import DietTracker from "@/components/DietTracker";
import SalalahGpsTracker from "@/components/SalalahGpsTracker";
import DynamicRoutine from "@/components/DynamicRoutine";
import AiCoachChat from "@/components/AiCoachChat";
import ApiShowcase from "@/components/ApiShowcase";
import BentoDashboard from "@/components/BentoDashboard";
import { spatialAudio } from "@/lib/audio";
import { HapticEngine } from "@/lib/haptics";
import { SpeechEngine } from "@/lib/speech";

export default function Home() {
  // The first / default screen is Today's Live Visual Program as requested
  const [activeTab, setActiveTab] = useState<string>("daily-smart-routine");
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [selectedMuscleHighlight, setSelectedMuscleHighlight] = useState<string>("chest_triceps");
  const [anatomyViewMode, setAnatomyViewMode] = useState<"2d-svg" | "3d-three">("2d-svg");

  const tabs = [
    {
      id: "daily-smart-routine",
      label: "برنامج اليوم البصري (الرئيسية)",
      icon: CalendarCheck,
      badge: "JSONBin سحابي",
    },
    {
      id: "exercises",
      label: "محاكي التمارين والحركات (21)",
      icon: Dumbbell,
      badge: "أنيميشن دقيق",
    },
    {
      id: "3d-anatomy",
      label: "التشريح العضلي 2D SVG التفاعلي",
      icon: Layers,
      badge: "2D SVG + 3D",
    },
    {
      id: "apex-mockup",
      label: "استوديو Apex Pro (التصميم الأصلي)",
      icon: Sparkles,
      badge: "UI Mockup",
    },
    {
      id: "spine-protocol",
      label: "بروتوكول الفقرات L4-L5",
      icon: ShieldAlert,
      badge: "حماية صارمة",
    },
    {
      id: "diet",
      label: "نظام الوجبات (1850 Kcal)",
      icon: Utensils,
    },
    {
      id: "inbody",
      label: "تحليل InBody والوزن (60.5 kg)",
      icon: Scale,
    },
    {
      id: "salalah-gps",
      label: "مسار مشي صلالة (GPS)",
      icon: Footprints,
    },
    {
      id: "routine",
      label: "الجدول الزمني للساعات",
      icon: Clock,
    },
    {
      id: "ai-coach",
      label: "الكوتش الذكي AI Coach",
      icon: Bot,
    },
    {
      id: "bento-overview",
      label: "لوحة Bento الشاملة",
      icon: LayoutGrid,
    },
    {
      id: "apis-20",
      label: "لوحة الـ 20 API",
      icon: Code,
      badge: "20 APIs",
    },
  ];

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    spatialAudio.playClick();
    HapticEngine.tap();
  };

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
    SpeechEngine.stop();
    spatialAudio.playClick();
  };

  const handle3DHighlightFromLibrary = (muscleKey: string) => {
    setSelectedMuscleHighlight(muscleKey);
    setActiveTab("3d-anatomy");
  };

  return (
    <div className="min-h-screen bg-[#04070e] text-slate-100 selection:bg-[#00f0ff] selection:text-black font-sans antialiased pb-24">
      {/* Background Ambient Apex Glows */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-[#00f0ff]/10 rounded-full blur-[160px]" />
        <div className="absolute top-1/2 -right-40 w-96 h-96 bg-blue-600/10 rounded-full blur-[160px]" />
        <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-emerald-500/10 rounded-full blur-[160px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6 space-y-4">
        {/* APEX FITNESS PRO STUDIO Header */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center bg-[#090d16] border border-slate-800/90 p-4 sm:p-5 rounded-3xl gap-4 backdrop-blur-xl shadow-2xl">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 bg-[#00f0ff]/15 border border-[#00f0ff]/40 rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(0,240,255,0.3)] text-[#00f0ff] flex-shrink-0">
              <Zap className="w-6 h-6 fill-[#00f0ff]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-mono">
                  APEX FITNESS <span className="text-[#00f0ff]">PRO STUDIO</span>
                </h1>
                <span className="text-[10px] uppercase bg-[#00f0ff]/15 text-[#00f0ff] px-2.5 py-0.5 rounded-full border border-[#00f0ff]/40 font-mono tracking-wider font-bold">
                  PRO VERSION 2027
                </span>
                <span className="text-[10px] uppercase bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/40 font-mono hidden sm:inline-block">
                  JSONBin SYNC: 6a97dc6b
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                تضخيم عضلي صافٍ (60.5 → 65 kg) + بروتوكول حماية L4-L5 + مشي صلالة 10k
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between md:justify-end w-full md:w-auto gap-4">
            <div className="text-right">
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">
                SALALAH PROTOCOL
              </p>
              <p className="text-xs font-mono font-bold text-[#00f0ff]">مسار صلالة | 24°C</p>
            </div>

            {/* Athlete Chip */}
            <div className="w-10 h-10 rounded-2xl border border-[#00f0ff]/40 bg-slate-900 p-0.5 flex-shrink-0 flex items-center justify-center">
              <span className="text-xs font-black text-[#00f0ff] font-mono">APEX</span>
            </div>

            {/* Audio Toggle */}
            <button
              onClick={handleToggleMute}
              className={`p-2.5 rounded-2xl border transition ${
                isMuted
                  ? "bg-slate-900 text-slate-500 border-slate-800"
                  : "bg-[#00f0ff]/20 text-[#00f0ff] border-[#00f0ff]/50 shadow-[0_0_15px_rgba(0,240,255,0.2)]"
              }`}
              title={isMuted ? "كتم الصوت" : "تشغيل الصوت التفاعلي"}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* Navigation Tabs Bar - Fixed at Bottom for Easy Mobile/Desktop Access */}
        <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#090d16]/95 border-t border-slate-800/90 backdrop-blur-2xl px-3 sm:px-6 py-2.5 shadow-[0_-10px_25px_rgba(0,0,0,0.5)]">
          <div className="max-w-7xl mx-auto flex gap-2 overflow-x-auto scrollbar-none">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`px-3.5 py-2 rounded-2xl text-xs font-mono font-bold whitespace-nowrap transition-all flex items-center gap-2 border flex-shrink-0 ${
                    isActive
                      ? "bg-[#00f0ff]/20 text-[#00f0ff] border-[#00f0ff]/50 shadow-[0_0_15px_rgba(0,240,255,0.25)]"
                      : "bg-slate-900/80 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700"
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? "text-[#00f0ff]" : "text-slate-400"}`} />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded-md font-mono ${
                        isActive
                          ? "bg-[#00f0ff] text-slate-950 font-black"
                          : "bg-slate-800 text-slate-300"
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Main Content Area */}
        <main className="transition-all duration-300">
          {activeTab === "daily-smart-routine" && (
            <DailySmartRoutine
              onNavigateTab={handleTabChange}
              onSelectMuscleTarget={(m) => {
                setSelectedMuscleHighlight(m);
                setActiveTab("3d-anatomy");
              }}
            />
          )}

          {activeTab === "exercises" && (
            <ExerciseLibrary onHighlightMuscleIn3D={handle3DHighlightFromLibrary} />
          )}

          {activeTab === "3d-anatomy" && (
            <div className="space-y-4">
              {/* Anatomy Engine Mode Switcher */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#090d16] border border-slate-800/90">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00f0ff] animate-ping" />
                  <span className="text-xs font-mono font-bold text-white">
                    نظام التشريح العضلي التفاعلي
                  </span>
                </div>
                <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    onClick={() => {
                      setAnatomyViewMode("2d-svg");
                      spatialAudio.playClick();
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 ${
                      anatomyViewMode === "2d-svg"
                        ? "bg-[#00f0ff] text-slate-950 shadow-[0_0_10px_rgba(0,240,255,0.4)]"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>التشريح الدقيق 2D SVG</span>
                  </button>
                  <button
                    onClick={() => {
                      setAnatomyViewMode("3d-three");
                      spatialAudio.playClick();
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 ${
                      anatomyViewMode === "3d-three"
                        ? "bg-[#00f0ff] text-slate-950 shadow-[0_0_10px_rgba(0,240,255,0.4)]"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <Box className="w-3.5 h-3.5" />
                    <span>مجسم ثلاثي الأبعاد 3D</span>
                  </button>
                </div>
              </div>

              {anatomyViewMode === "2d-svg" ? (
                <Svg2DMuscleViewer
                  activeMuscleTarget={selectedMuscleHighlight}
                  showCardGrid={true}
                />
              ) : (
                <ThreeMuscleViewer
                  activeMuscleTarget={selectedMuscleHighlight}
                  showCardGrid={true}
                />
              )}
            </div>
          )}

          {activeTab === "apex-mockup" && (
            <div className="space-y-4">
              <ApexPhoneMockup />
            </div>
          )}

          {activeTab === "spine-protocol" && <SpineProtocol />}

          {activeTab === "diet" && <DietTracker />}

          {activeTab === "inbody" && <InBodyAnalytics />}

          {activeTab === "salalah-gps" && <SalalahGpsTracker />}

          {activeTab === "routine" && <DynamicRoutine />}

          {activeTab === "ai-coach" && <AiCoachChat />}

          {activeTab === "bento-overview" && (
            <BentoDashboard
              onNavigateTab={handleTabChange}
              onSelectMuscleIn3D={handle3DHighlightFromLibrary}
            />
          )}

          {activeTab === "apis-20" && <ApiShowcase />}
        </main>
      </div>

      {/* Floating Picture-in-Picture / Over-All-Apps Widget HUD */}
      <FloatingPiPWidget onNavigateTab={handleTabChange} />
    </div>
  );
}
