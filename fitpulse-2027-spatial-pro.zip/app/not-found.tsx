import Link from "next/link";
import { Sparkles, Home, ArrowRight } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#04070e] text-slate-100 flex items-center justify-center p-6 text-center">
      <div className="max-w-md w-full bg-[#090d16] border border-slate-800/90 p-8 rounded-3xl backdrop-blur-xl shadow-2xl space-y-5">
        <div className="w-14 h-14 mx-auto rounded-2xl bg-[#00f0ff]/15 border border-[#00f0ff]/40 flex items-center justify-center text-[#00f0ff] shadow-[0_0_20px_rgba(0,240,255,0.3)]">
          <Sparkles className="w-7 h-7" />
        </div>
        <div>
          <h2 className="text-2xl font-black font-mono text-white">404 - الصفحة غير موجودة</h2>
          <p className="text-xs text-slate-400 mt-2 font-mono">
            الصفحة التي تحاول الوصول إليها غير متوفرة أو تم نقلها.
          </p>
        </div>
        <Link
          href="/"
          className="inline-flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-[#00f0ff] text-slate-950 font-bold text-sm font-mono shadow-[0_0_15px_rgba(0,240,255,0.4)] hover:bg-[#00f0ff]/90 transition"
        >
          <Home className="w-4 h-4" />
          <span>العودة للرئيسية</span>
        </Link>
      </div>
    </div>
  );
}
