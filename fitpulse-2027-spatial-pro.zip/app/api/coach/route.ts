import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { message, context } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        reply: "تنبيه: مفتاح Gemini API غير مهيأ حالياً، ولكن الكوتش الذكي يعمل بالخوارزميات المدمجة لبروتوكول FitPulse 2027 Spatial Pro. استمر في تنفيذ تمارين الظهر والوجبات المقررة!",
        fallback: true,
      });
    }

    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const systemPrompt = `
أنت الكوتش الذكي والمستشار الرياضي الحيوي لتطبيق "FitPulse 2027 Spatial Pro".
تتحدث باللغة العربية بأسلوب تحفيزي، علمي ودقيق، ومباشر.

بيانات المستخدم الطبية والبدنية الثابتة:
1. بيانات InBody:
   - الوزن الكلي: 61.80 كجم.
   - الكتلة العضلية (SMM): 51.10 كجم (قاعدة قوية ممتازة لبناء الكتلة).
   - نسبة الدهون في الجسم: 13.0% (مثالية للتضخيم الصافي).
   - الدهون تحت الجلد: 9.1% | الدهون الحشوية: المستوى 5 (ممتاز).
   - معدل الأيض الأساسي (BMR): 1473 سعرة حرارية/يوم.
   - الهدف الرياضي: تضخيم صافي (Hypertrophy / Clean Bulking) على هدف 1800 - 1850 سعرة حرارية يومياً، وبروتين 115 - 120 جم.

2. بروتوكول سلامة الفقرات والعصب القطني (L4-L5):
   - قرار طبي حاسم: منع استخدام حزام/سترة شد الظهر لأنها تسبب خمول وضمور عضلات العمود الفقري العميقة.
   - البديل لشد القوام: تمرين Face Pulls لتقوية الكتف الخلفي وأعلى الظهر.
   - علاج وتخفيف عرق النسا: تمرين جسر المقعدة (Glute Bridges) وإطالة عضلة الكمثرية (Piriformis Stretch).
   - المشي الميداني بصلالة: 8,000 إلى 10,000 خطوة يومياً لتوسيع الفقرات وترطيب الغضاريف.

3. الوجبات المحددة:
   - الإفطار (450 Kcal / 28g P): 3 بيضات مسلوقة + خبز أسمر + خيار وطماطم.
   - السناك (220 Kcal / 8g P): كوب حليب/لبن + موز قبل التمرين بساعة.
   - الغداء (680 Kcal / 45g P): صدر دجاج / علبة تونة / طبق عدس + 7 ملاعق أرز + سلطة خضراء.
   - العشاء (380 Kcal / 25g P): علبة زبادي + قطعة جبن قريش/أبيض مع زيت زيتون وخيار.

عند الإجابة:
- كن دقيقاً جداً واذكر التوجيهات الطبية الرياضية لفقرات L4-L5 والوجبات.
- اجعل الإجابة مركزة، منظمة وواضحة وسريعة القراءة.
`;

    const contents = context
      ? `السياق الحالي للمستخدم: ${JSON.stringify(context)}\n\nسؤال المستخدم: ${message}`
      : message;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });

    const reply = response.text || "تم تحليل بياناتك بنجاح. استمر بالالتزام بجدول التمارين وترطيب الفقرات.";

    return NextResponse.json({ reply });
  } catch (error: any) {
    console.error("Gemini Coach API Error:", error);
    return NextResponse.json(
      {
        reply: "أهلاً بك! تذكر أن أولويتنا اليوم هي استهداف 1850 سعرة حرارية مع 120 جم بروتين، وحماية فقرات L4-L5 عبر تمارين Face Pulls وإطالة الكمثرية مع إكمال خطوات المشي بصلالة.",
        error: error?.message || "Internal error",
      },
      { status: 200 }
    );
  }
}
