import type { Metadata } from 'next';
import { Cairo } from 'next/font/google';
import './globals.css';

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  weight: ['400', '600', '700', '900'],
  variable: '--font-cairo',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'APEX FITNESS PRO STUDIO',
  description: 'تطبيق APEX FITNESS PRO STUDIO المتقدم: برنامج اليوم البصري التفاعلي، محاكي التمارين والحركات Biomechanical 3D، التشريح العضلي الدقيق، التضخيم الصافي، حماية الفقرات L4-L5، ومزامنة السحابة التلقائية عبر JSONBin.io.',
  openGraph: {
    title: 'APEX FITNESS PRO STUDIO',
    description: 'تطبيق APEX FITNESS PRO STUDIO المتقدم: برنامج اليوم البصري التفاعلي، محاكي التمارين والحركات Biomechanical 3D، التشريح العضلي الدقيق، التضخيم الصافي، حماية الفقرات L4-L5، ومزامنة السحابة التلقائية عبر JSONBin.io.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'APEX FITNESS PRO STUDIO',
    description: 'تطبيق APEX FITNESS PRO STUDIO المتقدم: برنامج اليوم البصري التفاعلي، محاكي التمارين والحركات Biomechanical 3D، التشريح العضلي الدقيق، التضخيم الصافي، حماية الفقرات L4-L5، ومزامنة السحابة التلقائية عبر JSONBin.io.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${cairo.className} bg-[#04070e] text-slate-100 antialiased font-sans`} suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
