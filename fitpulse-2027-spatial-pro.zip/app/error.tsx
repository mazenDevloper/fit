"use client";

import React, { useEffect } from "react";
import { AlertTriangle, RotateCcw, Home } from "lucide-react";
import Link from "next/link";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("App Runtime Error:", error);
  }, [error]);

  return (
    <div className="min-h-screen bg-[#04070e] text-slate-100 flex items-center justify-center p-6 text-center">
      <div className="max-w-md w-full bg-[#090d16] border border-red-500/30 p-8 rounded-3xl backdrop-blur-xl shadow-2xl space-y-5">
        <div className="w-14 h-14 mx-auto rounded-2xl bg-red-500/15 border border-red-500/40 flex items-center justify-center text-red-400">
          <AlertTriangle className="w-7 h-7" />
        </div>
        <div>
          <h2 className="text-xl font-black font-mono text-white">حدث خطأ في النظام</h2>
          <p className="text-xs text-slate-400 mt-2 font-mono">
            {error?.message || "تعذر تحميل الصفحة بشكل صحيح"}
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => reset()}
            className="flex-1 py-3 px-4 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 font-bold text-xs font-mono hover:bg-slate-800 transition flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>إعادة المحاولة</span>
          </button>
          <Link
            href="/"
            className="flex-1 py-3 px-4 rounded-xl bg-[#00f0ff] text-slate-950 font-bold text-xs font-mono hover:bg-[#00f0ff]/90 transition flex items-center justify-center gap-2"
          >
            <Home className="w-4 h-4" />
            <span>الرئيسية</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
